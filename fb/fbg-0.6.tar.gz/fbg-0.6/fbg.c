#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <curses.h>
#include <time.h>
#include "fb.h"
#include "fb_img.h"

#define KEY_ROTATE_CLOCKWISE        'l'
#define KEY_ROTATE_COUNTERCLOCKWISE 'r'
#define KEY_FIT_MIN                 'f'
#define KEY_FIT_MAX                 'F'
#define KEY_ORIGINAL                'o'
#define KEY_PREV_IMAGE              KEY_BACKSPACE
#define KEY_NEXT_IMAGE              ' '
#define KEY_QUIT                    'q'
#define KEY_DOWN_IMAGE              KEY_UP
#define KEY_UP_IMAGE                KEY_DOWN
#define KEY_LEFT_IMAGE              KEY_RIGHT
#define KEY_RIGHT_IMAGE             KEY_LEFT
#define KEY_SCROLL_DOWN_IMAGE       KEY_PPAGE
#define KEY_SCROLL_UP_IMAGE         KEY_NPAGE
#define KEY_SCROLL_LEFT_IMAGE       KEY_END
#define KEY_SCROLL_RIGHT_IMAGE      KEY_HOME
#define KEY_SHOW_IMAGE              '\n'
#define KEY_SPEED_UP                '-'
#define KEY_SPEED_DOWN              '+'

#define SPEED_RATIO 1.5
#define SPEED_MIN   0.1
#define SPEED_MAX   10
#define SKIP_MAX    10000
#define SCROLL_PX   10

static enum FIT {FIT_NONE, FIT_MAX, FIT_MIN} Fit = FIT_NONE;
static int Quiet = 0;

static int  get_size(char *file, int *w, int *h);
static int  get_next_id(FB_IMAGE *img, int id);
static void draw(FB_IMAGE *img, int ofst_x, int ofst_y);
static void show_img_info(int i, int total, char *name);
static void show_load_info(char *name);
static void show_skip_info(int skip);
static void clear_disp(void);
static void loop(int argc, char *argv[]);

static FB_IMAGE **load_frame(int *i, int argc, char *argv[]);
static FB_IMAGE **load_next_frame(int *i, int argc, char *argv[], int skip);
static FB_IMAGE **load_prev_frame(int *i, int argc, char *argv[], int skip);

int main(int argc, char *argv[])
{
  int opt;
  char *optstr = "cCfFqb:";
  char *usage = "Usage: %s [-cCfFq -b\"bgcolor\"] file\n";

  if(fb_open())
    goto END;

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'C':
      fb_clear();
    case 'c':
      puts("\033c");
      goto END;
      break;
    case 'f':
      Fit = FIT_MIN;
      break;
    case 'F':
      Fit = FIT_MAX;
      break;
    case 'b':
      {
	int r, g, b;
	if(sscanf(optarg, "%02x%02x%02x", &r, &g, &b) != 3){
	  fprintf(stderr, "error: option -b\n");
	  goto END;
	}
	fb_image_set_bg(r, g, b);
      }
      break;
    case 'q':
      Quiet = 1;
      break;
    default:
      printf(usage, argv[0]);
      goto END;
      break;
    }
  }

  if(argc - optind < 1){
    printf(usage, argv[0]);
    goto END;
  }

  loop(argc - optind, argv + optind);

 END:
  fb_close();
  return 0;
}

static void loop(int argc, char *argv[])
{
  FB_IMAGE **frame = NULL;
  int image_id, ofst_x, ofst_y, frame_id, cnt, skip, key;
  WINDOW *win;
  double speed;

  win = initscr();
  if(win == NULL)
    return;

  cbreak();
  noecho();
  nodelay(win, true);
  keypad(win, true);
   wgetch(win);

  image_id = -1;
  skip = 0;

  frame = load_next_frame(&image_id, argc, argv, skip);
  if(frame == NULL)
    goto END;

  ofst_x = ofst_y = 0;
  frame_id = 0;
  cnt = 0;
  speed = 1;

  clear_disp();
  draw(frame[frame_id], ofst_x, ofst_y);
  show_img_info(image_id, argc, argv[image_id]);

  while(1){
    switch(key = wgetch(win)){
    case KEY_SPEED_UP:
      speed /= SPEED_RATIO;
      if(speed < SPEED_MIN)
	speed *= SPEED_RATIO;
      skip = 0;
      break;
    case KEY_SPEED_DOWN:
      speed *= SPEED_RATIO;
      if(speed > SPEED_MAX)
	speed /= SPEED_RATIO;
      skip = 0;
      break;
    case KEY_SHOW_IMAGE:
      frame_id = get_next_id(frame[0], frame_id);
      cnt = skip = 0;
      show_img_info(image_id, argc, argv[image_id]);
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ROTATE_CLOCKWISE:
      ofst_x = ofst_y = 0;
      skip = 0;
      fb_frame_rotate(frame, 1);
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ROTATE_COUNTERCLOCKWISE:
      ofst_x = ofst_y = 0;
      skip = 0;
      fb_frame_rotate(frame, 0);
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_FIT_MIN:
      skip = 0;
      if(Fit == FIT_MIN)
	break;
      Fit = FIT_MIN;
      ofst_x = ofst_y = 0;
      fb_frame_free(frame);
      frame = load_frame(&image_id, argc, argv);
      if(frame == NULL)
	return;
      frame_id = cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_FIT_MAX:
      skip = 0;
      if(Fit == FIT_MAX)
	break;
      Fit = FIT_MAX;
      ofst_x = ofst_y = 0;
      fb_frame_free(frame);
      frame = load_frame(&image_id, argc, argv);
      if(frame == NULL)
	return;
      frame_id = cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ORIGINAL:
      speed = 1;
      skip = 0;
      if(Fit == FIT_NONE)
	break;
      Fit = FIT_NONE;
      ofst_x = ofst_y = 0;
      fb_frame_free(frame);
      frame = load_frame(&image_id, argc, argv);
      if(frame == NULL)
	return;
      frame_id = cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_PREV_IMAGE:
      fb_frame_free(frame);
      frame = load_prev_frame(&image_id, argc, argv, skip);
      skip = 0;
      if(frame == NULL){
	image_id = argc;
	frame = load_prev_frame(&image_id, argc, argv, skip);
	if(frame == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      frame_id = cnt = 0;
      speed = 1;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      show_img_info(image_id, argc, argv[image_id]);
      break;
    case KEY_NEXT_IMAGE:
      fb_frame_free(frame);
      frame = load_next_frame(&image_id, argc, argv, skip);
      skip = 0;
      if(frame == NULL){
	image_id = -1;
	frame = load_next_frame(&image_id, argc, argv, skip);
	if(frame == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      frame_id = cnt = 0;
      speed = 1;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      show_img_info(image_id, argc, argv[image_id]);
      break;
    case KEY_SCROLL_LEFT_IMAGE: case KEY_LEFT_IMAGE:
      if(frame[frame_id]->width - ofst_x > fb_width()){
	int px;
	if(key == KEY_SCROLL_LEFT_IMAGE)
	  px = fb_width();
	else
	  px = SCROLL_PX;

	if(frame[frame_id]->width - ofst_x - px > fb_width()){
	  ofst_x += px;
	}else{
	  ofst_x = frame[frame_id]->width - fb_width();
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      skip = 0;
      break;
    case KEY_SCROLL_RIGHT_IMAGE: case KEY_RIGHT_IMAGE:
      if(ofst_x > 0){
	int px;
	if(key == KEY_SCROLL_RIGHT_IMAGE)
	  px = fb_width();
	else
	  px = SCROLL_PX;

	if(ofst_x > px){
	  ofst_x -= px;
	}else{
	  ofst_x = 0;
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      skip = 0;
      break;
    case KEY_SCROLL_UP_IMAGE: case KEY_UP_IMAGE:
      if(frame[frame_id]->height - ofst_y > fb_height()){
	int px;
	if(key == KEY_SCROLL_UP_IMAGE)
	  px = fb_height();
	else
	  px = SCROLL_PX;

	if(frame[frame_id]->height - ofst_y - px > fb_height()){
	  ofst_y += px;
	}else{
	  ofst_y = frame[frame_id]->height - fb_height();
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      skip = 0;
      break;
    case KEY_SCROLL_DOWN_IMAGE: case KEY_DOWN_IMAGE:
      if(ofst_y > 0){
	int px;
	if(key == KEY_SCROLL_DOWN_IMAGE)
	  px = fb_height();
	else
	  px = SCROLL_PX;

	if(ofst_y > px){
	  ofst_y -= px;
	}else{
	  ofst_y = 0;
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      skip = 0;
      break;
    case '0': case '1': case '2': case '3': case '4':
    case '5': case '6': case '7': case '8': case '9':
      skip = skip * 10 + key - '0';
      if(skip > SKIP_MAX)
	skip /= 10;
      show_skip_info(skip);
      break;
    case KEY_QUIT:
      goto END;
    case ERR:
      {
#define MUL 4
	/*                                m  u  n */
	static struct timespec req = {0, 10000000 * MUL}, rem;
	nanosleep(&req, &rem);
	if(frame[0]->num < 2)
	  break;
	cnt++;
	if(cnt < frame[frame_id]->delay * speed / MUL)
	  break;
	frame_id = get_next_id(frame[0], frame_id);
	cnt = 0;
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      break;
    default:
      show_img_info(image_id, argc, argv[image_id]);
      draw(frame[frame_id], ofst_x, ofst_y);
      refresh();
    }
  }

 END:
  clear_disp();
  endwin();
  return;
}

static void show_img_info(int i, int total, char *name)
{
  if(! Quiet){
    mvprintw(LINES - 1, 0, "%d/%d (%s)", i + 1, total, name);
    move(LINES - 1, 0);
    refresh();
  }
}

static void show_load_info(char *name)
{
  static char msg[] = "loding... ";
  if(! Quiet){
    mvprintw(LINES - 1, 0, "%s%-*s", msg, COLS - sizeof(msg), name);
    move(LINES - 1, 0);
    refresh();
  }
}

static void show_skip_info(int skip)
{
  if(! Quiet){
    mvprintw(LINES - 1, 0, "%-*d", COLS - 1, skip);
    move(LINES - 1, 0);
    refresh();
  }
}

static int get_size(char *file, int *w, int *h)
{
  *w = 0;
  *h = 0;

  switch(Fit){
  case FIT_MIN:
    if(get_image_size(file, w, h))
      return 1;
    if(1.0 * *w / fb_width() > 1.0 * *h / fb_height()){
      *h *= fb_width() * 1.0 / *w;
      *w  = fb_width();
    }else{
      *w *= fb_height() * 1.0 / *h;
      *h  = fb_height();
    }
    break;
  case FIT_MAX:
    *w = fb_width();
    *h = fb_height();
    break;
  case FIT_NONE:
    *w = 0;
    *h = 0;
    break;
  }

  return 0;
}

static FB_IMAGE **load_frame(int *i, int argc, char *argv[])
{
  FB_IMAGE **frame = NULL;
  int w, h;

  show_load_info(argv[*i]);

  get_size(argv[*i], &w, &h);
  frame = fb_image_load(argv[*i], w, h);

  return frame;
}

static FB_IMAGE **load_next_frame(int *i, int argc, char *argv[], int skip)
{
  FB_IMAGE **frame = NULL;
  int w, h;

  if(skip == 0)
    skip = 1;

  (*i) += skip;
  while(*i >= 0 && *i < argc){
    show_load_info(argv[*i]);
    get_size(argv[*i], &w, &h);
    frame = fb_image_load(argv[*i], w, h);
    if(frame != NULL)
      break;
    (*i)++;
  }
  return frame;
}

static FB_IMAGE **load_prev_frame(int *i, int argc, char *argv[], int skip)
{
  FB_IMAGE **frame = NULL;
  int w, h;

  if(skip == 0)
    skip = 1;

  (*i) -= skip;
  while(*i >= 0 && *i < argc){
    show_load_info(argv[*i]);
    get_size(argv[*i], &w, &h);
    frame = fb_image_load(argv[*i], w, h);
    if(frame != NULL)
      break;
    (*i)--;
  }
  return frame;
}

static int get_next_id(FB_IMAGE *img, int id)
{
  id++;
  if(id >= img->num)
    id = 0;

  return id;
}

static void draw(FB_IMAGE *img, int ofst_x, int ofst_y)
{
  if(img == NULL)
    return;

  fb_image_draw(img, 0, 0, ofst_x, ofst_y, img->width - ofst_x, img->height - ofst_y);

}

static void clear_disp(void)
{
  fb_clear();
  clear();
  move(LINES - 1, 0);
  refresh();
}
