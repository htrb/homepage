/* $Id: fb.h,v 1.6 2002/10/10 16:16:03 ukai Exp $ */
#ifndef fb_header
#define fb_header
#include <linux/fb.h>

typedef struct FB_IMAGE_{
    int delay;
    int width;
    int height;
    int rowstride;
    int len;
    struct FB_IMAGE_ *next, *prev;
    unsigned char *data;
} FB_IMAGE;

typedef struct {
    int num;
    int wait, iterations;
    int width, height;
    FB_IMAGE *first, *last, *current;
} FB_ANIMATION;

FB_IMAGE *fb_image_new(int width, int height);
void fb_image_pset(FB_IMAGE * image, int x, int y, int r, int g, int b);
void fb_image_fill(FB_IMAGE * image, int r, int g, int b);
int fb_image_draw(FB_IMAGE * image, int x, int y, int sx, int sy, int width,
		  int height);
void fb_image_free(FB_IMAGE * image);
void fb_image_copy(FB_IMAGE * dest, FB_IMAGE * src);

FB_ANIMATION *fb_animation_new(int w, int h, int num);
void fb_animation_free(FB_ANIMATION *animation);

int fb_open(void);
void fb_close(void);
int fb_width(void);
int fb_height(void);

#endif
