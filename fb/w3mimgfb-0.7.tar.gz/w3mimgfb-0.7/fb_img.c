/* $Id: fb_img.c,v 1.5 2002/10/10 16:16:04 ukai Exp $ */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stimg.h>
#include "fb.h"
#include "fb_img.h"

static int bg_r = 0, bg_g = 0, bg_b = 0;

static void draw(FB_IMAGE *img, int x, int y, int w, int h, STIMG *image);

void
fb_image_set_bg(int r, int g, int b)
{
    bg_r = r;
    bg_g = g;
    bg_b = b;
}

int get_image_size(char *filename, int *w, int *h)
{
  if (filename == NULL)
    return 1;

  return stimg_animation_size(filename, w, h);
}

FB_ANIMATION *
fb_image_load(char *filename, int w, int h, int max_anim)
{
  STIMG_ANIMATION *animation;
  STIMG *image;
  int n, i, j, fw, fh, frame_num;
  int action = STIMG_FRAME_REVERT;
  FB_ANIMATION *fb_animation;
  FB_IMAGE *fb_image;

  if (filename == NULL)
    return NULL;

  animation = stimg_animation_load(filename);
  if (animation == NULL)
    return NULL;

  if (stimg_animation_get_first_image(animation) == NULL) {
    stimg_animation_delete(animation);
    return NULL;
  }

  fw = stimg_animation_get_width(animation);
  fh = stimg_animation_get_height(animation);
  frame_num = n =  stimg_animation_get_num(animation);

  if (max_anim < 0) {
    frame_num = (-max_anim > n) ? n : -max_anim;
  } else if (max_anim > 0) {
    frame_num = n = (max_anim > n) ? n : max_anim;
  }

  if (w < 1 || h < 1) {
    w = fw;
    h = fh;
  }

  if (w != fw || h != h) {
    STIMG_ANIMATION *tmp;
    tmp = stimg_animation_resize(animation, w, h, 1);
    stimg_animation_delete(animation);
    if (tmp == NULL)
      return NULL;

    animation = tmp;
  }

  fb_animation = fb_animation_new(w, h, frame_num);
  if (fb_animation == NULL)
    goto END;

  image = stimg_animation_get_first_image(animation);
  fb_image = fb_animation->first;
  if (bg_r != 0 || bg_g != 0 || bg_b != 0) 
    fb_image_fill(fb_image, bg_r, bg_g, bg_b);

  for (j = 0; j < n; j++) {
    fb_image->delay = stimg_animation_get_delay(animation);

    if (max_anim < 0) {
      i = j - n + frame_num;
    } else {
      i = j;
    }
    if (j > 0) {
      switch (action) {
      case STIMG_FRAME_RETAIN:
        if (i > 0)
          fb_image_copy(fb_image, fb_image->prev);
	break;
      case STIMG_FRAME_DISPOSE:
	if (bg_r != 0 || bg_g != 0 || bg_b != 0) {
	  fb_image_fill(fb_image, bg_r, bg_g, bg_b);
	}
	break;
      case STIMG_FRAME_REVERT:
        if (i > 0)
          fb_image_copy(fb_image, fb_image->prev);
	break;
      default:
        if (i > 0)
          fb_image_copy(fb_image, fb_image->prev);
      }
    }
    action = stimg_animation_get_action(animation);
    draw(fb_image, 
	 stimg_animation_get_x_offset(animation),
	 stimg_animation_get_y_offset(animation),
	 stimg_get_width(image), stimg_get_height(image),
	 image);
    if (i >= 0)
      fb_image = fb_image->next;
    image = stimg_animation_get_next_image(animation);
  }

  fb_animation->iterations = animation->iterations;

  END:
  stimg_animation_delete(animation);
  return fb_animation;
}

static void
draw(FB_IMAGE * img, int x, int y, int w, int h, STIMG *image)
{
  int i, j, r, g, b;
  unsigned char *pixels;
  int alpha;

  if (img == NULL || image == NULL)
    return;
  pixels = stimg_get_data(image);
  alpha = (stimg_get_has_alpha(image))? 1: 0;
  for (j = 0; j < h; j++) {
    for (i = 0; i < w; i++) {
      r = *pixels++;
      g = *pixels++;
      b = *pixels++;
      if (!(alpha && *pixels == 0)) {
	fb_image_pset(img, i + x, j + y, r, g, b);
      }
      pixels += alpha;
    }
  }
  return;
}
