#ifndef fb_img_header
#define fb_img_header

#ifdef IMLIB2
 #include "fb_imlib2.h"
#else
 #include "fb_gdkpixbuf.h"
#endif

IMAGE *fb_load_image(char *filename, int w, int h);
int    fb_draw_image(IMAGE *img, int x, int y, int sx, int sy, int width, int height);
int    fb_draw_image_simple(IMAGE *img, int x, int y);
int    fb_resize_image(IMAGE *img, int width, int height);
void   fb_free_image(IMAGE *img);
void   fb_set_bg(int r, int g, int b);
IMAGE *fb_dup_image(IMAGE *img);
int    fb_rotate_image(IMAGE *img, int angle);

#endif
