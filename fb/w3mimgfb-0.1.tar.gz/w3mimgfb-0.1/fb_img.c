#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "fb.h"
#include "fb_img.h"

static int bg_r = 0, bg_g = 0, bg_b = 0;

#ifdef IMLIB2
 #include "fb_imlib2.c"
#else
 #include "fb_gdkpixbuf.c"
#endif

int fb_draw_image_simple(IMAGE *img, int x, int y)
{
  return fb_draw_image(img, x, y, 0, 0, img->width, img->height);
}

void fb_set_bg(int r, int g, int b)
{
  bg_r = r;
  bg_g = g;
  bg_b = b;
}
