#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fb_img.h"

int main(int argc, char **argv)
{
  IMAGE  *image;

  fclose(stderr);
  if (argc < 2)
    exit(1);

  image = fb_load_image(argv[1], -1, -1);
  if(image == NULL)
    exit(1);

  printf("%d %d\n", image->width, image->height);

  exit(0);
}
