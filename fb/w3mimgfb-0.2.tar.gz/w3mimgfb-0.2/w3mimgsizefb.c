#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fb.h"
#include "fb_img.h"

int main(int argc, char **argv)
{
  int w, h;

  if (argc < 2)
    exit(1);

  if(get_image_size(argv[1], &w, &h))
    exit(1);

  printf("%d %d\n", w, h);

  exit(0);
}
