/* $Id: w3mimgdisplay.c,v 1.2 2002/01/31 18:28:24 ukai Exp $ */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "fb.h"
#include "fb_img.h"

static char *background = NULL;
static int offset_x = 0, offset_y = 0;
static int defined_bg = 0, defined_x = 0, defined_y = 0, defined_test = 0;
static int defined_debug = 0;

#define MAX_IMAGE 1000
typedef struct {
  FB_IMAGE *pixmap;
  int width;
  int height;
} Image;
static Image *imageBuf = NULL;
static int maxImage = 0;

static void GetOption(int argc, char **argv);
static void DrawImage(char *buf, int redraw);
static void ClearImage(void);

int
main(int argc, char **argv)
{
    int len, width, height;
    char buf[1024 + 128];

    GetOption(argc, argv);
    if (!defined_debug)
	fclose(stderr);

    if(fb_open())
      return 1;

    width = fb_width();
    height = fb_height();

    if (defined_test) {
	printf("%d %d\n", width - offset_x, height - offset_y);
	exit(0);
    }

    if(background != NULL){
      int r, g, b;
      if(sscanf(background, "#%02x%02x%02x", &r, &g, &b) == 3){
	fb_image_set_bg(r, g, b);
      }
    }

    while (fgets(buf, sizeof(buf), stdin) != NULL) {
	if (!(isdigit(buf[0]) && buf[1] == ';')) {
	    fputc('\n', stdout);
	    fflush(stdout);
	    continue;
	}
	len = strlen(buf);
	if (buf[len - 1] == '\n') {
	    buf[--len] = '\0';
	    if (buf[len - 1] == '\r')
		buf[--len] = '\0';
	}
	switch (buf[0]) {
	case '0':
	    DrawImage(&buf[2], 0);
	    break;
	case '1':
	    DrawImage(&buf[2], 1);
	    break;
	case '2':
	    ClearImage();
	    break;
	case '3':
	  //	    XSync(display, False);
	    break;
	case '4':
	    fputs("\n", stdout);
	    fflush(stdout);
	    break;
#if 0
	case '5':
	  {
	    IMAGE *im = fb_image_load(&buf[2], 0, 0);
	    fprintf(stdout, "%d %d\n", im->width, im->height);
	    fflush(stdout);
	    fb_image_free(im);
	  }
	  break;
#endif
	}
    }
    ClearImage();
    /*
     * XCloseDisplay(display);
     */
    fb_close();
    exit(0);
}

static void
GetOption(int argc, char **argv)
{
    int i;

    for (i = 1; i < argc; i++) {
	if (!strcmp("-bg", argv[i])) {
	    if (++i >= argc)
		exit(1);
	    background = argv[i];
	    defined_bg = 1;
	}
	else if (!strcmp("-x", argv[i])) {
	    if (++i >= argc)
		exit(1);
	    offset_x = atoi(argv[i]);
	    defined_x = 1;
	}
	else if (!strcmp("-y", argv[i])) {
	    if (++i >= argc)
		exit(1);
	    offset_y = atoi(argv[i]);
	    defined_y = 1;
	}
	else if (!strcmp("-test", argv[i])) {
	    defined_test = 1;
	}
	else if (!strcmp("-debug", argv[i])) {
	    defined_debug = 1;
	}
	else {
	    exit(1);
	}
    }
}

void
DrawImage(char *buf, int redraw)
{
    char *p = buf;
    FB_IMAGE *im;
    int n = 0, x = 0, y = 0, w = 0, h = 0, sx = 0, sy = 0, sw = 0, sh = 0;

    if (!p)
	return;
    for (; isdigit(*p); p++)
	n = 10 * n + (*p - '0');
    if (*(p++) != ';')
	return;
    for (; isdigit(*p); p++)
	x = 10 * x + (*p - '0');
    if (*(p++) != ';')
	return;
    for (; isdigit(*p); p++)
	y = 10 * y + (*p - '0');
    if (*(p++) != ';')
	return;
    for (; isdigit(*p); p++)
	w = 10 * w + (*p - '0');
    if (*(p++) != ';')
	return;
    for (; isdigit(*p); p++)
	h = 10 * h + (*p - '0');
    if (*(p++) != ';')
	return;
    for (; isdigit(*p); p++)
	sx = 10 * sx + (*p - '0');
    if (*(p++) != ';')
	return;
    for (; isdigit(*p); p++)
	sy = 10 * sy + (*p - '0');
    if (*(p++) != ';')
	return;
    for (; isdigit(*p); p++)
	sw = 10 * sw + (*p - '0');
    if (*(p++) != ';')
	return;
    for (; isdigit(*p); p++)
	sh = 10 * sh + (*p - '0');
    if (*(p++) != ';')
	return;

    n--;
    if (n < 0 || n >= MAX_IMAGE)
	return;
    if (redraw) {
	if (n >= maxImage || !imageBuf[n].pixmap)
	    return;
	goto draw_image;
    }

    if (n >= maxImage) {
      int i = maxImage;
      maxImage = i ? (i * 2) : 2;
      if (maxImage > MAX_IMAGE)
	maxImage = MAX_IMAGE;
      else if (n >= maxImage)
	maxImage = n + 1;
      imageBuf = (Image *) realloc((void *)imageBuf, sizeof(Image) * maxImage);
      for (; i < maxImage; i++)
	imageBuf[i].pixmap = NULL;
    }
    if (imageBuf[n].pixmap) {
      fb_image_free(imageBuf[n].pixmap);
      imageBuf[n].pixmap = NULL;
    }

    im = fb_image_load(p, w, h);
    if (!im)
      return;
    imageBuf[n].pixmap = im;

  draw_image:
    fb_image_draw(imageBuf[n].pixmap,
		  x + offset_x, y + offset_y,
		  sx, sy,
		  (sw ? sw : imageBuf[n].width), (sh ? sh : imageBuf[n].height));
}

void
ClearImage(void)
{
  if (imageBuf) {
    int i;
    for (i = 0; i < maxImage; i++) {
      if (imageBuf[i].pixmap){
	fb_image_free(imageBuf[i].pixmap);
      }
    }
    free(imageBuf);
    imageBuf = NULL;
  }
  maxImage = 0;
}
