/**************************************************************************
                fbg 0.5 Copyright (C) 2002, hito
 **************************************************************************/

#define PRG_NAME "fbg Version 0.5"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <curses.h>
#include <time.h>
#include "fb.h"
#include "fb_img.h"

#define KEY_ROTATE_CLOCKWISE        'r'
#define KEY_ROTATE_COUNTERCLOCKWISE 'R'
#define KEY_FIT_MIN                 'f'
#define KEY_FIT_MAX                 'F'
#define KEY_ORIGINAL                'o'
#define KEY_PREV_IMAGE              'p'
#define KEY_NEXT_IMAGE              'n'
#define KEY_QUIT                    'q'
#define KEY_DOWN_IMAGE              'k'
#define KEY_UP_IMAGE                'j'
#define KEY_LEFT_IMAGE              'h'
#define KEY_RIGHT_IMAGE             'l'
#define KEY_SHOW_IMAGE              ' '
#define KEY_SPEED_UP                '-'
#define KEY_SPEED_DOWN              '+'

#define SPEED_RATIO 1.5

enum FIT {FIT_NONE, FIT_MAX, FIT_MIN};

static int Fit = FIT_NONE;

static int  get_size(char *file, int *w, int *h);
static int  get_next_id(FB_IMAGE *img, int id);
static void draw(FB_IMAGE *img, int ofst_x, int ofst_y);
static void clear_disp(void);
static void loop(int argc, char *argv[]);

static FB_IMAGE **load_frame(int *i, int argc, char *argv[]);
static FB_IMAGE **load_next_frame(int *i, int argc, char *argv[]);
static FB_IMAGE **load_prev_frame(int *i, int argc, char *argv[]);

int main(int argc, char *argv[])
{
  int opt;
  char *optstr = "cCfFb:";
  char *usage = "Usage: %s [-cCfF -b\"bgcolor\"] file\n";

  if(fb_open())
    goto END;

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'C':
      fb_clear();
    case 'c':
      puts("\033c");
      goto END;
      break;
    case 'f':
      Fit = FIT_MIN;
      break;
    case 'F':
      Fit = FIT_MAX;
      break;
    case 'b':
      {
	int r, g, b;
	if(sscanf(optarg, "%02x%02x%02x", &r, &g, &b) != 3){
	  fprintf(stderr, "error: option -b\n");
	  goto END;
	}
	fb_image_set_bg(r, g, b);
      }
      break;
    default:
      printf(usage, argv[0]);
      goto END;
      break;
    }
  }

  if(argc - optind < 1){
    printf(usage, argv[0]);
    goto END;
  }

  loop(argc - optind, argv + optind);

 END:
  fb_close();
  return 0;
}

static void loop(int argc, char *argv[])
{
  FB_IMAGE **frame = NULL;
  int image_id, ofst_x, ofst_y, frame_id, cnt;
  WINDOW *win;
  double speed;

  win = initscr();
  if(win == NULL)
    return;

  cbreak();
  noecho();
  nodelay(win, true);
  wgetch(win);

  image_id = -1;
  frame = load_next_frame(&image_id, argc, argv);
  if(frame == NULL)
    goto END;

  ofst_x = ofst_y = 0;
  frame_id = 0;
  cnt = 0;
  speed = 1;

  draw(frame[frame_id], ofst_x, ofst_y);

  while(1){
    switch(wgetch(win)){
    case KEY_SPEED_UP:
      speed /= SPEED_RATIO;
      if(speed < 0.1)
	speed *= SPEED_RATIO;
      break;
    case KEY_SPEED_DOWN:
      speed *= SPEED_RATIO;
      if(speed > 10)
	speed /= SPEED_RATIO;
      break;
    case KEY_SHOW_IMAGE:
      frame_id = get_next_id(frame[0], frame_id);
      cnt = 0;
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ROTATE_CLOCKWISE:
      ofst_x = ofst_y = 0;
      fb_frame_rotate(frame, 1);
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ROTATE_COUNTERCLOCKWISE:
      ofst_x = ofst_y = 0;
      fb_frame_rotate(frame, 0);
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_FIT_MIN:
      if(Fit == FIT_MIN)
	break;
      Fit = FIT_MIN;
      ofst_x = ofst_y = 0;
      fb_frame_free(frame);
      frame = load_frame(&image_id, argc, argv);
      if(frame == NULL)
	return;
      frame_id = 0;
      cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_FIT_MAX:
      if(Fit == FIT_MAX)
	break;
      Fit = FIT_MAX;
      ofst_x = ofst_y = 0;
      fb_frame_free(frame);
      frame = load_frame(&image_id, argc, argv);
      if(frame == NULL)
	return;
      frame_id = 0;
      cnt = 0;
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ORIGINAL:
      speed = 1;
      if(Fit == FIT_NONE)
	break;
      Fit = FIT_NONE;
      ofst_x = ofst_y = 0;
      fb_frame_free(frame);
      frame = load_frame(&image_id, argc, argv);
      if(frame == NULL)
	return;
      frame_id = 0;
      cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_PREV_IMAGE:
      fb_frame_free(frame);
      frame = load_prev_frame(&image_id, argc, argv);
      if(frame == NULL){
	image_id = argc;
	frame = load_prev_frame(&image_id, argc, argv);
	if(frame == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      frame_id = 0;
      cnt = 0;
      speed = 1;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_NEXT_IMAGE:
      fb_frame_free(frame);
      frame = load_next_frame(&image_id, argc, argv);
      if(frame == NULL){
	image_id = -1;
	frame = load_next_frame(&image_id, argc, argv);
	if(frame == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      frame_id = 0;
      cnt = 0;
      speed = 1;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_LEFT_IMAGE:
      if(frame[frame_id]->width - ofst_x > fb_width()){
	if(frame[frame_id]->width - ofst_x - fb_width() > fb_width()){
	  ofst_x += fb_width();
	}else{
	  ofst_x = frame[frame_id]->width - fb_width();
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      break;
    case KEY_RIGHT_IMAGE:
      if(ofst_x > 0){
	if(ofst_x > fb_width()){
	  ofst_x -= fb_width();
	}else{
	  ofst_x = 0;
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      break;
    case KEY_UP_IMAGE:
      if(frame[frame_id]->height - ofst_y > fb_height()){
	if(frame[frame_id]->height - ofst_y - fb_height() > fb_height()){
	  ofst_y += fb_height();
	}else{
	  ofst_y = frame[frame_id]->height - fb_height();
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      break;
    case KEY_DOWN_IMAGE:
      if(ofst_y > 0){
	if(ofst_y > fb_height()){
	  ofst_y -= fb_height();
	}else{
	  ofst_y = 0;
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      break;
    case KEY_QUIT:
      goto END;
    default:
      {
	#define MUL 10
	/*                         m  u  n */
	struct timespec req = {0, 10000000 * MUL}, rem;
	nanosleep(&req, &rem);
	if(frame[0]->num < 2)
	  break;
	cnt++;
	if(cnt < frame[frame_id]->delay * speed / MUL)
	  break;
	frame_id = get_next_id(frame[0], frame_id);
	cnt = 0;
	draw(frame[frame_id], ofst_x, ofst_y);
      }
    }
  }

 END:
  clear_disp();
  endwin();
  return;
}

static int get_size(char *file, int *w, int *h)
{
  *w = 0;
  *h = 0;

  switch(Fit){
  case FIT_MIN:
    if(get_image_size(file, w, h))
      return 1;
    if(*w > fb_width() || *h > fb_height()){
      if(1.0 * *w / fb_width() > 1.0 * *h / fb_height()){
	*h *= fb_width() * 1.0 / *w;
	*w  = fb_width();
      }else{
	*w *= fb_height() * 1.0 / *h;
	*h  = fb_height();
      }
    }
    break;
  case FIT_MAX:
    *w = fb_width();
    *h = fb_height();
    break;
  }

  return 0;
}

static FB_IMAGE **load_frame(int *i, int argc, char *argv[])
{
  FB_IMAGE **frame = NULL;
  int w, h;

  get_size(argv[*i], &w, &h);
  frame = fb_image_load(argv[*i], w, h);

  return frame;
}

static FB_IMAGE **load_next_frame(int *i, int argc, char *argv[])
{
  FB_IMAGE **frame = NULL;
  int w, h;

  (*i)++;
  while(*i >= 0 && *i < argc){
    get_size(argv[*i], &w, &h);
    frame = fb_image_load(argv[*i], w, h);
    if(fb_image_load != NULL)
      break;
    (*i)++;
  }
  return frame;
}

static FB_IMAGE **load_prev_frame(int *i, int argc, char *argv[])
{
  FB_IMAGE **frame = NULL;
  int w, h;

  (*i)--;
  while(*i >= 0 && *i < argc){
    get_size(argv[*i], &w, &h);
    frame = fb_image_load(argv[*i], w, h);
    if(frame != NULL)
      break;
    (*i)--;
  }
  return frame;
}

static int get_next_id(FB_IMAGE *img, int id)
{
  id++;
  if(id >= img->num)
    id = 0;

  return id;
}

static void draw(FB_IMAGE *img, int ofst_x, int ofst_y)
{
  if(img == NULL)
    return;

  fb_image_draw(img, 0, 0, ofst_x, ofst_y, img->width - ofst_x, img->height - ofst_y);

}

static void clear_disp(void)
{
  fb_clear();
}
