/* $Id: fb_img.c,v 1.3 2003/02/12 14:34:30 hito Exp $ */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "fb.h"
#include "fb_img.h"
#ifdef HAVE_CONFIG_H 
#include "config.h"
#endif

static int bg_r = 0, bg_g = 0, bg_b = 0;

#if defined(HAVE_LIBGDK_PIXBUF)
 #include "fb_gdkpixbuf.c"
#elif defined(HAVE_LIBSTIMG)
 #include "fb_stimg.c"
#elif defined(HAVE_IMLIB2)
 #include "fb_imlib2.c"
#endif

int fb_image_draw_simple(FB_IMAGE *img, int x, int y)
{
  return fb_image_draw(img, x, y, 0, 0, img->width, img->height);
}

void fb_image_set_bg(int r, int g, int b)
{
  bg_r = r;
  bg_g = g;
  bg_b = b;
}

