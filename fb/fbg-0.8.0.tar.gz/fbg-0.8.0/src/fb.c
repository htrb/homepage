/* $Id: fb.c,v 1.11 2003/07/10 23:08:33 hito Exp $ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <limits.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <linux/fb.h>

#include "fb.h"

#define FB_ENV		"FRAMEBUFFER"
#define	FB_DEFDEV	"/dev/fb0"

#define MONO_OFFSET_8BIT  0x40
#define COLORS_MONO_8BIT  0x40
#define MONO_MASK_8BIT    0xFC
#define MONO_SHIFT_8BIT   2

#define COLOR_OFFSET_8BIT 0x80
#define COLORS_8BIT       0x80
#define RED_MASK_8BIT     0xC0
#define GREEN_MASK_8BIT   0xE0
#define BLUE_MASK_8BIT    0xC0
#define RED_SHIFT_8BIT    1
#define GREEN_SHIFT_8BIT  3
#define BLUE_SHIFT_8BIT   6

#define FALSE 0
#define TRUE  1

#ifndef MAX
#define MAX(a, b)          (((a) > (b))? (a): (b)) 
#endif
#ifndef MIN
#define MIN(a, b)          (((a) < (b))? (a): (b)) 
#endif

#define IMAGE_SIZE_MAX 10000

static struct fb_cmap *fb_cmap_create(struct fb_fix_screeninfo *,
				      struct fb_var_screeninfo *);
static void fb_cmap_destroy(struct fb_cmap *cmap);
static int fb_fscrn_get(int fbfp, struct fb_fix_screeninfo *scinfo);
static void *fb_mmap(int fbfp, struct fb_fix_screeninfo *scinfo);
static int fb_munmap(void *buf, struct fb_fix_screeninfo *scinfo);
static int fb_vscrn_get(int fbfp, struct fb_var_screeninfo *scinfo);
static int fb_cmap_set(int fbfp, struct fb_cmap *cmap);
static int fb_cmap_get(int fbfp, struct fb_cmap *cmap);
static int fb_cmap_init(void);
static int fb_get_cmap_index(int r, int g, int b);

static unsigned long fb_get_packed_color8(int r, int g, int b);
static unsigned long fb_get_packed_color15(int r, int g, int b);
static unsigned long fb_get_packed_color16(int r, int g, int b);
static unsigned long fb_get_packed_color24(int r, int g, int b);
static unsigned long fb_get_packed_color_other(int r, int g, int b);

static unsigned long (*fb_get_packed_color)(int r, int g, int b);

static struct fb_fix_screeninfo fscinfo;
static struct fb_var_screeninfo vscinfo;
static struct fb_cmap *cmap = NULL, *cmap_org = NULL;
static int is_open = FALSE;
static int fbfp = -1;
static size_t pixel_size = 0;
static unsigned char *buf = NULL;

static int rlen, roff, rmask, glen, goff, gmask, blen, boff, bmask;

int
fb_open(void)
{
    char *fbdev = { FB_DEFDEV };

    if (is_open == TRUE)
	return 1;

    if (getenv(FB_ENV)) {
	fbdev = getenv(FB_ENV);
    }

    if ((fbfp = open(fbdev, O_RDWR)) == -1) {
	fprintf(stderr, "open %s error\n", fbdev);
	goto ERR_END;
    }

    if (fb_fscrn_get(fbfp, &fscinfo)) {
	goto ERR_END;
    }

    if (fb_vscrn_get(fbfp, &vscinfo)) {
	goto ERR_END;
    }

    if ((cmap = fb_cmap_create(&fscinfo, &vscinfo)) == (struct fb_cmap *)-1) {
	goto ERR_END;
    }

    if (!(buf = fb_mmap(fbfp, &fscinfo))) {
	fprintf(stderr, "Can't allocate memory.\n");
	goto ERR_END;
    }

    if (fscinfo.type != FB_TYPE_PACKED_PIXELS) {
	fprintf(stderr, "This type of framebuffer is not supported.\n");
	goto ERR_END;
    }

    if (fscinfo.visual == FB_VISUAL_PSEUDOCOLOR && vscinfo.bits_per_pixel == 8) {
	if (fb_cmap_get(fbfp, cmap)) {
	    fprintf(stderr, "Can't get color map.\n");
	    fb_cmap_destroy(cmap);
	    cmap = NULL;
	    goto ERR_END;
	}

	if (fb_cmap_init())
	    goto ERR_END;

	pixel_size = 1;
    }
    else if ((fscinfo.visual == FB_VISUAL_TRUECOLOR ||
	      fscinfo.visual == FB_VISUAL_DIRECTCOLOR) &&
	     (vscinfo.bits_per_pixel == 15 ||
	      vscinfo.bits_per_pixel == 16 ||
	      vscinfo.bits_per_pixel == 24 || vscinfo.bits_per_pixel == 32)) {
	pixel_size = (vscinfo.bits_per_pixel + 7) / CHAR_BIT;
    }
    else {
	fprintf(stderr, "This type of framebuffer is not supported.\n");
	goto ERR_END;
    }

    rlen  = CHAR_BIT - vscinfo.red.length;
    roff  = vscinfo.red.offset;
    rmask = 0x00ff >> rlen;
    glen  = CHAR_BIT - vscinfo.green.length;
    goff  = vscinfo.green.offset;
    gmask = 0x00ff >> glen;
    blen  = CHAR_BIT - vscinfo.blue.length;
    boff  = vscinfo.blue.offset;
    bmask = 0x00ff >> blen;

    if (pixel_size == 1) {
      fb_get_packed_color = fb_get_packed_color8;
    } else if (vscinfo.red.length == 5 && 
	       vscinfo.blue.length == 5 &&
	       vscinfo.green.length == 5 &&
	       vscinfo.red.offset == 10 && 
	       vscinfo.green.offset == 5 &&
	       vscinfo.blue.offset == 0) {
      fb_get_packed_color = fb_get_packed_color15;
    } else if (vscinfo.red.length == 5 &&
	       vscinfo.blue.length == 5 &&
	       vscinfo.green.length == 6 &&
	       vscinfo.red.offset == 11 &&
	       vscinfo.green.offset == 5 &&
	       vscinfo.blue.offset == 0) {
      fb_get_packed_color = fb_get_packed_color16;
    } else if (vscinfo.red.length == 8 &&
	       vscinfo.blue.length == 8 &&
	       vscinfo.green.length == 8 &&
	       vscinfo.red.offset == 16 &&
	       vscinfo.green.offset == 8 &&
	       vscinfo.blue.offset == 0) {
      fb_get_packed_color = fb_get_packed_color24;
    } else {
      fb_get_packed_color = fb_get_packed_color_other;
    }

    is_open = TRUE;
    return 0;

  ERR_END:
    fb_close();
    return 1;
}

void
fb_close(void)
{
    if (is_open != TRUE)
	return;

    if (cmap != NULL) {
	fb_cmap_destroy(cmap);
	cmap = NULL;
    }
    if (cmap_org != NULL) {
	fb_cmap_set(fbfp, cmap_org);
	fb_cmap_destroy(cmap_org);
	cmap = NULL;
    }
    if (buf != NULL) {
	fb_munmap(buf, &fscinfo);
	buf = NULL;
    }

    if (fbfp >= 0) {
	close(fbfp);
    }

    is_open = FALSE;
}

/***********   fb_image_*  ***********/

FB_IMAGE *
fb_image_new(int width, int height)
{
    FB_IMAGE *image;

    if (is_open != TRUE)
	return NULL;

    if (width > IMAGE_SIZE_MAX || height > IMAGE_SIZE_MAX || width < 1
	|| height < 1)
	return NULL;

    image = malloc(sizeof(*image));
    if (image == NULL)
	return NULL;

    image->data = calloc(sizeof(*(image->data)), width * height * pixel_size);
    if (image->data == NULL) {
	free(image);
	return NULL;
    }

    image->num = 1;
    image->id = 0;
    image->delay = 0;
    image->loop = 0;

    image->width = width;
    image->height = height;
    image->rowstride = width * pixel_size;
    image->len = width * height * pixel_size;

    return image;
}

void
fb_image_free(FB_IMAGE * image)
{
    if (image == NULL)
	return;

    if (image->data != NULL)
	free(image->data);

    free(image);
}

void
fb_image_pset(FB_IMAGE * image, int x, int y, int r, int g, int b)
{
    unsigned long work;
    int i = pixel_size;
    unsigned char  *dist, *src = (unsigned char *) &work;

    if (image == NULL || is_open != TRUE)
	return;
    work = fb_get_packed_color(r, g, b);
    dist = image->data + image->rowstride * y + pixel_size * x;
    while (i--) *dist++ = *src++;
}

void
fb_image_fill(FB_IMAGE * image, int r, int g, int b)
{
    unsigned long work;
    int offset;

    if ( is_open != TRUE || image == NULL || image->data == NULL)
	return;

    work = fb_get_packed_color(r, g, b);
    for (offset = 0; offset < image->len; offset += pixel_size) {
	memcpy(image->data + offset, &work, pixel_size);
    }
}

void
fb_image_fill_area(FB_IMAGE * image, int x, int y, int w, int h, int r, int g, int b)
{
    unsigned long work;
    int offset, i, j;

    if ( is_open != TRUE || image == NULL || image->data == NULL)
	return;

    work = fb_get_packed_color(r, g, b);
    for (i = y; i < y + h; i++) {
      offset = pixel_size * (image->width * i + x);
      for (j = x; j < x + w; j++) {
	if (offset >= image->len)
	  return;
	memcpy(image->data + offset, &work, pixel_size);
	offset += pixel_size;
      }
    }
}

int
fb_image_draw(FB_IMAGE * image, int x, int y, int sx, int sy, int width,
	      int height)
{
    int i, offset_fb, offset_img;

    if (image == NULL || is_open != TRUE ||
	sx > image->width || sy > image->height ||
	x > fb_width() || y > fb_height())
	return 1;

    if (sx + width > image->width)
	width = image->width - sx;

    if (sy + height > image->height)
	height = image->height - sy;

    if (x + width > fb_width())
	width = fb_width() - x;

    if (y + height > fb_height())
	height = fb_height() - y;

    offset_fb = fscinfo.line_length * y + pixel_size * x;
    offset_img = image->rowstride * sy + pixel_size * sx;
    for (i = 0; i < height; i++) {
	memcpy(buf + offset_fb, image->data + offset_img, pixel_size * width);
	offset_fb += fscinfo.line_length;
	offset_img += image->rowstride;
    }

    return 0;
}

void
fb_image_rotate(FB_IMAGE * image, int direction)
{
    unsigned char *src, *dest, *tmp;
    int x, y, i, ofst;

    if (image == NULL ||
	image->data == NULL ||
	image->width < 1 || image->height < 1 ||
	image->len != image->rowstride * image->height)
	return;

    tmp = malloc(image->len);
    if (tmp == NULL)
	return;

    src = image->data;
    dest = tmp;

    if (direction) {
	int ofst2 = image->rowstride * (image->height - 1);
	for (x = 0; x < image->rowstride; x += pixel_size) {
	    ofst = ofst2 + x;
	    for (y = image->height - 1; y >= 0; y--) {
		memcpy(dest, src + ofst, pixel_size);
		dest += pixel_size;
		ofst -= image->rowstride;
	    }
	}
    }
    else {
	for (x = image->rowstride - pixel_size; x >= 0; x -= pixel_size) {
	    ofst = x;
	    for (y = 0; y < image->height; y++) {
		memcpy(dest, src + ofst, pixel_size);
		dest += pixel_size;
		ofst += image->rowstride;
	    }
	}
    }
    memcpy(src, tmp, image->len);
    i = image->width;
    image->width = image->height;
    image->height = i;
    image->rowstride = image->width * pixel_size;
    free(tmp);
}

void
fb_image_flip(FB_IMAGE *image)
{
    unsigned char *src, *dest, *tmp;
    int i;

    if (image == NULL ||
	image->data == NULL ||
	image->width < 1 || image->height < 1 ||
	image->len != image->rowstride * image->height)
	return;

    tmp = malloc(image->len);
    if (tmp == NULL)
	return;

    src = image->data + image->len;
    dest = tmp;

    for (i = 0; i < image->height; i++) {
      src  -= image->rowstride;
      memcpy(dest, src, image->rowstride);
      dest += image->rowstride;
    }
    memcpy(src, tmp, image->len);
    free(tmp);
}

void
fb_image_flop(FB_IMAGE *image)
{
    unsigned char *src, *dest, *tmp;
    int x, y;

    if (image == NULL ||
	image->data == NULL ||
	image->width < 1 || image->height < 1 ||
	image->len != image->rowstride * image->height)
	return;

    tmp = malloc(image->rowstride);
    if (tmp == NULL)
	return;

    src = image->data;
    for (y = 0; y < image->height; y++) {
      dest = tmp;
      src += image->rowstride;
      for (x = 0; x < image->width; x++) {
	src  -= pixel_size;
	memcpy(dest, src, pixel_size);
	dest += pixel_size;
      }
      memcpy(src, tmp, image->rowstride);
      src += image->rowstride;
    }
    free(tmp);
}

void
fb_image_copy(FB_IMAGE * dest, FB_IMAGE * src)
{
    if (dest == NULL || src == NULL || dest->data == NULL || src->data == NULL)
	return;

    if (dest->len != src->len)
	return;

    memcpy(dest->data, src->data, src->len);
}

FB_IMAGE *
fb_image_resize(FB_IMAGE *image, int w, int h, int aa)
{
  FB_IMAGE *new_image;
  int x, y, sw, sh;
  unsigned char *data_new, *data, *tmp;
  double ratio_w, ratio_h;

  if (image == NULL || image->data == NULL ||
      image->width < 1 || image->height < 1)
    return NULL;

  if (w < 1 || h < 1)
    return NULL;

  new_image = fb_image_new(w, h);
  if(new_image == NULL)
    return NULL;

  data = image->data;
  data_new = new_image->data;
  
  ratio_w = (double) image->width / w;
  ratio_h = (double) image->height / h;

  sw = image->width;
  sh = image->height;
  if (w == sw && h == sh) {
    memcpy(new_image->data, image->data, new_image->rowstride * h);
  } else if (aa == 0 || (w >= sw && h >= sh)) {
    for (y = 0; y < h; y++) {
      tmp = data + image->rowstride * (int)(y * ratio_h);
      for (x = 0; x < w; x++) {
	memcpy(data_new, tmp + pixel_size * (int)(x * ratio_w), pixel_size);
	data_new += pixel_size;
      }
    }
  } else {
    int ix, jx, iy, jy, i, j, n, r, g, b, rr, gg, bb;
    for (y = 0; y < h; y++) {
      iy = (y - 0.5) * ratio_h;
      iy = MAX(0, iy);
      jy = (y + 0.5) * ratio_h;
      jy = MIN(sh - 1, jy);
      for (x = 0; x < w; x++) {
	ix = (x - 0.5) * ratio_w;
	ix = MAX(0, ix);
	jx = (x + 0.5) * ratio_w;
	jx = MIN(sw - 1, jx);
	r = g = b = n = 0;
	for (i = iy; i <= jy; i++) {
	  for (j = ix; j <= jx; j++) {
	    fb_image_get_color(image, j, i, &rr, &gg, &bb);
	    r += rr;
	    g += gg;
	    b += bb;
	    n++;
	  }
	}
	fb_image_pset(new_image, x, y, r/n, g/n, b/n);
      }
    }
  }
  return new_image;
}

int
fb_image_get_color(FB_IMAGE *image, int x, int y, int *r, int *g, int *b)
{
    unsigned long work = 0;
    int offset;
    unsigned char *data;

    if (image == NULL || image->data == NULL ||
	x >= image->width || y >= image->height ||
	r == NULL || g == NULL || b == NULL)
      return 1;

    data = image->data;
    offset = image->rowstride * y + pixel_size * x;

    if (offset >= image->len)
	return 1;

    memcpy(&work, data + offset, pixel_size);

    if (pixel_size == 1) {
	if (cmap == NULL)
	    return 1;
	if (cmap->red)
	    *r = *(cmap->red + work) >> CHAR_BIT;
	if (cmap->green)
	    *g = *(cmap->green + work) >> CHAR_BIT;
	if (cmap->blue)
	    *b = *(cmap->blue + work) >> CHAR_BIT;
    } else {
	*r = ((work >> roff) & rmask) << rlen;
	*g = ((work >> goff) & gmask) << glen;
	*b = ((work >> boff) & bmask) << blen;
    }
    return 0;
}
/***********   fb_frame_*  ***********/

FB_IMAGE **
fb_frame_new(int w, int h, int n)
{
    FB_IMAGE **frame;
    int i, error = 0;

    if (w > IMAGE_SIZE_MAX || h > IMAGE_SIZE_MAX || w < 1 || h < 1 || n < 1)
	return NULL;

    frame = malloc(sizeof(*frame) * n);
    if (frame == NULL)
	return NULL;

    for (i = 0; i < n; i++) {
	frame[i] = fb_image_new(w, h);
	if (frame[i] == NULL) {
	    error = 1;
	} else {
	    frame[i]->num = n;
	    frame[i]->id = i;
	    frame[i]->delay = 1000;
	}
    }

    if (error) {
	fb_frame_free(frame);
	return NULL;
    }

    return frame;
}


void
fb_frame_free(FB_IMAGE ** frame)
{
    int i, n;

    if (frame == NULL)
	return;

    n = frame[0]->num;
    for (i = 0; i < n; i++) {
	fb_image_free(frame[i]);
    }
    free(frame);
}

void
fb_frame_rotate(FB_IMAGE ** frame, int direction)
{
    int i, n;

    if (frame == NULL)
      return;

    n = frame[0]->num;
    for (i = 0; i < n; i++) {
	fb_image_rotate(frame[i], direction);
    }
}

void
fb_frame_flip(FB_IMAGE ** frame)
{
    int i, n;

    if (frame == NULL)
      return;

    n = frame[0]->num;
    for (i = 0; i < n; i++) {
	fb_image_flip(frame[i]);
    }
}

void
fb_frame_flop(FB_IMAGE **frame)
{
    int i, n;

    if (frame == NULL)
      return;

    n = frame[0]->num;
    for (i = 0; i < n; i++) {
	fb_image_flop(frame[i]);
    }
}

FB_IMAGE **
fb_frame_resize(FB_IMAGE **frame, int w, int h, int aa)
{
  int i, n, error = 0;
  FB_IMAGE **new_frame;

  if (frame == NULL ||
      w < 1 || h < 1 ||
      w > IMAGE_SIZE_MAX || h > IMAGE_SIZE_MAX)
    return NULL;

  n = frame[0]->num;

  new_frame = malloc(sizeof(*new_frame) * n);
  if (new_frame == NULL)
    return NULL;

  for (i = 0; i < n; i++) {
    new_frame[i] = fb_image_resize(frame[i], w, h, aa);
    if (new_frame[i] == NULL) {
      error = 1;
    } else {
      new_frame[i]->num = n;
      new_frame[i]->id = i;
      new_frame[i]->delay = frame[i]->delay;
      new_frame[i]->loop = frame[i]->loop;
    }
  }

  if (error) {
    fb_frame_free(frame);
    return NULL;
  }

  return new_frame;
}
/*************************************/

void
fb_pset(int x, int y, int r, int g, int b)
{
    unsigned long work;
    int offset;

    if (is_open != TRUE || x >= vscinfo.xres || y >= vscinfo.yres)
	return;

    offset = fscinfo.line_length * y + pixel_size * x;

    if (offset >= fscinfo.smem_len)
	return;

    work = fb_get_packed_color(r, g, b);
    memcpy(buf + offset, &work, pixel_size);
}

int
fb_get_color(int x, int y, int *r, int *g, int *b)
{
    unsigned long work = 0;
    int offset;

    if (is_open != TRUE || x >= vscinfo.xres || y >= vscinfo.yres)
	return 1;

    offset = fscinfo.line_length * y + pixel_size * x;

    if (offset >= fscinfo.smem_len)
	return 1;

    memcpy(&work, buf + offset, pixel_size);

    if (pixel_size == 1) {
	if (cmap == NULL)
	    return 1;
	if (cmap->red)
	    *r = *(cmap->red + work) >> CHAR_BIT;
	if (cmap->green)
	    *g = *(cmap->green + work) >> CHAR_BIT;
	if (cmap->blue)
	    *b = *(cmap->blue + work) >> CHAR_BIT;
    }
    else {
	*r = ((work >> vscinfo.red.
	       offset) & (0x000000ff >> (CHAR_BIT - vscinfo.red.length)))
	    << (CHAR_BIT - vscinfo.red.length);
	*g = ((work >> vscinfo.green.
	       offset) & (0x000000ff >> (CHAR_BIT - vscinfo.green.length)))
	    << (CHAR_BIT - vscinfo.green.length);
	*b = ((work >> vscinfo.blue.
	       offset) & (0x000000ff >> (CHAR_BIT - vscinfo.blue.length)))
	    << (CHAR_BIT - vscinfo.blue.length);
    }
    return 0;
}

void
fb_clear(void)
{
    if (is_open != TRUE)
	return;

    memset(buf, 0,
	   (vscinfo.xres * vscinfo.yres * vscinfo.bits_per_pixel) / CHAR_BIT);
}

int
fb_width(void)
{
    if (is_open != TRUE)
	return 0;

    return vscinfo.xres;
}

int
fb_height(void)
{
    if (is_open != TRUE)
	return 0;

    return vscinfo.yres;
}

/********* static functions **************/
static unsigned long
fb_get_packed_color8(int r, int g, int b)
{
  return fb_get_cmap_index(r, g, b);
}

static unsigned long
fb_get_packed_color15(int r, int g, int b)
{
  return ((r & 0xf8) << 7) + ((g & 0xf8) << 2) + (b >> 3);
}

static unsigned long
fb_get_packed_color16(int r, int g, int b)
{
  return ((r & 0xf8) << 8) + ((g & 0xfc) << 3) + (b >> 3);
}

static unsigned long
fb_get_packed_color24(int r, int g, int b)
{
  return (r << 16) + (g << 8) + b;
}

static unsigned long
fb_get_packed_color_other(int r, int g, int b)
{
  return ((r >> rlen) << roff) + ((g >> glen) << goff) + ((b >> blen) << boff);
}

static int
fb_get_cmap_index(int r, int g, int b)
{
    int work;
    if ((r & GREEN_MASK_8BIT) == (g & GREEN_MASK_8BIT)
	&& (g & GREEN_MASK_8BIT) == (b & GREEN_MASK_8BIT)) {
	work = (r >> MONO_SHIFT_8BIT) + MONO_OFFSET_8BIT;
    }
    else {
	work = ((r & RED_MASK_8BIT) >> RED_SHIFT_8BIT)
	    + ((g & GREEN_MASK_8BIT) >> GREEN_SHIFT_8BIT)
	    + ((b & BLUE_MASK_8BIT) >> BLUE_SHIFT_8BIT)
	    + COLOR_OFFSET_8BIT;
    }
    return work;
}

static int
fb_cmap_init(void)
{
    int lp;

    if (cmap == NULL)
	return 1;

    if (cmap->len < COLOR_OFFSET_8BIT + COLORS_8BIT) {
	fprintf(stderr, "Can't allocate enough color.\n");
	return 1;
    }

    if (cmap_org == NULL) {
	if ((cmap_org =
	     fb_cmap_create(&fscinfo, &vscinfo)) == (struct fb_cmap *)-1) {
	    return 1;
	}

	if (fb_cmap_get(fbfp, cmap_org)) {
	    fprintf(stderr, "Can't get color map.\n");
	    fb_cmap_destroy(cmap_org);
	    cmap_org = NULL;
	    return 1;
	}
    }

    cmap->start = MONO_OFFSET_8BIT;
    cmap->len = COLORS_8BIT + COLORS_MONO_8BIT;

    for (lp = 0; lp < COLORS_MONO_8BIT; lp++) {
	int c;
	c = (lp << (MONO_SHIFT_8BIT + 8)) +
	    (lp ? (0xFFFF - (MONO_MASK_8BIT << 8)) : 0);
	if (cmap->red)
	    *(cmap->red + lp) = c;
	if (cmap->green)
	    *(cmap->green + lp) = c;
	if (cmap->blue)
	    *(cmap->blue + lp) = c;
    }

    for (lp = 0; lp < COLORS_8BIT; lp++) {
	int r, g, b;
	r = lp & (RED_MASK_8BIT >> RED_SHIFT_8BIT);
	g = lp & (GREEN_MASK_8BIT >> GREEN_SHIFT_8BIT);
	b = lp & (BLUE_MASK_8BIT >> BLUE_SHIFT_8BIT);
	if (cmap->red)
	    *(cmap->red + lp + COLORS_MONO_8BIT)
		= (r << (RED_SHIFT_8BIT + 8)) +
		(r ? (0xFFFF - (RED_MASK_8BIT << 8)) : 0);
	if (cmap->green)
	    *(cmap->green + lp + COLORS_MONO_8BIT)
		= (g << (GREEN_SHIFT_8BIT + 8)) +
		(g ? (0xFFFF - (GREEN_MASK_8BIT << 8)) : 0);
	if (cmap->blue)
	    *(cmap->blue + lp + COLORS_MONO_8BIT)
		= (b << (BLUE_SHIFT_8BIT + 8)) +
		(b ? (0xFFFF - (BLUE_MASK_8BIT << 8)) : 0);
    }

    if (fb_cmap_set(fbfp, cmap)) {
	fb_cmap_destroy(cmap);
	cmap = NULL;
	fprintf(stderr, "Can't set color map.\n");
	return 1;
    }
    return 0;
}

/*
 * (struct fb_cmap)$B%G%P%$%9$K0MB8$7$J$$%+%i!<%^%C%W>pJs(B
 * 
 * fb_cmap_create()     $B?75,$N%+%i!<%^%C%W>pJs(B
 * fb_cmap_destroy()    $B%+%i!<%^%C%W>pJs$NGK4~(B
 * fb_cmap_get()                $B>pJs$N3MF@(B
 * fb_cmap_set()                $B>pJs$N@_Dj(B
 */

#define	LUT_MAX		(256)

static struct fb_cmap *
fb_cmap_create(struct fb_fix_screeninfo *fscinfo,
	       struct fb_var_screeninfo *vscinfo)
{
    struct fb_cmap *cmap;
    int cmaplen = LUT_MAX;

    /* $B%+%i!<%^%C%W$NB8:_%A%'%C%/(B */
    if (fscinfo->visual == FB_VISUAL_MONO01 ||
	fscinfo->visual == FB_VISUAL_MONO10 ||
	fscinfo->visual == FB_VISUAL_TRUECOLOR)
	return NULL;

    cmap = (struct fb_cmap *)malloc(sizeof(struct fb_cmap));
    if (!cmap) {
	perror("cmap malloc error\n");
	return (struct fb_cmap *)-1;
    }
    memset(cmap, 0, sizeof(struct fb_cmap));

    /* $B3FJ,?'$,B8:_$7$=$&$@$C$?$i%+%i!<%^%C%WMQ$NNN0h$r3NJ](B */
    if (vscinfo->red.length) {
	cmap->red = (__u16 *) malloc(sizeof(__u16) * cmaplen);
	if (!cmap->red) {
	    perror("red lut malloc error\n");
	    return (struct fb_cmap *)-1;
	}
    }
    if (vscinfo->green.length) {
	cmap->green = (__u16 *) malloc(sizeof(__u16) * cmaplen);
	if (!cmap->green) {
	    if (vscinfo->red.length)
		free(cmap->red);
	    perror("green lut malloc error\n");
	    return (struct fb_cmap *)-1;
	}
    }
    if (vscinfo->blue.length) {
	cmap->blue = (__u16 *) malloc(sizeof(__u16) * cmaplen);
	if (!cmap->blue) {
	    if (vscinfo->red.length)
		free(cmap->red);
	    if (vscinfo->green.length)
		free(cmap->green);
	    perror("blue lut malloc error\n");
	    return (struct fb_cmap *)-1;
	}
    }
    if (vscinfo->transp.length) {
	cmap->transp = (__u16 *) malloc(sizeof(__u16) * cmaplen);
	if (!cmap->transp) {
	    if (vscinfo->red.length)
		free(cmap->red);
	    if (vscinfo->green.length)
		free(cmap->green);
	    if (vscinfo->blue.length)
		free(cmap->blue);
	    perror("transp lut malloc error\n");
	    return (struct fb_cmap *)-1;
	}
    }
    cmap->len = cmaplen;
    return cmap;
}

static void
fb_cmap_destroy(struct fb_cmap *cmap)
{
    if (cmap->red)
	free(cmap->red);
    if (cmap->green)
	free(cmap->green);
    if (cmap->blue)
	free(cmap->blue);
    if (cmap->transp)
	free(cmap->transp);
    free(cmap);
}

static int
fb_cmap_get(int fbfp, struct fb_cmap *cmap)
{
    if (ioctl(fbfp, FBIOGETCMAP, cmap)) {
	perror("ioctl FBIOGETCMAP error\n");
	return -1;
    }
    return 0;
}

static int
fb_cmap_set(int fbfp, struct fb_cmap *cmap)
{
    if (ioctl(fbfp, FBIOPUTCMAP, cmap)) {
	perror("ioctl FBIOPUTCMAP error\n");
	return -1;
    }
    return 0;
}

/*
 * $B%U%l!<%`%P%C%U%!$KBP$9$k%"%/%;%9(B
 * 
 * fb_mmap()            $B%U%l!<%`%P%C%U%!$N%a%b%j>e$X$N%^%C%W(B
 * fb_munmap()          $B%U%l!<%`%P%C%U%!$N%a%b%j>e$+$i$N%"%s%^%C%W(B
 */

static void *
fb_mmap(int fbfp, struct fb_fix_screeninfo *scinfo)
{
    void *buf;
    if ((buf = (unsigned char *)
	 mmap(NULL, scinfo->smem_len, PROT_READ | PROT_WRITE, MAP_SHARED, fbfp,
	      (off_t) 0))
	== MAP_FAILED) {
	perror("mmap error");
	return NULL;
    }
    return buf;
}

static int
fb_munmap(void *buf, struct fb_fix_screeninfo *scinfo)
{
    return munmap(buf, scinfo->smem_len);
}

/*
 * (struct fb_fix_screeninfo)$B%G%P%$%9$K0MB8$7$J$$8GDj$5$l$?>pJs(B
 * 
 * fb_fscrn_get()               $B>pJs$N3MF@(B
 */
static int
fb_fscrn_get(int fbfp, struct fb_fix_screeninfo *scinfo)
{
    if (ioctl(fbfp, FBIOGET_FSCREENINFO, scinfo)) {
	perror("ioctl FBIOGET_FSCREENINFO error\n");
	return -1;
    }
    return 0;
}

/*
 * (struct fb_var_screeninfo)$B%G%P%$%9$K0MB8$7$J$$JQ992DG=$J>pJs(B
 * 
 * fb_vscrn_get()               $B>pJs$N3MF@(B
 * fb_vscrn_set()               $B>pJs$N@_Dj(B
 */
static int
fb_vscrn_get(int fbfp, struct fb_var_screeninfo *scinfo)
{
    if (ioctl(fbfp, FBIOGET_VSCREENINFO, scinfo)) {
	perror("ioctl FBIOGET_VSCREENINFO error\n");
	return -1;
    }
    return 0;
}
