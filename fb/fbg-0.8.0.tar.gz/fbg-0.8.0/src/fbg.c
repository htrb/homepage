/* $Id: fbg.c,v 1.12 2003/05/25 14:26:21 hito Exp $ */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <curses.h>
#include <time.h>
#include "fb.h"
#include "fb_img.h"
#ifdef HAVE_CONFIG_H 
#include "config.h"
#endif

#ifndef PACKAGE
#define PACKAGE "fbg"
#endif
#ifndef VERSION
#define VERSION ""
#endif

#define KEY_ROTATE_CLOCKWISE        'l'
#define KEY_ROTATE_COUNTERCLOCKWISE 'r'
#define KEY_AA                      'A'
#define KEY_FIT_MIN                 'f'
#define KEY_FIT_MAX                 'F'
#define KEY_FLIP_IMAGE              'v'
#define KEY_FLOP_IMAGE              'h'
#define KEY_ORIGINAL_IMAGE          'o'
#define KEY_RELOAD_IMAGE            'R'
#define KEY_PREV_IMAGE              KEY_BACKSPACE
#define KEY_NEXT_IMAGE              ' '
#define KEY_QUIT                    'q'
#define KEY_QUIET                   'Q'
#define KEY_SHOW_INFO               '='
#define KEY_GOTO_NTH_IMAGE          'g'
#define KEY_DOWN_IMAGE              KEY_UP
#define KEY_UP_IMAGE                KEY_DOWN
#define KEY_LEFT_IMAGE              KEY_RIGHT
#define KEY_RIGHT_IMAGE             KEY_LEFT
#define KEY_SCROLL_DOWN_IMAGE       KEY_PPAGE
#define KEY_SCROLL_UP_IMAGE         KEY_NPAGE
#define KEY_SCROLL_LEFT_IMAGE       KEY_END
#define KEY_SCROLL_RIGHT_IMAGE      KEY_HOME
#define KEY_SHOW_IMAGE              '\n'
#define KEY_SPEED_UP                '-'
#define KEY_SPEED_DOWN              '+'

#define SPEED_RATIO 1.5
#define SPEED_MIN   0.1
#define SPEED_MAX   10
#define SKIP_MAX    10000
#define SCROLL_PX   10

static enum FIT {FIT_NONE, FIT_MAX, FIT_MIN} Fit = FIT_NONE;
static int Quiet = 0, Rotate = 0, Flip = 0, Flop = 0, Aa = 0;

static int  get_next_id(FB_IMAGE *img, int id);
static void draw(FB_IMAGE *img, int ofst_x, int ofst_y);
static void show_img_info(int i, int total, char *name, FB_IMAGE *img, int loop);
static void show_load_info(char *name);
static void show_skip_info(int skip);
static void clear_disp(void);
static void loop(int argc, char *argv[]);

static FB_IMAGE **load_frame(int *i, int argc, char *argv[], int w, int h);
static FB_IMAGE **load_next_frame(int *i, int argc, char *argv[], int skip);
static FB_IMAGE **load_prev_frame(int *i, int argc, char *argv[], int skip);
static FB_IMAGE **modify_frame(FB_IMAGE **frame);

int main(int argc, char *argv[])
{
  int opt;
  char *optstr = "cCfFlrhvaqqb:";
  char *usage = PACKAGE " " VERSION "\nUsage: %s [-cCfFlrhvaq -b\"bgcolor\"] file\n";

  if(fb_open())
    goto END;

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'C':
      fb_clear();
    case 'c':
      puts("\033c");
      goto END;
      break;
    case 'f':
      Fit = FIT_MIN;
      break;
    case 'F':
      Fit = FIT_MAX;
      break;
    case 'b':
      {
	int r, g, b;
	if(sscanf(optarg, "%02x%02x%02x", &r, &g, &b) != 3){
	  fprintf(stderr, "error: option -b\n");
	  goto END;
	}
	fb_image_set_bg(r, g, b);
      }
      break;
    case 'q':
      Quiet = 1;
      break;
    case 'l':
      Rotate = 1;
      break;
    case 'r':
      Rotate = -1;
      break;
    case 'h':
      Flop = 1;
      break;
    case 'v':
      Flip = 1;
      break;
    case 'a':
      Aa = 1;
      break;
    default:
      printf(usage, argv[0]);
      goto END;
      break;
    }
  }

  if(argc - optind < 1){
    printf(usage, argv[0]);
    goto END;
  }

  loop(argc - optind, argv + optind);

 END:
  fb_close();
  return 0;
}

static void loop(int argc, char *argv[])
{
  FB_IMAGE **frame = NULL;
  int image_id, ofst_x, ofst_y, frame_id, cnt, skip, key;
  WINDOW *win;
  double speed;

  win = initscr();
  if(win == NULL)
    return;

  cbreak();
  noecho();
  nodelay(win, true);
  keypad(win, true);
   wgetch(win);

  image_id = -1;
  skip = 0;

  frame = load_next_frame(&image_id, argc, argv, skip);
  if(frame == NULL)
    goto END;

  ofst_x = ofst_y = 0;
  frame_id = 0;
  cnt = 0;
  speed = 1;

  clear_disp();
  draw(frame[frame_id], ofst_x, ofst_y);
  show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);

  while(1){
    switch(key = wgetch(win)){
    case KEY_AA:
      Aa = ! Aa;
      skip = 0;
      show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
      break;
    case KEY_SPEED_UP:
      speed /= SPEED_RATIO;
      if(speed < SPEED_MIN)
	speed *= SPEED_RATIO;
      skip = 0;
      break;
    case KEY_SPEED_DOWN:
      speed *= SPEED_RATIO;
      if(speed > SPEED_MAX)
	speed /= SPEED_RATIO;
      skip = 0;
      break;
    case KEY_SHOW_IMAGE:
      frame_id = get_next_id(frame[0], frame_id);
      cnt = skip = 0;
      show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_FLIP_IMAGE:
      skip = 0;
      Flip = !Flip;
      fb_frame_flip(frame);
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_FLOP_IMAGE:
      skip = 0;
      Flop = !Flop;
      fb_frame_flop(frame);
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ROTATE_CLOCKWISE:
      ofst_x = ofst_y = 0;
      skip = 0;
      Rotate++;
      fb_frame_rotate(frame, 1);
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ROTATE_COUNTERCLOCKWISE:
      ofst_x = ofst_y = 0;
      skip = 0;
      Rotate--;
      fb_frame_rotate(frame, 0);
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_FIT_MIN:
      skip = 0;
      /*
      if(Fit == FIT_MIN)
	break;
      */
      Fit = FIT_MIN;
      {
	int tmp = Rotate;
	Rotate = 0;
	frame = modify_frame(frame);
	if(frame == NULL)
	  return;
	Rotate = tmp;
      }
      ofst_x = ofst_y = 0;
      frame_id = cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_FIT_MAX:
      skip = 0;
      /*
      if(Fit == FIT_MAX)
	break;
      */
      Fit = FIT_MAX;
      {
	int tmp = Rotate;
	Rotate = 0;
	frame = modify_frame(frame);
	if(frame == NULL)
	  return;
	Rotate = tmp;
      }
      frame_id = cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_ORIGINAL_IMAGE:
      speed = 1;
      skip = 0;
      /*
      if(Fit == FIT_NONE)
	break;
      */
      Fit = FIT_NONE;
      Rotate = 0;
      Flip = Flop = 0;
      ofst_x = ofst_y = 0;
      fb_frame_free(frame);
      frame = load_frame(&image_id, argc, argv, 0, 0);
      if(frame == NULL)
	return;
      frame_id = cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_RELOAD_IMAGE:
      skip = 0;
      {
	int w, h, tmp;
	tmp = Fit;
	Fit = FIT_NONE;
	w = (Rotate % 2)? frame[0]->height: frame[0]->width;
	h = (Rotate % 2)? frame[0]->width: frame[0]->height;
	fb_frame_free(frame);
	frame = load_frame(&image_id, argc, argv, w, h);
	if(frame == NULL)
	  return;
	Fit = tmp;
      }
      frame_id = cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      break;
    case KEY_GOTO_NTH_IMAGE:
      if (skip < 1 || skip > argc || image_id == skip - 1) {
	skip = 0;
	show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
	refresh();
	break;
      }
      image_id = skip - 1;
      skip = 0;
      {
	FB_IMAGE **new_frame;
	new_frame = load_frame(&image_id, argc, argv, 0, 0);
	if (new_frame == NULL)
	  break;
	fb_frame_free(frame);
	frame = new_frame;
      }	    
      frame_id = cnt = 0;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
      break;
    case KEY_PREV_IMAGE:
      fb_frame_free(frame);
      frame = load_prev_frame(&image_id, argc, argv, skip);
      skip = 0;
      if(frame == NULL){
	image_id = argc;
	frame = load_prev_frame(&image_id, argc, argv, skip);
	if(frame == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      frame_id = cnt = 0;
      speed = 1;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
      break;
    case KEY_NEXT_IMAGE:
      fb_frame_free(frame);
      frame = load_next_frame(&image_id, argc, argv, skip);
      skip = 0;
      if(frame == NULL){
	image_id = -1;
	frame = load_next_frame(&image_id, argc, argv, skip);
	if(frame == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      frame_id = cnt = 0;
      speed = 1;
      clear_disp();
      draw(frame[frame_id], ofst_x, ofst_y);
      show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
      break;
    case KEY_SCROLL_LEFT_IMAGE: case KEY_LEFT_IMAGE:
      if(frame[frame_id]->width - ofst_x > fb_width()){
	int px;
	if(key == KEY_SCROLL_LEFT_IMAGE)
	  px = fb_width();
	else
	  px = SCROLL_PX;

	if(frame[frame_id]->width - ofst_x - px > fb_width()){
	  ofst_x += px;
	}else{
	  ofst_x = frame[frame_id]->width - fb_width();
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      skip = 0;
      break;
    case KEY_SCROLL_RIGHT_IMAGE: case KEY_RIGHT_IMAGE:
      if(ofst_x > 0){
	int px;
	if(key == KEY_SCROLL_RIGHT_IMAGE)
	  px = fb_width();
	else
	  px = SCROLL_PX;

	if(ofst_x > px){
	  ofst_x -= px;
	}else{
	  ofst_x = 0;
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      skip = 0;
      break;
    case KEY_SCROLL_UP_IMAGE: case KEY_UP_IMAGE:
      if(frame[frame_id]->height - ofst_y > fb_height()){
	int px;
	if(key == KEY_SCROLL_UP_IMAGE)
	  px = fb_height();
	else
	  px = SCROLL_PX;

	if(frame[frame_id]->height - ofst_y - px > fb_height()){
	  ofst_y += px;
	}else{
	  ofst_y = frame[frame_id]->height - fb_height();
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      skip = 0;
      break;
    case KEY_SCROLL_DOWN_IMAGE: case KEY_DOWN_IMAGE:
      if(ofst_y > 0){
	int px;
	if(key == KEY_SCROLL_DOWN_IMAGE)
	  px = fb_height();
	else
	  px = SCROLL_PX;

	if(ofst_y > px){
	  ofst_y -= px;
	}else{
	  ofst_y = 0;
	}
	draw(frame[frame_id], ofst_x, ofst_y);
      }
      skip = 0;
      break;
    case KEY_QUIET:
      Quiet = !Quiet;
      if(Quiet){
	clrtoeol();
	refresh();
      } else {
	show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
      }
      skip = 0;
      break;
    case KEY_SHOW_INFO:
      {
	int tmp = Quiet;
	Quiet = 0;
	show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
	Quiet = tmp;
      }
      skip = 0;
      break;
    case '0': case '1': case '2': case '3': case '4':
    case '5': case '6': case '7': case '8': case '9':
      skip = skip * 10 + key - '0';
      if(skip > SKIP_MAX)
	skip /= 10;
      show_skip_info(skip);
      break;
    case KEY_QUIT:
      goto END;
    case ERR:
      {
#define MUL 4
	/*                                m  u  n */
	static struct timespec req = {0, 10000000 * MUL}, rem;
	int i;
	nanosleep(&req, &rem);
	if(frame[0]->num < 2)
	  break;
	cnt++;
	if(cnt < frame[frame_id]->delay * speed / MUL)
	  break;
	i = get_next_id(frame[0], frame_id);
	if (i == frame_id)
	  break;
	frame_id = i;
	cnt = 0;
	draw(frame[frame_id], ofst_x, ofst_y);
	if (skip == 0)
	  show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
	refresh();
      }
      break;
    default:
      skip = 0;
      draw(frame[frame_id], ofst_x, ofst_y);
      show_img_info(image_id, argc, argv[image_id], frame[frame_id], frame[0]->loop);
      refresh();
    }
  }

 END:
  clear_disp();
  endwin();
  return;
}

static void show_img_info(int i, int total, char *name, FB_IMAGE *img, int loop)
{
  static char *a = "NA";
  if(! Quiet){
    clrtoeol();
    refresh();
    if (img->num < 2) {
      mvprintw(LINES - 1, 0,
	       "[%1.1s] %d/%d %dx%d (%s)",
	       a + (Aa? 1: 0), i + 1, total,
	       img->width, img->height, name);
    } else if (img->num > 1 && loop > 0) {
      mvprintw(LINES - 1, 0,
	       "[%1.1s] %d/%d %dx%d[%d: %d/%d] (%s)",
	       a + (Aa? 1: 0), i + 1, total,
	       img->width, img->height, loop, img->id + 1, img->num, name);
    } else {
      mvprintw(LINES - 1, 0,
	       "[%1.1s] %d/%d %dx%d[%d/%d] (%s)",
	       a + (Aa? 1: 0), i + 1, total,
	       img->width, img->height, img->id + 1, img->num, name);
    }
    move(LINES - 1, 0);
    refresh();
  }
}

static void show_load_info(char *name)
{
  static char msg[] = "loding... ";
  if(! Quiet){
    mvprintw(LINES - 1, 0, "%s%-*s", msg, COLS - sizeof(msg), name);
    move(LINES - 1, 0);
    refresh();
  }
}

static void show_skip_info(int skip)
{
  mvprintw(LINES - 1, 0, "%-*d", COLS - 1, skip);
  move(LINES - 1, 0);
  refresh();
}

static FB_IMAGE **modify_frame(FB_IMAGE **frame)
{
  int w, h;

  if (frame == NULL)
    return NULL;

  Rotate %= 4;
  switch (Rotate) {
  case 1: case -3:
    fb_frame_rotate(frame, 1);
    break;
  case 2: case -2:
    fb_frame_flop(frame);
    fb_frame_flip(frame);
    break;
  case 3: case -1:
    fb_frame_rotate(frame, 0);
    break;
  }

  if (Flip)
    fb_frame_flip(frame);

  if (Flop)
    fb_frame_flop(frame);

  if (Fit != FIT_NONE) {
    switch(Fit){
    case FIT_MIN:
      w = frame[0]->width;
      h = frame[0]->height;
      if(1.0 * w / fb_width() > 1.0 * h / fb_height()){
	h *= fb_width() * 1.0 / w;
	w  = fb_width();
      }else{
	w *= fb_height() * 1.0 / h;
	h  = fb_height();
      }
      break;
    case FIT_MAX:
      w = fb_width();
      h = fb_height();
      break;
    default:
      w = frame[0]->width;
      h = frame[0]->height;
      break;
    }
    if (w != frame[0]->width && h != frame[0]->height) {
      FB_IMAGE **new_frame;

      new_frame = fb_frame_resize(frame, w, h, Aa);
      if (new_frame) {
	fb_frame_free(frame);
	frame = new_frame;
      }
    }
  }
  return frame;
}

static FB_IMAGE **load_frame(int *i, int argc, char *argv[], int w, int h)
{
  FB_IMAGE **frame = NULL;

  if (*i < 0 || *i >= argc)
    return NULL;

  show_load_info(argv[*i]);

  frame = fb_image_load(argv[*i], w, h);
  frame = modify_frame(frame);

  return frame;
}

static FB_IMAGE **load_next_frame(int *i, int argc, char *argv[], int skip)
{
  FB_IMAGE **frame = NULL;

  if(skip == 0)
    skip = 1;

  (*i) += skip;
  while(*i >= 0 && *i < argc){
    show_load_info(argv[*i]);
    frame = fb_image_load(argv[*i], 0, 0);
    if(frame != NULL) {
      frame = modify_frame(frame);
      break;
    }
    (*i)++;
  }
  return frame;
}

static FB_IMAGE **load_prev_frame(int *i, int argc, char *argv[], int skip)
{
  FB_IMAGE **frame = NULL;

  if(skip == 0)
    skip = 1;

  (*i) -= skip;
  while(*i >= 0 && *i < argc){
    show_load_info(argv[*i]);
    frame = fb_image_load(argv[*i], 0, 0);
    if(frame != NULL) {
      frame = modify_frame(frame);
      break;
    }
    (*i)--;
  }
  return frame;
}

static int get_next_id(FB_IMAGE *img, int id)
{
  id++;

  if (id >= img->num) {
    if (img->loop == 1)
      id--;
    else
      id = 0;

    if (img->loop > 1)
      img->loop -= 1;
  }

  return id;
}

static void draw(FB_IMAGE *img, int ofst_x, int ofst_y)
{
  if(img == NULL)
    return;

  fb_image_draw(img, 0, 0, ofst_x, ofst_y, img->width - ofst_x, img->height - ofst_y);

}

static void clear_disp(void)
{
  fb_clear();
  clear();
  move(LINES - 1, 0);
  refresh();
}
