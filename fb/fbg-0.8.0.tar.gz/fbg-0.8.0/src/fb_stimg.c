/* $Id: fb_stimg.c,v 1.6 2003/05/25 14:26:21 hito Exp $ */

#include <stimg.h>
#include "fb.h"
#include "fb_img.h"

static void draw(FB_IMAGE *img, int x, int y, int w, int h, STIMG *image);

int get_image_size(char *filename, int *w, int *h)
{
  if (filename == NULL)
    return 1;

  return stimg_animation_size(filename, w, h);
}

FB_IMAGE **
fb_image_load(char *filename, int w, int h)
{
  STIMG_ANIMATION *animation;
  STIMG *image;
  int n, i, fw, fh, loop;
  FB_IMAGE **fb_frame = NULL, *tmp_image = NULL;

  if (filename == NULL)
    return NULL;

  animation = stimg_animation_load(filename);
  if (animation == NULL)
    return NULL;

  if (stimg_animation_get_first_image(animation) == NULL) {
    stimg_animation_delete(animation);
    return NULL;
  }

  fw = stimg_animation_get_width(animation);
  fh = stimg_animation_get_height(animation);
  n =  stimg_animation_get_num(animation);
  loop = stimg_animation_get_iterations(animation);

  if (w < 1 || h < 1) {
    w = fw;
    h = fh;
  }

  if (w != fw || h != fh) {
    STIMG_ANIMATION *tmp;
    tmp = stimg_animation_resize(animation, w, h, 1);
    stimg_animation_delete(animation);
    if (tmp == NULL)
      return NULL;

    animation = tmp;
  }

  tmp_image = fb_image_new(w, h);
  if (tmp_image == NULL)
    goto END;
  if (bg_r != 0 || bg_g != 0 || bg_b != 0) 
    fb_image_fill(tmp_image, bg_r, bg_g, bg_b);

  fb_frame = fb_frame_new(w, h, n);
  if (fb_frame == NULL)
    goto END;

  fb_image_fill(fb_frame[0], bg_r, bg_g, bg_b);
    
  for (image = stimg_animation_get_first_image(animation), i = 0; image != NULL;
       image = stimg_animation_get_next_image(animation), i++) {
    fb_frame[i]->delay = stimg_animation_get_delay(animation);
    fb_frame[i]->loop = loop;
    fb_image_copy(fb_frame[i], tmp_image);
    draw(fb_frame[i],
	 stimg_animation_get_x_offset(animation),
	 stimg_animation_get_y_offset(animation),
	 stimg_get_width(image), stimg_get_height(image),
	 image);
    switch (stimg_animation_get_action(animation)) {
    case STIMG_FRAME_RETAIN:
      fb_image_copy(tmp_image, fb_frame[i]);
      break;
    case STIMG_FRAME_DISPOSE:
      break;
    case STIMG_FRAME_REVERT:
      fb_image_copy(tmp_image, fb_frame[0]);
      break;
    default:
      fb_image_copy(tmp_image, fb_frame[0]);
    }
  }
 END:
  if (tmp_image)
    fb_image_free(tmp_image);
  stimg_animation_delete(animation);
  return fb_frame;
}

static void
draw(FB_IMAGE * img, int x, int y, int w, int h, STIMG *image)
{
  int i, j, r, g, b;
  unsigned char *pixels;
  int alpha;

  if (img == NULL || image == NULL)
    return;
  pixels = stimg_get_data(image);
  alpha = (stimg_get_has_alpha(image))? 1: 0;
  for (j = 0; j < h; j++) {
    for (i = 0; i < w; i++) {
      r = *pixels++;
      g = *pixels++;
      b = *pixels++;
      if (!alpha || *pixels++ != 0) {
	fb_image_pset(img, i + x, j + y, r, g, b);
      }
    }
  }
  return;
}
