/**************************************************************************
                fbg 0.4 Copyright (C) 2002, hito
 **************************************************************************/

#define PRG_NAME "fbg Version 0.4"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <curses.h>
#include "fb.h"
#include "fb_img.h"

#define KEY_ROTATE_CLOCKWISE        'r'
#define KEY_ROTATE_COUNTERCLOCKWISE 'R'
#define KEY_FIT_MIN                 'f'
#define KEY_FIT_MAX                 'F'
#define KEY_ORIGINAL                'o'
#define KEY_PREV_IMAGE              'p'
#define KEY_NEXT_IMAGE              'n'
#define KEY_QUIT                    'q'
#define KEY_DOWN_IMAGE              'k'
#define KEY_UP_IMAGE                'j'
#define KEY_LEFT_IMAGE              'h'
#define KEY_RIGHT_IMAGE             'l'
#define KEY_SHOW_IMAGE              ' '

enum FIT {FIT_NONE, FIT_MAX, FIT_MIN};

static int Fit = FIT_NONE;

void draw(FB_IMAGE *img, int ofst_x, int ofst_y);
void clear_disp(void);
void loop(int argc, char *argv[]);

int main(int argc, char *argv[])
{
  int opt;
  char *optstr = "cCfFb:";
  char *usage = "Usage: %s [-cCfF -b\"bgcolor\"] file\n";

  if(fb_open())
    goto END;

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'C':
      fb_clear();
    case 'c':
      puts("\033c");
      goto END;
      break;
    case 'f':
      Fit = FIT_MIN;
      break;
    case 'F':
      Fit = FIT_MAX;
      break;
    case 'b':
      {
	int r, g, b;
	if(sscanf(optarg, "%02x%02x%02x", &r, &g, &b) != 3){
	  fprintf(stderr, "error: option -b\n");
	  goto END;
	}
	fb_image_set_bg(r, g, b);
      }
      break;
    default:
      printf(usage, argv[0]);
      goto END;
      break;
    }
  }

  if(argc - optind < 1){
    printf(usage, argv[0]);
    goto END;
  }

  loop(argc - optind, argv + optind);

 END:
  fb_close();
  return 0;
}


int get_size(char *file, int *w, int *h)
{
  *w = 0;
  *h = 0;

  switch(Fit){
  case FIT_MIN:
    if(get_image_size(file, w, h))
      return 1;
    if(*w > fb_width() || *h > fb_height()){
      if(1.0 * *w / fb_width() > 1.0 * *h / fb_height()){
	*h *= fb_width() * 1.0 / *w;
	*w  = fb_width();
      }else{
	*w *= fb_height() * 1.0 / *h;
	*h  = fb_height();
      }
    }
    break;
  case FIT_MAX:
    *w = fb_width();
    *h = fb_height();
    break;
  }

  return 0;
}

FB_IMAGE *load_img(int *i, int argc, char *argv[])
{
  FB_IMAGE *img = NULL;
  int w, h;

  get_size(argv[*i], &w, &h);
  img = fb_image_load(argv[*i], w, h);

  return img;
}

FB_IMAGE *load_next_img(int *i, int argc, char *argv[])
{
  FB_IMAGE *img = NULL;
  int w, h;

  (*i)++;
  while(*i >= 0 && *i < argc){
    get_size(argv[*i], &w, &h);
    img = fb_image_load(argv[*i], w, h);
    if(img != NULL)
      break;
    (*i)++;
  }
  return img;
}

FB_IMAGE *load_prev_img(int *i, int argc, char *argv[])
{
  FB_IMAGE *img = NULL;
  int w, h;

  (*i)--;
  while(*i >= 0 && *i < argc){
    get_size(argv[*i], &w, &h);
    img = fb_image_load(argv[*i], w, h);
    if(img != NULL)
      break;
    (*i)--;
  }
  return img;
}

void loop(int argc, char *argv[])
{
  FB_IMAGE *img = NULL;
  int i, ofst_x, ofst_y;
  WINDOW *win;

  win = initscr();
  if(win == NULL)
    return;

  cbreak();
  noecho();
  nodelay(win, true);
  wgetch(win);

  i = -1;
  img = load_next_img(&i, argc, argv);
  if(img == NULL)
    goto END;

  ofst_x = ofst_y = 0;
  draw(img, ofst_x, ofst_y);

  while(1){
    switch(wgetch(win)){
    case KEY_SHOW_IMAGE:
      clear_disp();
      draw(img, ofst_x, ofst_y);
      break;
    case KEY_ROTATE_CLOCKWISE:
      ofst_x = ofst_y = 0;
      fb_image_rotete(img, 1);
      clear_disp();
      draw(img, ofst_x, ofst_y);
      break;
    case KEY_ROTATE_COUNTERCLOCKWISE:
      ofst_x = ofst_y = 0;
      fb_image_rotete(img, 0);
      clear_disp();
      draw(img, ofst_x, ofst_y);
      break;
    case KEY_FIT_MIN:
      if(Fit == FIT_MIN)
	break;
      Fit = FIT_MIN;
      ofst_x = ofst_y = 0;
      fb_image_free(img);
      img = load_img(&i, argc, argv);
      if(img == NULL)
	return;
      clear_disp();
      draw(img, ofst_x, ofst_y);
      break;
    case KEY_FIT_MAX:
      if(Fit == FIT_MAX)
	break;
      Fit = FIT_MAX;
      ofst_x = ofst_y = 0;
      fb_image_free(img);
      img = load_img(&i, argc, argv);
      if(img == NULL)
	return;
      draw(img, ofst_x, ofst_y);
      break;
    case KEY_ORIGINAL:
      if(Fit == FIT_NONE)
	break;
      Fit = FIT_NONE;
      ofst_x = ofst_y = 0;
      fb_image_free(img);
      img = load_img(&i, argc, argv);
      if(img == NULL)
	return;
      clear_disp();
      draw(img, ofst_x, ofst_y);
      break;
    case KEY_PREV_IMAGE:
      fb_image_free(img);
      img = load_prev_img(&i, argc, argv);
      if(img == NULL){
	i = argc;
	img = load_prev_img(&i, argc, argv);
	if(img == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, ofst_x, ofst_y);
      break;
    case KEY_NEXT_IMAGE:
      fb_image_free(img);
      img = load_next_img(&i, argc, argv);
      if(img == NULL){
	i = -1;
	img = load_next_img(&i, argc, argv);
	if(img == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, ofst_x, ofst_y);
      break;
    case KEY_LEFT_IMAGE:
      if(img->width - ofst_x > fb_width()){
	if(img->width - ofst_x - fb_width() > fb_width()){
	  ofst_x += fb_width();
	}else{
	  ofst_x = img->width - fb_width();
	}
	draw(img, ofst_x, ofst_y);
      }
      break;
    case KEY_RIGHT_IMAGE:
      if(ofst_x > 0){
	if(ofst_x > fb_width()){
	  ofst_x -= fb_width();
	}else{
	  ofst_x = 0;
	}
	draw(img, ofst_x, ofst_y);
      }
      break;
    case KEY_UP_IMAGE:
      if(img->height - ofst_y > fb_height()){
	if(img->height - ofst_y - fb_height() > fb_height()){
	  ofst_y += fb_height();
	}else{
	  ofst_y = img->height - fb_height();
	}
	draw(img, ofst_x, ofst_y);
      }
      break;
    case KEY_DOWN_IMAGE:
      if(ofst_y > 0){
	if(ofst_y > fb_height()){
	  ofst_y -= fb_height();
	}else{
	  ofst_y = 0;
	}
	draw(img, ofst_x, ofst_y);
      }
      break;
    case KEY_QUIT:
      goto END;
    }
    usleep(1000);
  }

 END:
  clear_disp();
  endwin();
  return;
}

void draw(FB_IMAGE *img, int ofst_x, int ofst_y)
{
  if(img == NULL)
    return;

  fb_image_draw(img, 0, 0, ofst_x, ofst_y, img->width - ofst_x, img->height - ofst_y);

}

void clear_disp(void)
{
  fb_clear();
}
