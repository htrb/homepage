/**************************************************************************
                fbg 0.3 Copyright (C) 2002, hito
 **************************************************************************/

#define PRG_NAME "fbg Version 0.3"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <curses.h>
#include "fb.h"
#include "fb_img.h"

#define KEY_ROTATE_CLOCKWISE        'r'
#define KEY_ROTATE_COUNTERCLOCKWISE 'R'
#define KEY_FIT_MIN                 'f'
#define KEY_FIT_MAX                 'F'
#define KEY_ORIGINAL                'o'
#define KEY_PREV_IMAGE              'p'
#define KEY_NEXT_IMAGE              'n'
#define KEY_QUIT                    'q'
#define KEY_DOWN_IMAGE              'k'
#define KEY_UP_IMAGE                'j'
#define KEY_LEFT_IMAGE              'h'
#define KEY_RIGHT_IMAGE             'l'

#define MESSAGE_WAIT 500000

enum FIT {FIT_NONE, FIT_MAX, FIT_MIN};
enum ROTATE {ROTATE_NONE, ROTATE_CLOCKWIZE, ROTATE_COUNTERCLOCKWISE};

static int Fit = FIT_NONE, Rotate = ROTATE_NONE;

void draw(IMAGE *img, int ofst_x, int ofst_y);
void clear_disp(void);
void loop(int argc, char *argv[]);

int main(int argc, char *argv[])
{
  int opt;
  char *optstr = "cCfFrRh";
  char *usage = "Usage: %s [-cCfFrRh] file\n";

  if(fb_open())
    goto END;

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'C':
      fb_clear();
    case 'c':
      puts("\033c");
      goto END;
      break;
    case 'f':
      Fit = FIT_MIN;
      break;
    case 'F':
      Fit = FIT_MAX;
      break;
    case 'r':
      Rotate = ROTATE_CLOCKWIZE;
      break;
    case 'R':
      Rotate = ROTATE_COUNTERCLOCKWISE;
      break;
    case 'h':
      printf(usage, argv[0]);
      goto END;
      break;
    }
  }

  if(argc - optind < 1){
    printf(usage, argv[0]);
    goto END;
  }

  loop(argc - optind, argv + optind);

 END:
  fb_close();
  return 0;
}

IMAGE *open_next_img(int *i, int argc, char *argv[])
{
  IMAGE *img = NULL;

  (*i)++;
  while(*i >= 0 && *i < argc){
    img = fb_load_image(argv[*i], 0, 0);
    if(img != NULL)
      break;
    (*i)++;
  }
  return img;
}

IMAGE *open_prev_img(int *i, int argc, char *argv[])
{
  IMAGE *img = NULL;

  (*i)--;
  while(*i >= 0 && *i < argc){
    img = fb_load_image(argv[*i], 0, 0);
    if(img != NULL)
      break;
    (*i)--;
  }
  return img;
}

void loop(int argc, char *argv[])
{
  IMAGE *img = NULL;
  int i, ofst_x, ofst_y;
  WINDOW *win;

  win = initscr();
  if(win == NULL)
    return;

  cbreak();
  noecho();
  nodelay(win, true);
  wgetch(win);

  i = -1;
  img = open_next_img(&i, argc, argv);
  if(img == NULL)
    goto END;

  ofst_x = ofst_y = 0;
  draw(img, 0, 0);

  while(1){
    switch(wgetch(win)){
    case KEY_ROTATE_CLOCKWISE:
      Rotate = ROTATE_CLOCKWIZE;
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, 0, 0);
      break;
    case KEY_ROTATE_COUNTERCLOCKWISE:
      Rotate = ROTATE_COUNTERCLOCKWISE;
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, 0, 0);
      break;
    case KEY_FIT_MIN:
      Fit = FIT_MIN;
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, 0, 0);
      break;
    case KEY_FIT_MAX:
      Fit = FIT_MAX;
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, 0, 0);
      break;
    case KEY_ORIGINAL:
      Rotate = ROTATE_NONE;
      Fit = FIT_NONE;
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, 0, 0);
      break;
    case KEY_PREV_IMAGE:
      fb_free_image(img);
      img = open_prev_img(&i, argc, argv);
      if(img == NULL){
	printf("Jump to last image.\r");
	fflush(stdout);
	usleep(MESSAGE_WAIT);
	i = argc;
	img = open_prev_img(&i, argc, argv);
	if(img == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, 0, 0);
      break;
    case KEY_NEXT_IMAGE:
      fb_free_image(img);
      img = open_next_img(&i, argc, argv);
      if(img == NULL){
	printf("Jump to first image.\r");
	fflush(stdout);
	usleep(MESSAGE_WAIT);
	i = -1;
	img = open_next_img(&i, argc, argv);
	if(img == NULL)
	  return;
      }
      ofst_x = ofst_y = 0;
      clear_disp();
      draw(img, 0, 0);
      break;
    case KEY_LEFT_IMAGE:
      {
	int width;
	if(Rotate != ROTATE_NONE)
	  width = img->height;
	else
	  width = img->width;
	if(Fit == FIT_NONE && width - ofst_x > fb_width()){
	  if(width - ofst_x - fb_width() > fb_width()){
	    ofst_x += fb_width();
	  }else{
	    ofst_x = width - fb_width();
	  }
	  draw(img, ofst_x, ofst_y);
	}
      }
      break;
    case KEY_RIGHT_IMAGE:
      if(Fit == FIT_NONE && ofst_x > 0){
	if(ofst_x > fb_width()){
	  ofst_x -= fb_width();
	}else{
	  ofst_x = 0;
	}
	draw(img, ofst_x, ofst_y);
      }
      break;
    case KEY_UP_IMAGE:
      {
	int height;
	if(Rotate != ROTATE_NONE)
	  height = img->width;
	else
	  height = img->height;
	if(Fit == FIT_NONE && height - ofst_y > fb_height()){
	  if(height - ofst_y - fb_height() > fb_height()){
	    ofst_y += fb_height();
	  }else{
	    ofst_y = height - fb_height();
	  }
	  draw(img, ofst_x, ofst_y);
	}
      }
      break;
    case KEY_DOWN_IMAGE:
      if(Fit == FIT_NONE && ofst_y > 0){
	if(ofst_y > fb_height()){
	  ofst_y -= fb_height();
	}else{
	  ofst_y = 0;
	}
	draw(img, ofst_x, ofst_y);
      }
      break;
    case KEY_QUIT:
      goto END;
    }
    usleep(1000);
  }

 END:
  clear_disp();
  endwin();
  return;
}

void draw(IMAGE *img, int ofst_x, int ofst_y)
{
  int width, height;

  if(img == NULL)
    return;

  if(Rotate != ROTATE_NONE || Fit != FIT_NONE){
    img = fb_dup_image(img);
    if(img == NULL)
      return;
  }

  switch(Rotate){
  case ROTATE_CLOCKWIZE:
    fb_rotate_image(img, 90.0);
    break;
  case ROTATE_COUNTERCLOCKWISE:
    fb_rotate_image(img, -90);
    break;
  }
  
  width = img->width;
  height = img->height;

  switch(Fit){
  case FIT_MIN:
    if(width > fb_width() || height > fb_height()){
      if(1.0 * width / fb_width() > 1.0 * height / fb_height()){
	height *= fb_width() * 1.0 / width;
	width = fb_width();
      }else{
	width *= fb_height() * 1.0 / height;
	height = fb_height();
      }
    }
    break;
  case FIT_MAX:
    width = fb_width();
    height = fb_height();
    break;
  }
  
  fb_resize_image(img, width, height);
  fb_draw_image(img, 0, 0, ofst_x, ofst_y, width - ofst_x, height - ofst_y);

  if(Rotate != ROTATE_NONE || Fit != FIT_NONE){
    fb_free_image(img);
  }
}

void clear_disp(void)
{
  puts("\033c");
  fb_clear();
}
