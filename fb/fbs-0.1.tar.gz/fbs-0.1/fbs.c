/**************************************************************************
                fbs 0.1 Copyright (C) 2002, hito
 **************************************************************************/

#define PRG_NAME "fbs Version 0.1"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <Imlib2.h>

#include "fb.h"

void save_screen(char *file);

int main(int argc, char *argv[])
{
  char *usage = "Usage: %s file [wait]\n";
  int wait = 0;
  char *file;

  switch(argc){
  case 3:
    wait = atoi(argv[2]);
  case 2:
    file = argv[1];
    break;
  default:
    printf(usage, argv[0]);
    return 0;
  }

  if(fb_open()){
    fprintf(stderr, "Can't open frame buffer.\n");
    return 1;
  }

  if(wait > 0)
    sleep(wait);

  save_screen(argv[1]);

  fb_close();
  return 0;
}

void save_screen(char *file)
{
  Imlib_Image image;
  DATA32 *data;
  int i, j, r, g, b, offset, w, h;
  
  w = fb_width();
  h = fb_height();
  image = imlib_create_image(w, h);

  imlib_context_set_image(image);
  data = imlib_image_get_data();

  for(j = 0; j < h; j++){
    offset = j * w;
    for(i = 0; i < w; i++){
      if(fb_get_color(i, j, &r, &g, &b) != 0){
	return;
      }
      data[offset + i] = 0xff000000 + (r << 16) + (g << 8) + b;
    }
  }

  imlib_image_set_format("png");
  imlib_save_image(file);
  printf("save screen.\n");
}
