#ifndef __S_IMAGE_LOADER_HEADER__
#define __S_IMAGE_LOADER_HEADER__

#define FRAME_RETAIN  1
#define FRAME_DISPOSE 2
#define FRAME_REVERT  3

typedef struct _S_IMAGE {
  int w, h, rowstride;
  int alpha;
  int x_offset, y_offset, delay_time;
  int action;
  unsigned char *data;
  struct _S_IMAGE *next;
} S_IMAGE;

typedef struct {
  int w, h, n;
  S_IMAGE *data;
} S_ANIMATION;

S_IMAGE *image_new(int w, int h, int alpha);
S_IMAGE *image_load(char *file);
S_IMAGE *image_resize(S_IMAGE *image, int w, int h);
int      image_size(char *filename, int *w, int *h);
void     image_delete(S_IMAGE *image);

S_ANIMATION *image_animation_new(void);
S_ANIMATION *image_animation_load(char *file);
S_ANIMATION *image_animation_resize(S_ANIMATION *animation, int w, int h);
int          image_animation_size(char *filename, int *w, int *h);
void         image_animation_delete(S_ANIMATION *animation);
void         image_animation_add_frame(S_ANIMATION *animation, S_IMAGE *image);

#endif
