#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fb.h"
#include "fb_img.h"
#include "image.h"

static int bg_r = 0, bg_g = 0, bg_b = 0;

static void draw(FB_IMAGE *img, int bg, int x, int y, int w, int h, S_IMAGE *image);

FB_IMAGE **
fb_image_load(char *filename, int w, int h)
{
    S_ANIMATION *animation;
    S_IMAGE *image;
    int n, i, fw, fh;
    FB_IMAGE **fb_frame;
    int action = FRAME_REVERT;

    if (filename == NULL)
	return NULL;

    animation = image_animation_load(filename);
    if (animation == NULL)
	return NULL;

    if (animation->data == NULL) {
        image_animation_delete(animation);
	return NULL;
    }

    fw = animation->w;
    fh = animation->h;
    n = animation->n;

    if (w < 1 || h < 1) {
	w = fw;
	h = fh;
    }

    if (w != fw || h != h) {
      S_ANIMATION *tmp;
      tmp = image_animation_resize(animation, w, h);
      image_animation_delete(animation);
      if (tmp == NULL)
	return NULL;

      animation = tmp;
    }

    fb_frame = fb_frame_new(w, h, n);
    if (fb_frame == NULL)
	goto END;

    image = animation->data;
    for (i = 0; i < n; i++) {
	if (image == NULL)
	  break;

	fb_frame[i]->delay = image->delay_time;
	if (i > 0) {
	    switch (action) {
	    case FRAME_RETAIN:
		fb_image_copy(fb_frame[i], fb_frame[i - 1]);
		break;
	    case FRAME_DISPOSE:
		if (bg_r != 0 || bg_g != 0 || bg_b != 0) {
		    fb_image_fill(fb_frame[i], bg_r, bg_g, bg_b);
		}
		break;
	    case FRAME_REVERT:
		fb_image_copy(fb_frame[i], fb_frame[0]);
		break;
	    default:
		fb_image_copy(fb_frame[i], fb_frame[0]);
	    }
	}
	action = image->action;
	draw(fb_frame[i], !i, image->x_offset, image->y_offset, image->w, image->h, image);
	image = image->next;
    }
  END:
    image_animation_delete(animation);
    return fb_frame;
}

static void
draw(FB_IMAGE * img, int bg, int x, int y, int w, int h, S_IMAGE *image)
{
    int i, j, r, g, b, offset, bpp, rowstride;
    unsigned char *pixels;
    int alpha;

    if (img == NULL || image == NULL)
	return;
    rowstride = image->rowstride;
    pixels = image->data;
    alpha = image->alpha;
    bpp = rowstride / w;
    for (j = 0; j < h; j++) {
	offset = j * rowstride;
	for (i = 0; i < w; i++, offset += bpp) {
	    r = pixels[offset];
	    g = pixels[offset + 1];
	    b = pixels[offset + 2];
	    if (alpha && pixels[offset + 3] == 0) {
		if (bg)
		    fb_image_pset(img, i + x, j + y, bg_r, bg_g, bg_b);
	    }
	    else {
		fb_image_pset(img, i + x, j + y, r, g, b);
	    }
	}
    }
    return;
}

int fb_image_draw_simple(FB_IMAGE *img, int x, int y)
{
  return fb_image_draw(img, x, y, 0, 0, img->width, img->height);
}

void fb_image_set_bg(int r, int g, int b)
{
  bg_r = r;
  bg_g = g;
  bg_b = b;
}

