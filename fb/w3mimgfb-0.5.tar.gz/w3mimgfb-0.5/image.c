#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <assert.h>
#include "image.h"

typedef S_ANIMATION *(*S_IMAGE_ANIMATION_FUNC) (char *filename, int check);
typedef S_IMAGE *(*S_IMAGE_FUNC) (char *filename, int check);


/*** Image loader ***/

#ifdef USE_JPEG
S_ANIMATION *load_animation_jpeg(char *file, int check);
S_IMAGE     *load_jpeg(char *file, int check);
#endif

#ifdef USE_PNG
S_ANIMATION *load_animation_png(char *file, int check);
S_IMAGE     *load_png(char *file, int check);
#endif

#ifdef USE_TIFF
S_ANIMATION *load_animation_tiff(char *file, int check);
S_IMAGE     *load_tiff(char *file, int check);
#endif

S_ANIMATION *load_animation_gif(char *file, int check);
S_ANIMATION *load_animation_xpm(char *file, int check);
S_ANIMATION *load_animation_xbm(char *file, int check);
S_ANIMATION *load_animation_pnm(char *file, int check);
S_ANIMATION *load_animation_bmp(char *file, int check);
S_IMAGE     *load_gif(char *file, int check);
S_IMAGE     *load_xpm(char *file, int check);
S_IMAGE     *load_xbm(char *file, int check);
S_IMAGE     *load_pnm(char *file, int check);
S_IMAGE     *load_bmp(char *file, int check);

static S_IMAGE_ANIMATION_FUNC Image_animation_func[] = {
  load_animation_gif,
#ifdef USE_PNG
  load_animation_png,
#endif
#ifdef USE_JPEG
  load_animation_jpeg,
#endif
  load_animation_bmp,
#ifdef USE_TIFF
  load_animation_tiff,
#endif
  load_animation_xpm,
  load_animation_xbm,
  load_animation_pnm,
  NULL
};

static S_IMAGE_FUNC Image_func[] = {
  load_gif,
#ifdef USE_PNG
  load_png,
#endif
#ifdef USE_JPEG
  load_jpeg,
#endif
  load_bmp,
#ifdef USE_TIFF
  load_tiff,
#endif
  load_xpm,
  load_xbm,
  load_pnm,
  NULL
};
/********************/

#define S_IMAGE_FUNC_NUM (sizeof(Image_func)/sizeof(*Image_func))
#define S_IMAGE_ANIMATION_FUNC_NUM (sizeof(Image_animation_func)/sizeof(*Image_animation_func))

S_IMAGE *
image_load(char *filename)
{
  int i;
  S_IMAGE *image = NULL;

  for (i = 0; Image_func[i] != NULL; i++) {
    image = Image_func[i](filename, 0);
    if (image) break;
  }
  return image;
}

int
image_size(char *filename, int *w, int *h) 
{
  int i;
  S_IMAGE *image = NULL;

  for (i = 0; Image_func[i] != NULL; i++) {
    image = Image_func[i](filename, 1);
    if (image) break;
  }

  if (image == NULL)
    return 1;

  *w = image->w;
  *h = image->h;

  image_delete(image);

  return 0;
}

S_IMAGE *
image_new(int w, int h, int alpha)
{
  S_IMAGE *image;
  int bpp;

  if (w < 1 || h < 1)
    return NULL;

  bpp = 3 + ((alpha)? 1: 0);

  image = malloc(sizeof(S_IMAGE));
  if (image == NULL)
    return NULL;

  image->data = malloc(w * h * bpp);
  if (image->data == NULL) {
    free(image);
    return NULL;
  }

  image->w = w;
  image->h = h;
  image->alpha = alpha;
  image->rowstride = w * bpp;
  image->x_offset = 0;
  image->y_offset = 0;
  image->delay_time = 0;
  image->action = 0;
  image->next = NULL;
  
  return image;
}

void 
image_delete(S_IMAGE *image)
{
  S_IMAGE *tmp;
  while (image != NULL) {
    if (image->data)
      free(image->data);
    tmp = image->next;
    free(image);
    image = tmp;
  }
}

S_IMAGE *
image_resize(S_IMAGE *image, int w, int h)
{
  S_IMAGE *new_image;
  int x, y, bpp;
  unsigned char *data_new, *data, *tmp;
  double ratio_w, ratio_h;

  if (image == NULL || image->data == NULL || image->w < 1 || image->h < 1)
    return NULL;

  if (w < 1 || h < 1)
    return NULL;

  new_image = image_new(w, h, image->alpha);
  if(new_image == NULL)
    return NULL;

  data = image->data;
  bpp = 3 + image->alpha;
  ratio_w = (double) image->w / w;
  ratio_h = (double) image->h / h;

  data_new = new_image->data;
  new_image->x_offset = image->x_offset / ratio_w;
  new_image->y_offset = image->y_offset / ratio_h;
  new_image->delay_time = image->delay_time;
  new_image->action = image->action;
  new_image->next = NULL;

  if (w == image->w && h == image->h) {
    memcpy(new_image->data, image->data, new_image->rowstride * h);
  } else {
    for (y = 0; y < h; y++) {
      tmp = data + bpp * image->w * (int)(y * ratio_h);
      for (x = 0; x < w; x++) {
	memcpy(data_new, tmp + bpp * (int)(x * ratio_w), bpp);
	data_new += bpp;
      }
    }
  }
  return new_image;
}

S_ANIMATION *
image_animation_load(char *filename)
{
  int i;
  S_ANIMATION *animation = NULL;

  for (i = 0; Image_animation_func[i] != NULL; i++) {
    animation = Image_animation_func[i](filename, 0);
    if (animation) break;
  }
  return animation;
}

int
image_animation_size(char *filename, int *w, int *h) 
{
  int i;
  S_ANIMATION *animation = NULL;

  for (i = 0; Image_animation_func[i] != NULL; i++) {
    animation = Image_animation_func[i](filename, 1);
    if (animation) break;
  }

  if (animation == NULL)
    return 1;

  *w = animation->w;
  *h = animation->h;

  image_animation_delete(animation);

  return 0;
}

S_ANIMATION *
image_animation_new(void)
{
  S_ANIMATION *animation;

  animation = malloc(sizeof(S_ANIMATION));
  if (animation) {
    animation->n = 0;
    animation->data = NULL;
    animation->w = 0;
    animation->h = 0;
  }
  return animation;
}

void
image_animation_delete(S_ANIMATION *animation)
{
  if (animation == NULL)
    return;

  if (animation->data)
    image_delete(animation->data);

  free(animation);
}

S_ANIMATION *
image_animation_resize(S_ANIMATION *animation, int w, int h)
{
  S_ANIMATION *tmp;
  S_IMAGE *image, *resized_image;
  double ratio_w, ratio_h;

  if (animation == NULL || animation->data == NULL || animation->w < 1 || animation->h < 1)
    return NULL;

  if (w < 1 || h < 1)
    return NULL;

  tmp = image_animation_new();
  if (tmp == NULL)
    return NULL;

  ratio_w = (double) w / animation->w;
  ratio_h = (double) h / animation->h;

  for (image = animation->data; image != NULL; image = image->next) {
    int new_w, new_h;
    new_w = image->w * ratio_w + 0.5;
    new_h = image->h * ratio_h + 0.5;
    resized_image = image_resize(image, (new_w)? new_w: 1, (new_h)? new_h: 1);
    if (resized_image == NULL) {
      image_animation_delete(tmp);
      return NULL;
    }
    resized_image->x_offset = image->x_offset * ratio_w;
    resized_image->y_offset = image->y_offset * ratio_h;

    if (resized_image->x_offset + resized_image->w > w)
      resized_image->x_offset = w - resized_image->w;

    if (resized_image->y_offset + resized_image->h > h)
      resized_image->y_offset = h - resized_image->h;

    image_animation_add_frame(tmp, resized_image);
  }
  assert(tmp->w == w && tmp->h == h);

  return tmp;
}

void
image_animation_add_frame(S_ANIMATION *animation, S_IMAGE *image)
{
  S_IMAGE *tmp;
  int w, h, n;

  if (animation == NULL || image == NULL)
    return;

  w = animation->w;
  h = animation->h;
  n = 0;

  if (animation->data == NULL) {
    animation->data = image;
    w = image->w + image->x_offset;
    h = image->h + image->y_offset;
  } else {
    for (tmp = animation->data; tmp->next != NULL; tmp = tmp->next) {
      n++;
    } 
    n++;

    if (w < image->w + image->x_offset)
      w = image->w + image->x_offset;
    if (h < image->h + image->y_offset)
      h = image->h + image->y_offset;
    tmp->next = image;
  }

  animation->w = w;
  animation->h = h;
  animation->n = n + 1;
  return;
}
