/**************************************************************************
                fbs 0.2 Copyright (C) 2002, hito
 **************************************************************************/

#define PRG_NAME "fbs Version 0.2"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <png.h>
#include <zlib.h>

#include "fb.h"

int save_screen(char *file);

int main(int argc, char *argv[])
{
  char *usage = "Usage: %s file [wait]\n";
  int wait = 0;
  char *file;

  switch(argc){
  case 3:
    wait = atoi(argv[2]);
  case 2:
    file = argv[1];
    break;
  default:
    printf(usage, argv[0]);
    return 0;
  }

  if(fb_open()){
    fprintf(stderr, "Can't open frame buffer.\n");
    return 1;
  }

  if(wait > 0)
    sleep(wait);

  save_screen(argv[1]);

  fb_close();
  return 0;
}


int save_screen(char *filename)
{
   FILE *f = NULL;
   png_structp png_ptr = NULL;
   png_infop info_ptr = NULL;
   png_bytep data = NULL;
   png_color_8 sig_bit;
   int x, y, j, w, h, r, g, b;
   unsigned char *buf = NULL;

   w = fb_width();
   h = fb_height();

   buf = fb_get_screen();
   data = malloc(w * 3 * sizeof(char));
   if (buf ==NULL || data == NULL)
     goto END;

   png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
   if (png_ptr == NULL)
     goto END;

   info_ptr = png_create_info_struct(png_ptr);
   if (info_ptr == NULL)
     goto END;

   if (setjmp(png_ptr->jmpbuf))
     goto END;

   f = fopen(filename, "wb");
   if (f == NULL)
     goto END;

   printf("get screen.\r");
   fflush(stdout);

   png_init_io(png_ptr, f);
   png_set_IHDR(png_ptr, info_ptr, w, h, 8, PNG_COLOR_TYPE_RGB,
                PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_BASE,
                PNG_FILTER_TYPE_BASE);

   sig_bit.red = 8;
   sig_bit.green = 8;
   sig_bit.blue = 8;
   sig_bit.alpha = 8;
   png_set_sBIT(png_ptr, info_ptr, &sig_bit);
   png_set_compression_level(png_ptr, Z_BEST_SPEED);
   png_write_info(png_ptr, info_ptr);
   png_set_shift(png_ptr, &sig_bit);
   png_set_packing(png_ptr);

   for (y = 0; y < h; y++) {
     for (j = 0, x = 0; x < w; x++) {
       fb_buf_color(buf, x, y, &r, &g, &b);
       data[j++] = r;
       data[j++] = g;
       data[j++] = b;
     }
     png_write_rows(png_ptr, &data, 1);
   }

   png_write_end(png_ptr, info_ptr);

   printf("save screen.\n");

 END:
   if (png_ptr)
     png_destroy_write_struct(&png_ptr, (png_infopp) &info_ptr);

   if (info_ptr)
     png_destroy_info_struct(png_ptr, (png_infopp) &info_ptr);

   if (data)
     free(data);

   if (buf)
     free(buf);

   if(f)
     fclose(f);

   return 0;
}
