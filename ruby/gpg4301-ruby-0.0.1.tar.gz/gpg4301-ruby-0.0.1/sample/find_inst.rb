#! /usr/bin/ruby

require 'gpg4301'

GPG4301.open {|gpib|
  gpib.ifc.ren.find_listener.each {|adr|
    s = gpib.send(adr, "*IDN?").recv(adr)
    puts("#{adr}: #{s}")
  }
}
