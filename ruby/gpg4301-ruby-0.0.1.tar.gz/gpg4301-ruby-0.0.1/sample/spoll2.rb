require "gpg4301"

# for Agilent 53131A

ADDRESS = 5

GPG4301.open { |g|
  g.ifc.ren

  [
   "*RST",
   "*CLS",
   "*SRE 0",
   "*ESE 0",
   ":STAT:PRES",

   ":CALC3:AVERAGE ON",
   ":CALC3:AVERAGE:CONT 10",
   ":TRIG:COUNT:AUTO ON",
   "*ESE 1",
   "*SRE 32",
   "*OPC",
   ":INIT",
  ].each {|cmd|
    g.send(ADDRESS, cmd)
  }

  g.set_srq_event {
    g.spoll(ADDRESS).each {|s|
      printf("ADRS=%d, STB=0x%x\n", s[0], s[1])
    }
  }
  g.wait_srq_event(5000)

  g.send(ADDRESS, ":CALC3:AVERAGE:ALL?")
  puts(g.recv(ADDRESS))
}
