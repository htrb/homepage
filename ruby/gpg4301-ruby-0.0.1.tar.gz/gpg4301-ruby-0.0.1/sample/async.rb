require "gpg4301"

# for Agilent 53131A

ADDRESS = 5

Signal.trap("SIGALRM"){}

GPG4301.open { |g|
  g.ifc.ren
  g.async = true
  g.send(ADDRESS, "*CLS") {
    g.send(ADDRESS, ":STAT:PRES"){
      g.send(ADDRESS, ":SENS:FUNC 'FREQ 1'") {
        g.send(ADDRESS, ":SENS:FREQ:ARM:STOP:TIM 10") {
          g.send(ADDRESS, ":FETCH?") {
            g.recv(ADDRESS) {|s|
              puts(s)
              Process.kill("SIGALRM", Process.pid)
            }
          }
        }
      }
    }
  }
  sleep
}
puts("close")
