# $Id: extconf.rb,v 1.5 2008-03-03 10:13:24 hito Exp $
require 'mkmf'

GPG4301_EXCEPTION_SRC = "gpg4301_exception.h"
GPG4301_ASYNC_SRC = "gpg4301_async.h"
ASYNC_NUM = 32

$CFLAGS = "-Wall -O2"

have_header("pcigpib.h")

if (enable_config("test"))
  have_library("gpg4301t", "PciGpibExInitBoard")
else
  have_library("gpg4301", "PciGpibExInitBoard")
end

async_num = arg_config("--async_num", ASYNC_NUM).to_i


create_makefile("gpg4301")


File.open(GPG4301_EXCEPTION_SRC, "w") {|f|
  f.print <<-EOF
struct gpib_error {
  int errno;
  char *errstr;
  VALUE class;
};

static struct gpib_error Errors[] = {
EOF

  [
   "NOT_FOUND_LISTENER",
   "OK_SEND_STB",
   "NOT_EXEC_SPOLL",
   "NOT_ACTIVE_SRQ",
   "ACTIVE_SRQ",
   "OK_EOI_DETECT",
   "OK_RECV_DATA_CNT",
   "NORMAL_EXIT",
   "ERR_BRD_NO",
   "ERR_INP_PARAM",
   "ERR_PARAM_NO",
   "ERR_NOT_USE_NOSYS",
   "ERR_NOT_USE_SYS",
   "ERR_SEND_BUS_CMD",
   "ERR_NO_SET_SIGNAL",
   "ERR_NO_ACTIVE_SRQ",
   "ERR_RECV_STB_TIMEOUT",
   "ERR_DATA_RECV",
   "ERR_DATA_SEND",
   "ERR_TRANSFER_TIMEOUT",
   "ERR_WAIT_SIGNAL_TMO",
   "ERR_IFC_TRANS_EXIT",
   "ERR_NOT_CACS",
   "ERR_NOW_BUS_OCCUPATION",
   "ERR_NOT_SET",
   "ERR_FILE_ACCESS",
   "ERR_SET_EVENT",
   "ERR_INVALID_EVENT",
   "ERR_EVENT_WAIT_TIMEOUT",
   "ERR_WAIT_EVENT",
   "ERR_NOT_SET_EVENT",
   "ERR_NOT_SYS_CONTROLLER",
   "ERR_DRV_RETURN",
   "ERR_NOT_SUPPORT",
   "ERR_NO_BOARD",
  ].each {|s|
    f.print <<-EOF
  {
    #{s},
    "#{s}",
    Qnil,
  },
EOF
  }
  f.print <<-EOF
};
#define GPG4301_ERR_NUM (sizeof(Errors)/sizeof(*Errors))
EOF
}


File.open(GPG4301_ASYNC_SRC, "w") {|f|
  f.print <<-EOF
#define ASYNC_NUM #{async_num}

static struct async_recv_dev AsyncRecvDev[ASYNC_NUM], AsyncSendDev[ASYNC_NUM];

static void c_send_call_back(int dev);
static void c_recv_call_back(int dev);

EOF
  (0...async_num).each {|i|
    f.puts("static void c_recv_call_back_#{i}(void) {c_recv_call_back(#{i});}")
    f.puts("static void c_send_call_back_#{i}(void) {c_send_call_back(#{i});}")
  }
  f.puts("static void\ninit_async_cb(void)\n{")
  (0...async_num).each {|i|
    f.print <<-EOF

  AsyncSendDev[#{i}].cb = c_send_call_back_#{i};
  AsyncRecvDev[#{i}].cb = c_recv_call_back_#{i};
  AsyncRecvDev[#{i}].buf = NULL;
  AsyncRecvDev[#{i}].dev = NULL;
  AsyncRecvDev[#{i}].len = 0;
  AsyncRecvDev[#{i}].buf_size = 0;
EOF
  }
  f.puts("}")
}
