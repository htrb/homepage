#include <ruby.h>
#include <pcigpib.h>

#define ADDR_SIZE (31 * 31)
#define BUF_SIZE (1024 * 1024)
#define TMP_BUF_SUZE 1024
#define DEVICE_NUM 16

#define CONFIG_TMO    0
#define CONFIG_SRT    1
#define CONFIG_STM    2
#define CONFIG_SDELIM 3
#define CONFIG_RDELIM 4
#define CONFIG_ASYNC  5
#define CONFIG_MA     6
#define CONFIG_SA     7
#define CONFIG_HSTMG  8
#define CONFIG_PPETM  9

#define ASYNC_RECV_INIT   -1
#define ASYNC_RECV_FINISH -2

struct gpg4301 {
  int dev;
  char *buf;
  int buf_size;
  VALUE srq_proc, self;
  unsigned long len;
};

struct async_recv_dev {
  struct gpg4301 *dev;
  char *buf;
  int buf_size;
  unsigned long len;
  VALUE proc;
  void (* cb)(void);
};

#include "gpg4301_exception.h"
#include "gpg4301_async.h"

static char *Delim_str[] = {
  "NO",
  "EOI",
  "CR",
  "CR+EOI",
  "LF",
  "LF+EOI",
  "CRLF",
  "CRLF+EOI",
  "NULL",
  "ANY",
};

#define DELIM_NUM (sizeof(Delim_str)/sizeof(*Delim_str))
#define DELIM_ID_ANY 9

static VALUE GPG4301_Error, Unknown_Error, C_GPG4301;
static ID ID_call, ID_length, ID_delim[DELIM_NUM];
static struct gpg4301 *Device[DEVICE_NUM];

static void c_gpib_raise(int err);
static void c_get_adr_tbl(VALUE adr, int *adr_tbl);
static VALUE c_gpib_adr_func(VALUE self, VALUE adr, int (*func) (int, int *));
static VALUE c_gpib_set_void_func(VALUE self, int (*func) (int));
static VALUE c_gpib_get_pint_func(VALUE self, int (*func) (int, int *));
static VALUE c_gpib_get_puint_func(VALUE self, int (*func) (int, unsigned int *));
static VALUE c_gpib_set_int_func(VALUE self, VALUE val, int (*func) (int, int));
static VALUE c_gpib_set_uint_func(VALUE self, VALUE val, int (*func) (int, unsigned int));
static VALUE c_gpib_set_ulong_func(VALUE self, VALUE val, int (*func) (int, unsigned long));
static VALUE c_gpib_get_int_func(VALUE self, int (*func) (int));
static VALUE c_gpg4301_open(int dev, int res);
static void  c_gpg4301_close(struct gpg4301 *dev);
static void  c_gpg4301_free(struct gpg4301 *dev);
static VALUE rb_gpg4301_init_board(int argc, VALUE *argv, VALUE self);
static VALUE rb_gpg4301_finish_board(VALUE self);
static VALUE rb_gpg4301_get_device(VALUE self);
static VALUE rb_gpg4301_get_info(VALUE self, VALUE prm);
static VALUE rb_gpg4301_set_config(VALUE self, VALUE conf);
static VALUE rb_gpg4301_get_config(VALUE self, VALUE prm);
static VALUE rb_gpg4301_get_status(VALUE self);
static VALUE rb_gpg4301_clr_status(VALUE self, VALUE clear_stat);
static VALUE rb_gpg4301_get_bus_line(int argc, VALUE *argv, VALUE self);
static VALUE rb_gpg4301_send_data(int argc, VALUE *argv, VALUE self);
static VALUE rb_gpg4301_recv_data(int argc, VALUE *argv, VALUE self);
static VALUE rb_gpg4301_check_stb(VALUE self);
static VALUE rb_gpg4301_set_srq(VALUE self, VALUE stb);
static VALUE rb_gpg4301_set_ist(VALUE self, VALUE mode);
static VALUE rb_gpg4301_set_pp2(VALUE self, VALUE mode);
static VALUE rb_gpg4301_set_ifc(int argc, VALUE *argv, VALUE self);
static VALUE rb_gpg4301_set_ren(VALUE self);
static VALUE rb_gpg4301_reset_ren(VALUE self);
static VALUE rb_gpg4301_set_remote(VALUE self, VALUE adr);
static VALUE rb_gpg4301_set_rwls(VALUE self, VALUE adr);
static VALUE rb_gpg4301_re_sys_ctrl(VALUE self, VALUE mode);
static VALUE rb_gpg4301_exec_trigger(VALUE self, VALUE adr);
static VALUE rb_gpg4301_exec_dev_clear(VALUE self);
static VALUE rb_gpg4301_exec_sdc(VALUE self, VALUE adr);
static VALUE rb_gpg4301_set_local(VALUE self, VALUE adr);
static VALUE rb_gpg4301_set_llo(VALUE self);
static VALUE rb_gpg4301_exec_pass_ctrl(VALUE self, VALUE adr);
static VALUE rb_gpg4301_exec_find_listener(int argc, VALUE *argv, VALUE self);
static VALUE rb_gpg4301_exec_dev_reset(VALUE self, VALUE adr);
static VALUE rb_gpg4301_go_standby(VALUE self, VALUE mode);
static VALUE rb_gpg4301_go_act_ctrller(VALUE self, VALUE mode);
static VALUE rb_gpg4301_exec_spoll(VALUE self, VALUE adr);
static VALUE rb_gpg4301_check_srq(VALUE self);
static VALUE rb_gpg4301_clear_srq(VALUE self);
static VALUE rb_gpg4301_enable_srq(VALUE self);
static VALUE rb_gpg4301_disable_srq(VALUE self);
static VALUE rb_gpg4301_exec_ppoll(VALUE self);
static VALUE rb_gpg4301_cfg_ppoll(VALUE self, VALUE adr, VALUE ppe);
static VALUE rb_gpg4301_un_cfg_ppoll(VALUE self, VALUE adr);
static VALUE rb_gpg4301_write_bus_cmd(VALUE self, VALUE cmd);
static VALUE rb_gpg4301_send_file(VALUE self, VALUE adr, VALUE file);
static VALUE rb_gpg4301_recv_file(VALUE self, VALUE adr, VALUE file);
static VALUE rb_gpg4301_set_signal(VALUE self, VALUE signal, VALUE detect);
static VALUE rb_gpg4301_wait_signal(VALUE self);
static VALUE rb_gpg4301_set_srq_event(VALUE self);
static VALUE rb_gpg4301_wait_srq_event(VALUE self, VALUE timeout);
static VALUE rb_gpg4301_kill_srq_event(VALUE self);

#define GetDev(obj, device) {\
    Data_Get_Struct(obj, struct gpg4301, device);\
    if (device->dev < 0) c_gpib_raise(ERR_BRD_NO);\
  };


static void 
c_send_call_back(int dev)
{
  VALUE proc;

  if (AsyncSendDev[dev].dev == NULL) {
    return;
  }

  proc = AsyncSendDev[dev].proc;

  rb_funcall(proc, ID_call, 0);

  AsyncSendDev[dev].dev = NULL;
  /* Fix: don't have to free proc? */
}

static void 
c_recv_call_back(int dev)
{
  VALUE data, proc;

  if (AsyncRecvDev[dev].dev == NULL) {
    return;
  }

  data = rb_str_new(AsyncRecvDev[dev].buf, AsyncRecvDev[dev].len);
  proc = AsyncRecvDev[dev].proc;

  AsyncRecvDev[dev].len = AsyncRecvDev[dev].buf_size;
  AsyncRecvDev[dev].proc = 0;
  AsyncRecvDev[dev].dev = NULL;

  rb_funcall(proc, ID_call, 1, data);

  /* Fix: don't have to free proc? */
}

static int
find_recv_cb(struct gpg4301 *dev)
{
  int i;

  for (i = 0; i < ASYNC_NUM; i++) {
    if (AsyncRecvDev[i].dev == NULL) {
      AsyncRecvDev[i].dev = dev;
      if (AsyncRecvDev[i].buf == NULL) {
	AsyncRecvDev[i].buf = ruby_xmalloc(BUF_SIZE);
	AsyncRecvDev[i].buf_size = BUF_SIZE;
      }
      return i;
    }
  }

  return -1;
}

static int
find_send_cb(struct gpg4301 *dev)
{
  int i;

  for (i = 0; i < ASYNC_NUM; i++) {
    if (AsyncSendDev[i].dev == NULL) {
      AsyncSendDev[i].dev = dev;
      return i;
    }
  }

  return -1;
}

static void
c_gpib_raise(int err)
{
  int i;
  char *format = "GPG4301Error (errno = %d)";

  for (i = 0; i < GPG4301_ERR_NUM; i++) {
    if (Errors[i].errno == err) {
      rb_raise(Errors[i].class, format, err);
    }
  }
  rb_raise(Unknown_Error, format, err);
}

static void 
c_get_adr_tbl(VALUE adr, int *adr_tbl)
{
  int i, len;
  VALUE val;

  if (FIXNUM_P(adr)) {
    adr_tbl[0] = FIX2INT(adr);
    adr_tbl[1] = -1;
    return;
  }

  len = NUM2INT(rb_funcall(adr, ID_length, 0));

  if (len > ADDR_SIZE) {
    len = ADDR_SIZE;
  }

  for (i = 0; i < len; i++) {
    val = rb_ary_entry(adr, i);
    adr_tbl[i] = NUM2INT(val);
  }
  adr_tbl[len] = -1;
}

static VALUE
c_gpib_adr_func(VALUE self, VALUE adr, int (*func) (int, int *))
{
  int adr_tbl[ADDR_SIZE + 1], r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  c_get_adr_tbl(adr, adr_tbl);
  r = func(dev->dev, adr_tbl);
  if (r) {
    c_gpib_raise(r);
  }

  return self;
}

static VALUE
c_gpib_set_void_func(VALUE self, int (*func) (int))
{
  int r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = func(dev->dev);
  if (r) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE
c_gpib_set_int_func(VALUE self, VALUE val, int (*func) (int, int))
{
  int r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = func(dev->dev, NUM2INT(val));
  if (r < 0) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE
c_gpib_set_uint_func(VALUE self, VALUE val, int (*func) (int, unsigned int))
{
  int r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = func(dev->dev, NUM2UINT(val));
  if (r < 0) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE
c_gpib_set_ulong_func(VALUE self, VALUE val, int (*func) (int, unsigned long))
{
  int r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = func(dev->dev, NUM2ULONG(val));
  if (r < 0) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE
c_gpib_get_int_func(VALUE self, int (*func) (int))
{
  int r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = func(dev->dev);
  if (r < 0) {
    c_gpib_raise(r);
  }
  return INT2NUM(r);
}

static VALUE
c_gpib_get_pint_func(VALUE self, int (*func) (int, int *))
{
  int r, val;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = func(dev->dev, &val);
  if (r) {
    c_gpib_raise(r);
  }
  return INT2NUM(val);
}

static VALUE
c_gpib_get_puint_func(VALUE self, int (*func) (int, unsigned int *))
{
  int r;
  unsigned int val;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = func(dev->dev, &val);
  if (r) {
    c_gpib_raise(r);
  }
  return UINT2NUM(val);
}

static VALUE
c_gpg4301_open(int dev, int res)
{
  VALUE obj;
  int r;
  struct gpg4301 *device;

  if (dev < 0 || dev >= DEVICE_NUM || Device[dev]) {
    c_gpib_raise(ERR_BRD_NO);
  }

  r = PciGpibExInitBoard(dev, res);
  if (r) {
    c_gpib_raise(r);
  }
  obj = Data_Make_Struct(C_GPG4301, struct gpg4301, NULL, c_gpg4301_free, device);
  Device[dev] = device;
  device->buf = ruby_xmalloc(BUF_SIZE);
  device->buf_size = BUF_SIZE;
  device->self = obj;
  device->len = 0;

  return obj;
}

static VALUE 
c_gpg4301_init_board(int argc, VALUE *argv, VALUE self)
{
  VALUE obj_gpg4301;
  VALUE dev, res;
  int i;

  i = rb_scan_args(argc, argv, "02", &dev, &res);
  switch (i) {
  case 0:
    dev = INT2FIX(0);
  case 1:
    res = INT2FIX(0);
  }

  obj_gpg4301 = c_gpg4301_open(NUM2INT(dev), NUM2INT(res));

  return obj_gpg4301;
}

static VALUE 
rb_gpg4301_new(int argc, VALUE *argv, VALUE self)
{
  if (rb_block_given_p()) {
    char *cname = rb_class2name(self);

    rb_warn("%s::new() does not take block; use %s::open() instead",
	    cname, cname);
  }
  return c_gpg4301_init_board(argc, argv, self);
}

static VALUE 
rb_gpg4301_init_board(int argc, VALUE *argv, VALUE self)
{
  VALUE obj_gpg4301;

  obj_gpg4301 = c_gpg4301_init_board(argc, argv, self);

  if (rb_block_given_p()) {
    return rb_ensure(rb_yield, obj_gpg4301, rb_gpg4301_finish_board, obj_gpg4301);
  }

  return obj_gpg4301;
}

static void
c_free_async_recv_buf(int i)
{
  char *ptr;

  AsyncRecvDev[i].dev = NULL;
  ptr = AsyncRecvDev[i].buf;
  AsyncRecvDev[i].buf = NULL;
  if (ptr) {
    free(ptr);
  }
  AsyncRecvDev[i].len = 0;
  AsyncRecvDev[i].buf_size = 0;
  AsyncRecvDev[i].proc = 0;
}

static void
c_gpg4301_free(struct gpg4301 *dev)
{
  int i;

  for (i = 0; i < ASYNC_NUM; i++) {
   if (AsyncRecvDev[i].dev == dev) {
     c_free_async_recv_buf(i);
   }
  }

  if (dev) {
    Device[dev->dev] = NULL;
    if (dev->dev >= 0) {
      c_gpg4301_close(dev);
    }
    if (dev->buf) {
      ruby_xfree(dev->buf);
    }
    free(dev);
  }

  for (i = 0; i < DEVICE_NUM; i++) {
    if (Device[i])
      return;
  }

  for (i = 0; i < ASYNC_NUM; i++) {
    c_free_async_recv_buf(i);
  }
}

static void
c_gpg4301_close(struct gpg4301 *dev)
{
  if (dev->dev >= 0) {
    PciGpibExFinishBoard(dev->dev);
  }
  if (dev->buf) {
    ruby_xfree(dev->buf);
    dev->buf = NULL;
    dev->buf_size = 0;
  }
  dev->dev = -1;
}

static VALUE 
rb_gpg4301_finish_board(VALUE self)
{
  struct gpg4301 *dev;
  GetDev(self, dev);
  c_gpg4301_close(dev);
  return self;
}

static VALUE 
rb_gpg4301_get_device(VALUE self)
{
  struct gpg4301 *dev;

  GetDev(self, dev);
  return INT2NUM(dev->dev);
}

static VALUE 
rb_gpg4301_get_info(VALUE self, VALUE prm)
{
  int r;
  unsigned long rprm;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = PciGpibExGetInfo(dev->dev, NUM2INT(prm), &rprm);
  if (r) {
    c_gpib_raise(r);
  }
  return INT2NUM(rprm);
}

static VALUE 
rb_gpg4301_set_config(VALUE self, VALUE conf)
{
  char *ptr;
  int r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  ptr = StringValuePtr(conf);
  r = PciGpibExSetConfig(dev->dev, ptr);
  if (r) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE
c_gpg4301_set_delim(int type, int argc, VALUE *argv, VALUE self)
{
  VALUE delim_chr, delim;
  char c = '\0', *ptr, buf[TMP_BUF_SUZE];
  int i;

  i = rb_scan_args(argc, argv, "11", &delim, &delim_chr);

  if (i == 2 && strcmp(Delim_str[DELIM_ID_ANY], StringValuePtr(delim)) == 0) {
    ptr = StringValuePtr(delim_chr);
    c = ptr[0];
    if (c == '\0') {
      delim = rb_str_new2("NULL");
    }
  }

  if (c == '\0') {
    snprintf(buf, sizeof(buf), "/%cDELIM=%s", (type) ? 'S': 'R', StringValuePtr(delim));
  } else {
    snprintf(buf, sizeof(buf), "/%cDELIM=!%c", (type) ? 'S': 'R', c);
  }

  return rb_gpg4301_set_config(self, rb_str_new2(buf));
}

static VALUE
c_gpg4301_get_delim(int type, VALUE self)
{
  VALUE rval;
  int val;

  rval = rb_gpg4301_get_config(self, INT2FIX((type) ? CONFIG_RDELIM: CONFIG_SDELIM));
  val = FIX2INT(rval);
  if (val >= 0 && val < DELIM_NUM) {
    return rb_str_new2(Delim_str[val]);
  }

  return Qnil;
}

static VALUE
rb_gpg4301_set_delim(int argc, VALUE *argv, VALUE self)
{
  c_gpg4301_set_delim(0, argc, argv, self);
  c_gpg4301_set_delim(1, argc, argv, self);
  return self;
}

static VALUE
rb_gpg4301_get_delim(VALUE self)
{
  VALUE rval;
  rval = rb_ary_new();
  rb_ary_push(rval, c_gpg4301_get_delim(0, self));
  rb_ary_push(rval, c_gpg4301_get_delim(1, self));

  return rval;
}

static VALUE
rb_gpg4301_set_sdelim(int argc, VALUE *argv, VALUE self)
{
  c_gpg4301_set_delim(0, argc, argv, self);
  return self;
}

static VALUE
rb_gpg4301_get_sdelim(VALUE self)
{
  return c_gpg4301_get_delim(1, self);
}

static VALUE
rb_gpg4301_set_rdelim(int argc, VALUE *argv, VALUE self)
{
  c_gpg4301_set_delim(1, argc, argv, self);
  return self;
}

static VALUE
rb_gpg4301_get_rdelim(VALUE self)
{
  return c_gpg4301_get_delim(1, self);
}

static VALUE
rb_gpg4301_set_async(VALUE self, VALUE flag)
{
  char *cmd_str;

  if (RTEST(flag)) {
    cmd_str = "/ASYNC=ON";
  } else {
    cmd_str = "/ASYNC=OFF";
  }

  return rb_gpg4301_set_config(self, rb_str_new2(cmd_str));
}

static VALUE
rb_gpg4301_get_async(VALUE self)
{
  VALUE rval;
  int val;

  rval = rb_gpg4301_get_config(self, INT2FIX(CONFIG_ASYNC));
  val = FIX2INT(rval);
  if (val) {
    return Qtrue;
  } else {
    return Qfalse;
  }

  return Qfalse;
}

static VALUE
rb_gpg4301_set_timeout(VALUE self, VALUE tmo)
{
  char buf[TMP_BUF_SUZE];

  snprintf(buf, sizeof(buf), "/TMO=%d", NUM2INT(tmo));

  return rb_gpg4301_set_config(self, rb_str_new2(buf));
}

static VALUE
rb_gpg4301_get_timeout(VALUE self)
{
  VALUE rval;

  rval = rb_gpg4301_get_config(self, INT2FIX(CONFIG_TMO));

  return rval;
}

static VALUE
rb_gpg4301_set_myaddress(VALUE self, VALUE adr)
{
  char buf[TMP_BUF_SUZE];

  snprintf(buf, sizeof(buf), "/MA=%d", NUM2INT(adr));

  return rb_gpg4301_set_config(self, rb_str_new2(buf));
}

static VALUE
rb_gpg4301_get_myaddress(VALUE self)
{
  VALUE rval;

  rval = rb_gpg4301_get_config(self, INT2FIX(CONFIG_MA));
  return rval;
}

static VALUE 
rb_gpg4301_get_config(VALUE self, VALUE prm)
{
  int r;
  unsigned long rprm;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = PciGpibExGetConfig(dev->dev, FIX2INT(prm), &rprm);
  if (r) {
    c_gpib_raise(r);
  }
  return ULONG2NUM(rprm);
}

static VALUE 
rb_gpg4301_get_status(VALUE self)
{
  return c_gpib_get_puint_func(self, PciGpibExGetStatus);
}

static VALUE 
rb_gpg4301_clr_status(VALUE self, VALUE clear_stat)
{
  return c_gpib_set_uint_func(self, clear_stat, PciGpibExClrStatus);
}

static VALUE 
rb_gpg4301_get_bus_line(int argc, VALUE *argv, VALUE self)
{
  int r;
  unsigned int bus;
  VALUE resv;
  struct gpg4301 *dev;

  r = rb_scan_args(argc, argv, "01", &resv);

  GetDev(self, dev);
  r = PciGpibExGetBusLine(dev->dev, &bus, 0);
  if (r) {
    c_gpib_raise(r);
  }
  return INT2NUM(bus);
}

static VALUE 
rb_gpg4301_send_data(int argc, VALUE *argv, VALUE self)
{
  void *cb;
  VALUE adr, data, len;
  int adr_tbl[ADDR_SIZE + 1], l, r, i = -1;
  char *ptr;
  struct gpg4301 *dev;

  GetDev(self, dev);

  r = rb_scan_args(argc, argv, "2", &adr, &data);

  if (rb_block_given_p()) {
    if (RTEST(rb_gpg4301_get_async(self))) {
      i = find_send_cb(dev);
      if (i < 0) {
	rb_raise(GPG4301_Error, "too many async call.");
      }
      AsyncSendDev[i].proc = rb_block_proc();
      cb = AsyncSendDev[i].cb;
    } else {
      rb_warn("async mode is disabled.");
      cb = NULL;
    }
  } else {
    cb = NULL;
  }

  c_get_adr_tbl(adr, adr_tbl);

  StringValue(data);
  len = rb_funcall(data, ID_length, 0);
  l = NUM2INT(len);
  ptr = StringValuePtr(data);

  r = PciGpibExSendData(dev->dev, adr_tbl, l, ptr, cb);
  if (r) {
    if (cb && i >= 0) {
      AsyncRecvDev[i].proc = 0;
      AsyncRecvDev[i].dev = NULL;
    }
    c_gpib_raise(r);
  }

  return self;
}

static VALUE 
rb_gpg4301_recv_data(int argc, VALUE *argv, VALUE self)
{
  void *cb;
  VALUE adr, data = 0;
  int adr_tbl[ADDR_SIZE + 1], r, i = -1, buf_size;
  char *buf;
  unsigned long *len;
  struct gpg4301 *dev;

  GetDev(self, dev);

  r = rb_scan_args(argc, argv, "1", &adr);

  if (rb_block_given_p()) {
    if (RTEST(rb_gpg4301_get_async(self))) {
      i = find_recv_cb(dev);
      if (i < 0) {
	rb_raise(GPG4301_Error, "too many async call.");
      }

      AsyncRecvDev[i].proc = rb_block_proc();
      buf = AsyncRecvDev[i].buf;
      buf_size = AsyncRecvDev[i].buf_size;
      len = &(AsyncRecvDev[i].len);
      cb = AsyncRecvDev[i].cb;
    } else {
      rb_warn("async mode is disabled.");
      buf = dev->buf;
      buf_size = dev->buf_size;
      len = &(dev->len);
      cb = NULL;
    }
  } else {
    buf = dev->buf;
    buf_size = dev->buf_size;
    len = &(dev->len);
    cb = NULL;
  }

  c_get_adr_tbl(adr, adr_tbl);

  while (1) {
    *len = buf_size;

    r = PciGpibExRecvData(dev->dev, adr_tbl, len, buf, cb);
    switch (r) {
    case OK_RECV_DATA_CNT:
    case NORMAL_EXIT:
    case OK_EOI_DETECT:
      if (cb == NULL){
	if (data) {
	  rb_str_cat(data, buf, *len);
	} else {
	  data = rb_str_new(buf, *len);
	}
	if (r == OK_RECV_DATA_CNT) {
	  continue;
	}
      }
      break;
    default:
      if (cb && i >= 0) {
	AsyncRecvDev[i].proc = 0;
	AsyncRecvDev[i].dev = NULL;
      }
      c_gpib_raise(r);
    }

    break;
  }

  return (cb) ? self: data;
}

static VALUE 
rb_gpg4301_check_stb(VALUE self)
{
  VALUE r;

  r = c_gpib_get_int_func(self, PciGpibExCheckStb);
  switch (NUM2INT(r)) {
  case OK_SEND_STB:
    return Qtrue;
  case NOT_EXEC_SPOLL:
    return Qfalse;
  default:
    c_gpib_raise(r);
  }

  return Qnil;
}

static VALUE 
rb_gpg4301_set_srq(VALUE self, VALUE stb)
{
  return c_gpib_set_int_func(self, stb, PciGpibExSetSrq);
}

static VALUE 
rb_gpg4301_set_ist(VALUE self, VALUE mode)
{
  int r, ist;
  struct gpg4301 *dev;

  GetDev(self, dev);

  if (RTEST(mode)) {
    ist = 1;
  } else {
    ist = 0;
  }

  r = PciGpibExSetIst(dev->dev, ist);
  if (r) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE 
rb_gpg4301_set_pp2(VALUE self, VALUE mode)
{
  int r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = PciGpibExSetPp2(dev->dev, NUM2INT(mode));
  if (r) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE 
rb_gpg4301_set_ifc(int argc, VALUE *argv, VALUE self)
{
  int r, i;
  VALUE timeout;
  struct gpg4301 *dev;

  GetDev(self, dev);

  i = rb_scan_args(argc, argv, "01", &timeout);
  if (i < 1) {
    timeout = INT2FIX(10);
  }
  r = PciGpibExSetIfc(dev->dev, NUM2INT(timeout));
  if (r) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE 
rb_gpg4301_set_ren(VALUE self)
{
  return c_gpib_set_void_func(self, PciGpibExSetRen);
}

static VALUE 
rb_gpg4301_reset_ren(VALUE self)
{
  return c_gpib_set_void_func(self, PciGpibExResetRen);
}

static VALUE 
rb_gpg4301_set_remote(VALUE self, VALUE adr)
{
  return c_gpib_adr_func(self, adr, PciGpibExSetRemote);
}

static VALUE 
rb_gpg4301_set_rwls(VALUE self, VALUE adr)
{
  return c_gpib_adr_func(self, adr, PciGpibExSetRwls);
}

static VALUE 
rb_gpg4301_re_sys_ctrl(VALUE self, VALUE mode)
{
  int cmode;

  if (RTEST(mode)) {
    cmode = 1;
  } else {
    cmode = 0;
  }

  return c_gpib_set_int_func(self, INT2FIX(cmode), PciGpibExReSysCtrl);
}

static VALUE 
rb_gpg4301_exec_trigger(VALUE self, VALUE adr)
{
  return c_gpib_adr_func(self, adr, PciGpibExExecTrigger);
}

static VALUE 
rb_gpg4301_exec_dev_clear(VALUE self)
{
  return c_gpib_set_void_func(self, PciGpibExExecDevClear);
}

static VALUE 
rb_gpg4301_exec_sdc(VALUE self, VALUE adr)
{
  return c_gpib_adr_func(self, adr, PciGpibExExecSdc);
}

static VALUE 
rb_gpg4301_set_local(VALUE self, VALUE adr)
{
  return c_gpib_adr_func(self, adr, PciGpibExSetLocal);
}

static VALUE 
rb_gpg4301_set_llo(VALUE self)
{
  return c_gpib_set_void_func(self, PciGpibExSetLlo);
}

static VALUE 
rb_gpg4301_exec_pass_ctrl(VALUE self, VALUE adr)
{
  return c_gpib_adr_func(self, adr, PciGpibExExecPassCtrl);
}

static VALUE 
rb_gpg4301_exec_find_listener(int argc, VALUE *argv, VALUE self)
{
  VALUE addr, ary;
  int i, j, addr_tbl[ADDR_SIZE + 1], find_tbl[ADDR_SIZE + 1], n, r, my, a;
  struct gpg4301 *dev;

  i = rb_scan_args(argc, argv, "01", &addr);
  if (i) {
    c_get_adr_tbl(addr, addr_tbl);
  } else {
    my = FIX2INT(rb_gpg4301_get_myaddress(self));
    for (a = j = 0; j < 32; j++) {
      if (j == my) {
	a = 1;
	continue;
      }
      addr_tbl[j - a] = j;
    }
    addr_tbl[j - a] = -1;
  }

  GetDev(self, dev);
  r = PciGpibExExecFindListener (dev->dev, addr_tbl, find_tbl, &n);
  switch (r) {
  case NOT_FOUND_LISTENER:
    return Qnil;
  case NORMAL_EXIT:
    break;
  default:
    c_gpib_raise(r);
  }

  ary = rb_ary_new();
  for (i = 0; i < n; i++) {
    j = find_tbl[i];
    if (j < 0) break;
    rb_ary_push(ary, INT2FIX(j));
  }

  return ary;
}

static VALUE 
rb_gpg4301_exec_dev_reset(VALUE self, VALUE adr)
{
  return c_gpib_adr_func(self, adr, PciGpibExExecDevReset);
}

static VALUE 
rb_gpg4301_go_standby(VALUE self, VALUE mode)
{
  return c_gpib_set_int_func(self, mode, PciGpibExGoStandby);
}

static VALUE 
rb_gpg4301_go_act_ctrller(VALUE self, VALUE mode)
{
  return c_gpib_set_int_func(self, mode, PciGpibExGoActCtrller);
}

static VALUE 
rb_gpg4301_exec_spoll(VALUE self, VALUE adr)
{
  int i, adr_tbl[ADDR_SIZE + 1], srq_adr_tbl[ADDR_SIZE + 1], srq_tbl[ADDR_SIZE + 1], r;
  struct gpg4301 *dev;
  VALUE rval, srq_data;

  GetDev(self, dev);
  c_get_adr_tbl(adr, adr_tbl);
  r = PciGpibExExecSpoll(dev->dev, adr_tbl, srq_tbl, srq_adr_tbl);
  if (r) {
    c_gpib_raise(r);
  }

  rval = rb_ary_new();

  for (i = 0; srq_adr_tbl[i] > 0; i++) {
    if (i >= ADDR_SIZE) break;
    srq_data = rb_ary_new3(2, INT2NUM(srq_adr_tbl[i]), INT2NUM(srq_tbl[i]));
    rb_ary_push(rval, srq_data);
  }

  return rval;
}

static VALUE 
rb_gpg4301_check_srq(VALUE self)
{
  int r;

  r = c_gpib_get_int_func(self, PciGpibExCheckSrq);
  switch (NUM2INT(r)) {
  case ACTIVE_SRQ:
    return Qtrue;
  case NOT_ACTIVE_SRQ:
    return Qfalse;
  default:
    c_gpib_raise(r);
  }

  return Qnil;
}

static VALUE 
rb_gpg4301_clear_srq(VALUE self)
{
  return c_gpib_set_void_func(self, PciGpibExClearSrq);
}

static VALUE
rb_gpg4301_set_srq_state(VALUE self, VALUE mode)
{
  VALUE rval;
  if (RTEST(mode)) {
    rval = rb_gpg4301_enable_srq(self);
  } else {
    rval = rb_gpg4301_disable_srq(self);
  }
  return rval;
}

static VALUE 
rb_gpg4301_enable_srq(VALUE self)
{
  return c_gpib_set_void_func(self, PciGpibExEnableSrq);
}

static VALUE 
rb_gpg4301_disable_srq(VALUE self)
{
  return c_gpib_set_void_func(self, PciGpibExDisableSrq);
}

static VALUE 
rb_gpg4301_exec_ppoll(VALUE self)
{
  return c_gpib_get_pint_func(self, PciGpibExExecPpoll);
}

static VALUE 
rb_gpg4301_cfg_ppoll(VALUE self, VALUE adr, VALUE ppe)
{
  int adr_tbl[ADDR_SIZE + 1], r;
  struct gpg4301 *dev;

  GetDev(self, dev);

  c_get_adr_tbl(adr, adr_tbl);
  r = PciGpibExCfgPpoll(dev->dev, adr_tbl,  FIX2INT(ppe));
  if (r) {
    c_gpib_raise(r);
  }

  return self;
}

static VALUE 
rb_gpg4301_un_cfg_ppoll(VALUE self, VALUE adr)
{
  return c_gpib_adr_func(self, adr, PciGpibExUnCfgPpoll);
}

static VALUE 
rb_gpg4301_write_bus_cmd(VALUE self, VALUE cmd)
{
#define CMD_TBL_SIZE 255
  int cmd_tbl[CMD_TBL_SIZE + 1], len, len2, i, j, r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  len = NUM2INT(rb_funcall(cmd, ID_length, 0));
  len2 = len / CMD_TBL_SIZE + 1;

  for (j = 0; j < len2; j++) {
    for (i = 0; i < CMD_TBL_SIZE; i++) {
      cmd_tbl[i] = rb_ary_entry(cmd, i);
      len--;
      if (len < 1) {
	break;
      }
    }
    cmd_tbl[i + 1] = -1;
    r = PciGpibExWriteBusCmd(dev->dev, cmd_tbl);
    if (r) {
      c_gpib_raise(r);
    }
  }
  return self;
}

static VALUE 
rb_gpg4301_send_file(VALUE self, VALUE adr, VALUE file)
{
  int adr_tbl[ADDR_SIZE + 1], r;
  struct gpg4301 *dev;

  GetDev(self, dev);

  c_get_adr_tbl(adr, adr_tbl);
  r = PciGpibExSendFile(dev->dev, adr_tbl,  StringValuePtr(file));
  if (r) {
    c_gpib_raise(r);
  }

  return self;
}

static VALUE 
rb_gpg4301_recv_file(VALUE self, VALUE adr, VALUE file)
{
  int adr_tbl[ADDR_SIZE + 1], r;
  unsigned long len;
  struct gpg4301 *dev;

  GetDev(self, dev);

  c_get_adr_tbl(adr, adr_tbl);
  len = dev->buf_size;
  r = PciGpibExRecvFile(dev->dev, adr_tbl, &len, StringValuePtr(file));
  if (r) {
    c_gpib_raise(r);
  }

  return self;
}

static VALUE 
rb_gpg4301_set_signal(VALUE self, VALUE signal, VALUE detect)
{
  int r;
  struct gpg4301 *dev;

  GetDev(self, dev);
  r = PciGpibExSetSignal(dev->dev, NUM2UINT(signal), NUM2INT(detect));
  if (r < 0) {
    c_gpib_raise(r);
  }
  return INT2NUM(r);
}

static VALUE 
rb_gpg4301_wait_signal(VALUE self)
{
  return c_gpib_get_puint_func(self, PciGpibExWaitSignal);
}

void 
c_set_srq_event_cb(int device, unsigned long user)
{
  VALUE self = (VALUE) user;
  struct gpg4301 *dev;

  GetDev(self, dev);
  rb_funcall(dev->srq_proc, ID_call, 0);
}

static VALUE 
rb_gpg4301_set_srq_event(VALUE self)
{
  int r;
  struct gpg4301 *dev;

  if (! rb_block_given_p()) {
    c_gpib_raise(ERR_SET_EVENT);
  }

  GetDev(self, dev);
  dev->srq_proc = rb_block_proc();

  r = PciGpibExSetSrqEvent(dev->dev, c_set_srq_event_cb, (unsigned long) self);
  if (r < 0) {
    c_gpib_raise(r);
  }
  return self;
}

static VALUE 
rb_gpg4301_wait_srq_event(VALUE self, VALUE timeout)
{
  return c_gpib_set_ulong_func(self, timeout, PciGpibExWaitSrqEvent);
}

static VALUE 
rb_gpg4301_kill_srq_event(VALUE self)
{
  return c_gpib_set_void_func(self, PciGpibExKillSrqEvent);
}

void 
Init_gpg4301(void)
{
  int i;

  C_GPG4301 = rb_define_class("GPG4301", rb_cObject);

  rb_define_singleton_method(C_GPG4301, "new", rb_gpg4301_new, -1);
  rb_define_singleton_method(C_GPG4301, "open", rb_gpg4301_init_board, -1);
  rb_define_singleton_method(C_GPG4301, "init_board", rb_gpg4301_init_board, -1);

  rb_define_method(C_GPG4301, "close", rb_gpg4301_finish_board, 0);
  rb_define_method(C_GPG4301, "finish_board", rb_gpg4301_finish_board, 0);
  rb_define_method(C_GPG4301, "device", rb_gpg4301_get_device, 0);
  rb_define_method(C_GPG4301, "get_info", rb_gpg4301_get_info, 1);
  rb_define_method(C_GPG4301, "set_config", rb_gpg4301_set_config, 1);
  rb_define_method(C_GPG4301, "get_config", rb_gpg4301_get_config, 1);
  rb_define_method(C_GPG4301, "my_address", rb_gpg4301_get_myaddress, 0);
  rb_define_method(C_GPG4301, "get_my_address", rb_gpg4301_get_myaddress, 0);
  rb_define_method(C_GPG4301, "my_address=", rb_gpg4301_set_myaddress, 1);
  rb_define_method(C_GPG4301, "set_my_address", rb_gpg4301_set_myaddress, 1);
  rb_define_method(C_GPG4301, "get_status", rb_gpg4301_get_status, 0);
  rb_define_method(C_GPG4301, "status", rb_gpg4301_get_status, 0);
  rb_define_method(C_GPG4301, "clr_status", rb_gpg4301_clr_status, 1);
  rb_define_method(C_GPG4301, "get_bus_line", rb_gpg4301_get_bus_line, -1);
  rb_define_method(C_GPG4301, "bus_line", rb_gpg4301_get_bus_line, -1);
  rb_define_method(C_GPG4301, "send_data", rb_gpg4301_send_data, -1);
  rb_define_method(C_GPG4301, "send", rb_gpg4301_send_data, -1);
  rb_define_method(C_GPG4301, "recv_data", rb_gpg4301_recv_data, -1);
  rb_define_method(C_GPG4301, "recv", rb_gpg4301_recv_data, -1);
  rb_define_method(C_GPG4301, "check_stb", rb_gpg4301_check_stb, 0);
  rb_define_method(C_GPG4301, "stb?", rb_gpg4301_check_stb, 0);
  rb_define_method(C_GPG4301, "set_srq", rb_gpg4301_set_srq, 1);
  rb_define_method(C_GPG4301, "srq=", rb_gpg4301_set_srq, 1);
  rb_define_method(C_GPG4301, "set_ist", rb_gpg4301_set_ist, 1);
  rb_define_method(C_GPG4301, "ist=", rb_gpg4301_set_ist, 1);
  rb_define_method(C_GPG4301, "set_pp2", rb_gpg4301_set_pp2, 1);
  rb_define_method(C_GPG4301, "pp2=", rb_gpg4301_set_pp2, 1);
  rb_define_method(C_GPG4301, "set_ifc", rb_gpg4301_set_ifc, -1);
  rb_define_method(C_GPG4301, "ifc", rb_gpg4301_set_ifc, -1);
  rb_define_method(C_GPG4301, "set_ren", rb_gpg4301_set_ren, 0);
  rb_define_method(C_GPG4301, "ren", rb_gpg4301_set_ren, 0);
  rb_define_method(C_GPG4301, "reset_ren", rb_gpg4301_reset_ren, 0);
  rb_define_method(C_GPG4301, "set_remote", rb_gpg4301_set_remote, 1);
  rb_define_method(C_GPG4301, "remote", rb_gpg4301_set_remote, 1);
  rb_define_method(C_GPG4301, "set_rwls", rb_gpg4301_set_rwls, 1);
  rb_define_method(C_GPG4301, "rwls", rb_gpg4301_set_rwls, 1);
  rb_define_method(C_GPG4301, "re_sys_ctrl", rb_gpg4301_re_sys_ctrl, 1);
  rb_define_method(C_GPG4301, "exec_trigger", rb_gpg4301_exec_trigger, 1);
  rb_define_method(C_GPG4301, "trigger", rb_gpg4301_exec_trigger, 1);
  rb_define_method(C_GPG4301, "exec_dev_clear", rb_gpg4301_exec_dev_clear, 0);
  rb_define_method(C_GPG4301, "dev_clear", rb_gpg4301_exec_dev_clear, 0);
  rb_define_method(C_GPG4301, "exec_sdc", rb_gpg4301_exec_sdc, 1);
  rb_define_method(C_GPG4301, "sdc", rb_gpg4301_exec_sdc, 1);
  rb_define_method(C_GPG4301, "set_local", rb_gpg4301_set_local, 1);
  rb_define_method(C_GPG4301, "local", rb_gpg4301_set_local, 1);
  rb_define_method(C_GPG4301, "set_llo", rb_gpg4301_set_llo, 0);
  rb_define_method(C_GPG4301, "llo", rb_gpg4301_set_llo, 0);
  rb_define_method(C_GPG4301, "exec_pass_ctrl", rb_gpg4301_exec_pass_ctrl, 1);
  rb_define_method(C_GPG4301, "pass_ctrl", rb_gpg4301_exec_pass_ctrl, 1);
  rb_define_method(C_GPG4301, "exec_find_listener", rb_gpg4301_exec_find_listener, -1);
  rb_define_method(C_GPG4301, "find_listener", rb_gpg4301_exec_find_listener, -1);
  rb_define_method(C_GPG4301, "exec_dev_reset", rb_gpg4301_exec_dev_reset, 1);
  rb_define_method(C_GPG4301, "dev_reset", rb_gpg4301_exec_dev_reset, 1);
  rb_define_method(C_GPG4301, "go_standby", rb_gpg4301_go_standby, 1);
  rb_define_method(C_GPG4301, "standby", rb_gpg4301_go_standby, 1);
  rb_define_method(C_GPG4301, "go_act_ctrller", rb_gpg4301_go_act_ctrller, 1);
  rb_define_method(C_GPG4301, "act_ctrller", rb_gpg4301_go_act_ctrller, 1);
  rb_define_method(C_GPG4301, "exec_spoll", rb_gpg4301_exec_spoll, 1);
  rb_define_method(C_GPG4301, "spoll", rb_gpg4301_exec_spoll, 1);
  rb_define_method(C_GPG4301, "check_srq", rb_gpg4301_check_srq, 0);
  rb_define_method(C_GPG4301, "srq?", rb_gpg4301_check_srq, 0);
  rb_define_method(C_GPG4301, "clear_srq", rb_gpg4301_clear_srq, 0);
  rb_define_method(C_GPG4301, "enable_srq", rb_gpg4301_enable_srq, 0);
  rb_define_method(C_GPG4301, "disable_srq", rb_gpg4301_disable_srq, 0);
  rb_define_method(C_GPG4301, "srq=", rb_gpg4301_set_srq_state, 1);
  rb_define_method(C_GPG4301, "exec_ppoll", rb_gpg4301_exec_ppoll, 0);
  rb_define_method(C_GPG4301, "ppoll", rb_gpg4301_exec_ppoll, 0);
  rb_define_method(C_GPG4301, "cfg_ppoll", rb_gpg4301_cfg_ppoll, 2);
  rb_define_method(C_GPG4301, "un_cfg_ppoll", rb_gpg4301_un_cfg_ppoll, 1);
  rb_define_method(C_GPG4301, "write_bus_cmd", rb_gpg4301_write_bus_cmd, 1);
  rb_define_method(C_GPG4301, "send_file", rb_gpg4301_send_file, 2);
  rb_define_method(C_GPG4301, "recv_file", rb_gpg4301_recv_file, 2);
  rb_define_method(C_GPG4301, "set_signal", rb_gpg4301_set_signal, 2);
  rb_define_method(C_GPG4301, "wait_signal", rb_gpg4301_wait_signal, 0);
  rb_define_method(C_GPG4301, "set_srq_event", rb_gpg4301_set_srq_event, 0);
  rb_define_method(C_GPG4301, "wait_srq_event", rb_gpg4301_wait_srq_event, 1);
  rb_define_method(C_GPG4301, "kill_srq_event", rb_gpg4301_kill_srq_event, 0);

  rb_define_method(C_GPG4301, "set_timeout", rb_gpg4301_set_timeout, 1);
  rb_define_method(C_GPG4301, "timeout=", rb_gpg4301_set_timeout, 1);
  rb_define_method(C_GPG4301, "get_timeout", rb_gpg4301_get_timeout, 0);
  rb_define_method(C_GPG4301, "timeout", rb_gpg4301_get_timeout, 0);

  /*
  rb_define_method(C_GPG4301, "set_srt", rb_gpg4301_set_srt, 1);
  rb_define_method(C_GPG4301, "srt=", rb_gpg4301_set_srt, 1);
  rb_define_method(C_GPG4301, "get_srt", rb_gpg4301_get_srt, 0);
  rb_define_method(C_GPG4301, "srt", rb_gpg4301_get_srt, 0);

  rb_define_method(C_GPG4301, "set_stm", rb_gpg4301_set_stm, 1);
  rb_define_method(C_GPG4301, "stm=", rb_gpg4301_set_stm, 1);
  rb_define_method(C_GPG4301, "get_stm", rb_gpg4301_get_stm, 0);
  rb_define_method(C_GPG4301, "stm", rb_gpg4301_get_stm, 0);
  */

  rb_define_method(C_GPG4301, "set_delim", rb_gpg4301_set_delim, -1);
  rb_define_method(C_GPG4301, "delim=", rb_gpg4301_set_delim, -1);
  rb_define_method(C_GPG4301, "get_delim", rb_gpg4301_get_delim, 0);
  rb_define_method(C_GPG4301, "delim", rb_gpg4301_get_delim, 0);

  rb_define_method(C_GPG4301, "set_sdelim", rb_gpg4301_set_sdelim, -1);
  rb_define_method(C_GPG4301, "sdelim=", rb_gpg4301_set_sdelim, -1);
  rb_define_method(C_GPG4301, "get_sdelim", rb_gpg4301_get_sdelim, 0);
  rb_define_method(C_GPG4301, "sdelim", rb_gpg4301_get_sdelim, 0);

  rb_define_method(C_GPG4301, "set_rdelim", rb_gpg4301_set_rdelim, -1);
  rb_define_method(C_GPG4301, "rdelim=", rb_gpg4301_set_rdelim, -1);
  rb_define_method(C_GPG4301, "get_rdelim", rb_gpg4301_get_rdelim, 0);
  rb_define_method(C_GPG4301, "rdelim", rb_gpg4301_get_rdelim, 0);

  rb_define_method(C_GPG4301, "set_async", rb_gpg4301_set_async, 1);
  rb_define_method(C_GPG4301, "async=", rb_gpg4301_set_async, 1);
  rb_define_method(C_GPG4301, "get_async", rb_gpg4301_get_async, 0);
  rb_define_method(C_GPG4301, "async?", rb_gpg4301_get_async, 0);

  for (i = 0; i < DELIM_NUM; i++) {
    char buf[TMP_BUF_SUZE], *ptr;

    snprintf(buf, sizeof(buf), "DELIM_%s", Delim_str[i]);
    ptr = strchr(buf, '+');
    if (ptr) {
      *ptr= '_';
    }
    rb_define_const(C_GPG4301, buf, rb_str_new2(Delim_str[i]));
    ID_delim[i] = rb_intern(buf);
  }

  rb_define_const(C_GPG4301, "BUS_LINE_ATN",  INT2FIX(1 << 15));
  rb_define_const(C_GPG4301, "BUS_LINE_DAV",  INT2FIX(1 << 14));
  rb_define_const(C_GPG4301, "BUS_LINE_NDAC", INT2FIX(1 << 13));
  rb_define_const(C_GPG4301, "BUS_LINE_NRFD", INT2FIX(1 << 12));
  rb_define_const(C_GPG4301, "BUS_LINE_EOI",  INT2FIX(1 << 11));
  rb_define_const(C_GPG4301, "BUS_LINE_SRQ",  INT2FIX(1 << 10));
  rb_define_const(C_GPG4301, "BUS_LINE_IFC",  INT2FIX(1 << 9));
  rb_define_const(C_GPG4301, "BUS_LINE_REN",  INT2FIX(1 << 8));

  rb_define_const(C_GPG4301, "BUS_STATUS_IFC",          UINT2NUM(1 << 31));
  rb_define_const(C_GPG4301, "BUS_STATUS_SRQ",          UINT2NUM(1 << 30));
  rb_define_const(C_GPG4301, "BUS_STATUS_SPOLL",        UINT2NUM(1 << 29));
  rb_define_const(C_GPG4301, "BUS_STATUS_DEV_TRG",      UINT2NUM(1 << 28));
  rb_define_const(C_GPG4301, "BUS_STATUS_DEV_CLR",      UINT2NUM(1 << 27));
  rb_define_const(C_GPG4301, "BUS_STATUS_RECV",         UINT2NUM(1 << 26));
  rb_define_const(C_GPG4301, "BUS_STATUS_LISTENER",     UINT2NUM(1 << 25));
  rb_define_const(C_GPG4301, "BUS_STATUS_TALKER",       UINT2NUM(1 << 24));
  rb_define_const(C_GPG4301, "BUS_STATUS_INOUT",        UINT2NUM(1 << 23));
  rb_define_const(C_GPG4301, "BUS_STATUS_REMOTE",       UINT2NUM(1 << 22));
  rb_define_const(C_GPG4301, "BUS_STATUS_LOCKOUT",      UINT2NUM(1 << 21));
  rb_define_const(C_GPG4301, "BUS_STATUS_DELIM",        UINT2NUM(1 << 20));
  rb_define_const(C_GPG4301, "BUS_STATUS_CIC",          UINT2NUM(1 << 19));
  rb_define_const(C_GPG4301, "BUS_STATUS_ATN",          UINT2NUM(1 << 18));
  rb_define_const(C_GPG4301, "BUS_STATUS_ASYNC_ERROR",  UINT2NUM(1 << 17));

  rb_define_const(C_GPG4301, "CONFIG_TMO",    INT2FIX(CONFIG_TMO));
  rb_define_const(C_GPG4301, "CONFIG_STM",    INT2FIX(CONFIG_STM));
  rb_define_const(C_GPG4301, "CONFIG_SDELIM", INT2FIX(CONFIG_SDELIM));
  rb_define_const(C_GPG4301, "CONFIG_RDELIM", INT2FIX(CONFIG_RDELIM));
  rb_define_const(C_GPG4301, "CONFIG_ASYNC",  INT2FIX(CONFIG_ASYNC));
  rb_define_const(C_GPG4301, "CONFIG_MA",     INT2FIX(CONFIG_MA));
  rb_define_const(C_GPG4301, "CONFIG_SA",     INT2FIX(CONFIG_SA));
  rb_define_const(C_GPG4301, "CONFIG_HSTMG",  INT2FIX(CONFIG_HSTMG));
  rb_define_const(C_GPG4301, "CONFIG_PPETM",  INT2FIX(CONFIG_PPETM));

  ID_length = rb_intern("length");
  ID_call = rb_intern("call");

  GPG4301_Error = rb_define_class("GPG4301Error", rb_eStandardError);

  for (i = 0; i < GPG4301_ERR_NUM; i++) {
    Errors[i].class =  rb_define_class(Errors[i].errstr, GPG4301_Error);
  }
  Unknown_Error = rb_define_class("UNKNOWN_ERROR", GPG4301_Error);

  init_async_cb();
}

