require 'mkmf'

have_header("libpafe/libpafe.h")
have_library("usb", "usb_init")
have_library("pafe", "pasori_open")
create_makefile("pasori")
