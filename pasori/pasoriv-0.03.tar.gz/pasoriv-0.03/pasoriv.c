#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define DESCRIPTION "" \
"PaSoRi (RC-S320) Viewer (version %.2f) based on\n" \
"  http://wiki.osdev.info/index.php?PaSoRi%%2FRC-S320\n" \
"and\n" \
"  JIS X 6319-4\n" \
"\n" \
"To build and run it, you need libusb:\n" \
"  http://libusb.sourceforge.net\n"

#include "pasoriv.h"

static struct ids {
  unsigned short vid;
  unsigned short pid;
} pasoriv_idv[] = {
  {0x54c, 0x1bb},
}, *idv = pasoriv_idv;

#ifndef USB_BUS_PREFIX
#ifdef __linux__ /* ??? */
#define USB_BUS_PREFIX "/proc/bus/usb/"
#else
#define USB_BUS_PREFIX ""
#endif
#endif

#ifndef USB_DEVS_MAX
#define USB_DEVS_MAX (64)
#endif

static char *me;
static int save_errno;
static char usb_bus_prefix[FILENAME_MAX + sizeof("")] = USB_BUS_PREFIX;
static int usb_bus_prefix_len = sizeof(USB_BUS_PREFIX) - sizeof("");
static char usb_bus_dirname[FILENAME_MAX + sizeof("")];
static char usb_dev_filename[FILENAME_MAX + sizeof("")];
static int usb_last_dev;
static int nids = sizeof(pasoriv_idv) / sizeof(pasoriv_idv[0]);
static int usb_timeout = 100; /* 0.1sec */
static int usb_try_again_interval = 100; /* 0.1sec */
static int usb_try_again_max = 3;
static int verbose = 1;
static int debug_libusb;
static int usb_initialized;
static struct usb_dev_handle *h;
static struct usb_device *dev, *devv[USB_DEVS_MAX];
static int ndevs;
static struct usb_interface_descriptor *uid;
static struct usb_endpoint_descriptor *epdv;
static u_int8_t interrupt_in;
static int in_pktsize;
static int polling_try_again_max = 0;

static void
pasoriv_perror(const char *msg)
{
  fprintf(stderr, "%s: %s (errno == %d) / %s\n", msg, strerror(save_errno), save_errno, usb_strerror());
  fflush(stderr);
}

static void
hexdump(const unsigned char *beginning, const unsigned char *e, FILE *out)
{
  const unsigned char *b;

  for (b = beginning ; b < e ; ++b) {
    if (b > beginning) {
      putc(' ', out);

      if (!((b - beginning) % 4))
	putc(' ', out);
    }

    fprintf(out, "%02X", *b);
  }
}

enum {
  pasoriv_error_system = -1,
  pasoriv_error_badlength = -2,
  pasoriv_error_nodev = -3,
  pasoriv_error_nopipe = -4,
  pasoriv_error_nak = -5,
  pasoriv_error_brokenpkt = -5,
  pasoriv_error_shortpkt = -7,
  pasoriv_error_unexpectedpkt = -8,
  pasoriv_error_optphasediffer = -9,
  pasoriv_error_optnotfound = -10,
  pasoriv_error_wrongoption = -11,
};

static int
pasoriv_rawwrite(unsigned char *p, int len)
{
  unsigned char *b, *e;
  int l, m, n;

  for (b = p, e = b + len ; b < e ;) {
    l = e - b;

    if (verbose >= 3) {
      fprintf(stderr, "pasoriv_rawwrite(): usb_control_msg(): try %d octets: \"", l);
      hexdump(b, b + l, stderr);
      fputs("\"\n", stderr);
      fflush(stderr);
    }

    for (m = usb_try_again_max ; (n = usb_control_msg(h, USB_TYPE_VENDOR, 0, 0, 0, b, l, usb_timeout)) < 0 ;) {
      save_errno = errno;

      if (verbose >= 2)
	pasoriv_perror("pasoriv_rawwrite(): usb_control_msg()");

      if (save_errno == EINTR)
	;
      else if (save_errno == EAGAIN) {
	if (--m > 0)
	  usleep(usb_try_again_interval * 1000);
	else
	  return pasoriv_error_system;
      }
      else
	return pasoriv_error_system;
    }

    if (verbose >= 3) {
      fprintf(stderr, "pasoriv_rawwrite(): usb_control_msg(): written %d octets: \"", n);
      hexdump(b, b + n, stderr);
      fputs("\"\n", stderr);
      fflush(stderr);
    }

    b += n;
  }

  return 0;
}

static int
pasoriv_rawread(unsigned char *p, int size_max, int size_min)
{
  int size, n, m, l = 0;

  for (size = size_max ; size > 0 && l < size_min ;) {
    for (m = usb_try_again_max ; (n = usb_interrupt_read(h, interrupt_in, p + l, size <= in_pktsize ? size : in_pktsize, usb_timeout)) < 0 ;) {
      save_errno = errno;

      if (verbose >= 2)
	pasoriv_perror("usb_interrupt_read()");

      if (save_errno == EINTR)
	;
      else if (save_errno == EAGAIN) {
	if (--m > 0)
	  usleep(usb_try_again_interval * 1000);
	else
	  return pasoriv_error_system;
      }
      else
	return pasoriv_error_system;
    }

    if (verbose >= 3) {
      fprintf(stderr, "pasoriv_rawread(%d, %d): %d .. %d: \"", size_max, size_min, l, l + n);
      hexdump(p + l, p + l + n, stderr);
      fputs("\"\n", stderr);
      fflush(stderr);
    }

    size -= n;
    l += n;
  }

  return l;
}

static unsigned char preamble[] = {PASORIV_PREAMBLE};
static unsigned char ack[] = {PASORIV_PREAMBLE, 0x00, 0xFF, PASORIV_POSTAMBLE};
static unsigned char nak[] = {PASORIV_PREAMBLE, 0xFF, 0x00, PASORIV_POSTAMBLE};

static int
pasoriv_send_ack(void)
{
  return pasoriv_rawwrite(ack, sizeof(ack));
}

static int
pasoriv_send_nak(void)
{
  return pasoriv_rawwrite(nak, sizeof(nak));
}

#ifndef PASORIV_BUFSIZE
#define PASORIV_BUFSIZE (PASORIV_PKT_SIZE_MIN + sizeof("\x00\x00\x00") - sizeof("") + PASORIV_PKT_MBR_LEN_MAX)
#endif /* !defined(PASORIV_BUFSIZE) */

static unsigned char usb_i_buffer[PASORIV_BUFSIZE], usb_o_buffer[PASORIV_BUFSIZE];

static int
pasoriv_write_pkt(unsigned char *p, int len)
{
  unsigned char *b, *e, *d;
  int sum;

  if (len < 0 || len > PASORIV_PKT_MBR_LEN_MAX) {
    if (verbose) {
      fprintf(stderr, "pasoriv_write_pkt(): requested size (%d) ", len);

      if (len < 0)
	fprintf(stderr, "> max (%d)\n", PASORIV_PKT_MBR_LEN_MAX);
      else
	fputs("< 0\n", stderr);

      fflush(stderr);
    }

    return pasoriv_error_badlength;
  }

  if (verbose >= 3) {
    fputs("pasoriv_write_pkt(p=\"", stderr);
    hexdump(p, p + len, stderr);
    fprintf(stderr, "\", len=%d)\n", len);
    fflush(stderr);
  }

  memcpy(usb_o_buffer, preamble, sizeof(preamble));
  usb_o_buffer[pasoriv_pkt_mbr_len] = len;
  usb_o_buffer[pasoriv_pkt_mbr_lmod] = 0x100 - len;

  for (sum = 0, b = p, e = p + len, d = usb_o_buffer + pasoriv_pkt_mbr_data ; b < e ;) {
    sum = (sum + *b) & 0xFF;
    *d++ = *b++;
  }

  *d++ = 0x100 - sum;
  *d++ = PASORIV_POSTAMBLE;
  return pasoriv_rawwrite(usb_o_buffer, d - usb_o_buffer);
}

static int
pasoriv_read_pkt(unsigned char *buf, int size)
{
  int n, m, l, k, sum;
  unsigned char *b, *e, *db, *de;

  for (;;) {
    n = pasoriv_rawread(usb_i_buffer, size, sizeof(ack));

    if (n < 0)
      return n;
    else if (n == sizeof(ack) && !memcmp(usb_i_buffer, ack, sizeof(ack)))
      continue;
    else if (n == sizeof(nak) && !memcmp(usb_i_buffer, nak, sizeof(nak))) {
      if (verbose) {
	fputs("pasoriv_read_pkt(): NAK received\n", stderr);
	fflush(stderr);
      }

      return pasoriv_error_nak;
    }
    else if (n < PASORIV_PKT_SIZE_MIN || memcmp(usb_i_buffer, preamble, sizeof(preamble))) {
      if (verbose) {
	fprintf(stderr, "pasoriv_read_pkt(): broken preamble (%d octets): \"", n);
	hexdump(usb_i_buffer, usb_i_buffer + n, stderr);
	fputs("\"\n", stderr);
	fflush(stderr);
      }

      return pasoriv_error_brokenpkt;
    }

    m = usb_i_buffer[pasoriv_pkt_mbr_len];

    if (usb_i_buffer[pasoriv_pkt_mbr_lmod] != 0x100 - m) {
      if (verbose) {
	fprintf(stderr, "pasoriv_read_pkt(): broken length checksum (expected==0x%02X, received==0x%02X)\n",
		0x100 - m, usb_i_buffer[pasoriv_pkt_mbr_lmod]);
	fflush(stderr);
      }

      return pasoriv_error_brokenpkt;
    }

    for (l = n, k = pasoriv_pkt_mbr_data + m + 1 + PASORIV_POSTAMBLE_LEN ; l < k ;)
      if ((n = pasoriv_rawread(usb_i_buffer + l, k - l, k - l)) < 0)
	return n;
      else if (!n) {
	if (verbose) {
	  fprintf(stderr, "pasord_read_pkt(): short packet (expected length==%d, received==%d)\n", k, l);
	  fflush(stderr);
	}

	return pasoriv_error_shortpkt;
      }
      else
	l += n;

    for (sum = 0, b = usb_i_buffer + pasoriv_pkt_mbr_data, e = b + m, db = buf, de = db + size ; b < e ;) {
      if (db < de)
	*db++ = *b;

      sum = (sum + *b++) & 0xFF;
    }

    if (*e != 0x100 - sum) {
      if (verbose) {
	fprintf(stderr, "pasoriv_read_pkt(): broken checksum (expected==0x%02X, received==0x%02X)\n", 0x100 - sum, *e);
	fflush(stderr);
      }

      return pasoriv_error_brokenpkt;
    }

    return db - buf;
  }
}

static void
pasoriv_shutdown_usb(void)
{
  if (h) {
    if (epdv) {
      usb_release_interface(h, uid->bInterfaceNumber);
      epdv = NULL;
    }

    usb_close(h);
    h = NULL;
    uid = NULL;
    in_pktsize = 0;
  }
}

static void
pasoriv_setup_device_path(const char *path, char *dbuf, int dbuf_size, char *fbuf, int fbuf_size)
{
  const char *slash;
  int n;

  if (*path && usb_bus_prefix_len > 0 && !strncmp(usb_bus_prefix, path, usb_bus_prefix_len)) {
    path += usb_bus_prefix_len;

    while (*path == '/')
      ++path;
  }

  if ((slash = (const char *)strrchr(path, '/'))) {
    if ((n = slash - path) > dbuf_size - sizeof(""))
      n = dbuf_size - sizeof("");

    memcpy(dbuf, path, n);
    dbuf[n] = '\0';
    path = slash + 1;
  }
  else
    dbuf[0] = '\0';

  if ((n = strlen(path)) > fbuf_size - sizeof(""))
    n = fbuf_size - sizeof("");

  memcpy(fbuf, path, n);
  fbuf[n] = '\0';
}

static struct usb_device *
pasoriv_usb_dev_match_p(struct usb_device *ret, const char *dirname, const char *filename)
{
  if (ret &&
      (!*dirname || !strcmp(ret->bus->dirname, dirname)) &&
      (!*filename || !strcmp(ret->filename, filename)))
    return ret;

  return NULL;
}

static int
pasoriv_init_usb(void)
{
  struct usb_bus *busses, *bus;
  int i;

  if (!usb_initialized) {
    if (debug_libusb)
      usb_set_debug(debug_libusb);

    usb_init();
    usb_initialized = 1;
  }

  if (dev)
    return 0;

  usb_find_busses();
  usb_find_devices();

  for (busses = usb_get_busses(), i = ndevs = 0 ; i < nids ; ++i)
    for (bus = busses ; bus ; bus = bus->next)
      for (dev = bus->devices ; dev ; dev = dev->next)
	if (dev->descriptor.idVendor == idv[i].vid &&
	    (!idv[i].pid || dev->descriptor.idProduct == idv[i].pid) &&
	    ndevs < sizeof(devv) / sizeof(devv[0]))
	  devv[ndevs++] = dev;

  if (ndevs > 0) {
    if (usb_last_dev) {
      for (i = ndevs ; i > 0 ;)
	if ((dev = pasoriv_usb_dev_match_p(devv[--i], usb_bus_dirname, usb_dev_filename)))
	  return 0;
    }
    else {
      for (i = 0 ; i < ndevs ;)
	if ((dev = pasoriv_usb_dev_match_p(devv[i++], usb_bus_dirname, usb_dev_filename)))
	  return 0;
    }
  }
  else
    dev = NULL;

  return pasoriv_error_nodev;
}

static void
pasoriv_show_device(struct usb_device *dev, FILE *out)
{
  if (dev)
    fprintf(out, "Dev#=%d Vendor=0x%04X ProdID=0x%04X Path=%s/%s\n",
	    dev->devnum,
	    dev->descriptor.idVendor, dev->descriptor.idProduct,
	    dev->bus->dirname, dev->filename);
  else
    fputs("No PaSoRi device found\n", out);

  fflush(out);
}

static unsigned char init0[] = {pasoriv_pcmd_init, 0x01, 0x82};
static unsigned char init0_res[] = {pasoriv_pcmd_init_res, 0x00, 0x88};
static unsigned char init1[] = {pasoriv_pcmd_init, 0x02, 0x80, 0x81};
static unsigned char init1_res[] = {pasoriv_pcmd_init_res, 0x00, 0xcc, 0x88};
static unsigned char init2[] = {pasoriv_pcmd_init, 0x22, 0x80, 0xcc, 0x81, 0x88};
static unsigned char init2_res[] = {pasoriv_pcmd_init_res, 0x00};
static unsigned char init3[] = {pasoriv_pcmd_init, 0x02, 0x80, 0x81};
static unsigned char init3_res[] = {pasoriv_pcmd_init_res, 0x00, 0xcc, 0x88};
static unsigned char init4[] = {pasoriv_pcmd_init, 0x02, 0x82, 0x87};
static unsigned char init4_res[] = {pasoriv_pcmd_init_res, 0x00, 0x88, 0x01};
static unsigned char init5[] = {pasoriv_pcmd_init, 0x21, 0x25, 0x58};
static unsigned char init5_res[] = {pasoriv_pcmd_init_res, 0x00};
static unsigned char reset[] = {pasoriv_pcmd_reset};
static unsigned char reset_res[] = {pasoriv_pcmd_reset_res, 0x00};
static unsigned char iostart[] = {pasoriv_pcmd_iostart, 0x80};
static unsigned char iostart_res[] = {pasoriv_pcmd_iostart_res, 0x00};

static struct {
  unsigned char *req;
  int req_len;
  unsigned char *res;
  int res_len_match;
} initv[] = {
  {init0, sizeof(init0), init0_res, 2},
  {init1, sizeof(init1), init1_res, 2},
  {init2, sizeof(init2), init2_res, sizeof(init2_res)},
  {init3, sizeof(init3), init3_res, sizeof(init3_res)},
  {init4, sizeof(init4), init4_res, sizeof(init4_res)},
  {init5, sizeof(init5), init5_res, sizeof(init5_res)},
  {reset, sizeof(reset), reset_res, sizeof(reset_res)},
  {iostart, sizeof(iostart), iostart_res, sizeof(iostart_res)},
  {NULL, 0, NULL, 0},
};

#undef NINITS
#define NINITS (sizeof(initv) / sizeof(initv[0]))

/* init1 causes 0x7F response from firmware of version 1.40
 * -- No, this is becuase of my fault (last 0x81 was missing in init1)
 */
static unsigned char skipv[NINITS];

static int
pasoriv_start(void)
{
  int n, i;
  unsigned char ibuf[PASORIV_PKT_MBR_LEN_MAX];

  if ((n = pasoriv_init_usb()) < 0)
    return n;

  if (!(h = usb_open(dev))) {
    save_errno = errno;

    if (verbose)
      pasoriv_perror("usb_open()");

    return pasoriv_error_system;
  }

  if (usb_set_configuration(h, dev->config->bConfigurationValue) < 0) {
    save_errno = errno;

    if (verbose)
      pasoriv_perror("usb_set_configuration()");

    pasoriv_shutdown_usb();
    return pasoriv_error_system;
  }

  uid = dev->config->interface->altsetting;

  if (usb_claim_interface(h, uid->bInterfaceNumber) < 0) {
    save_errno = errno;

    if (verbose)
      pasoriv_perror("usb_claim_interface()");

    pasoriv_shutdown_usb();
    return pasoriv_error_system;
  }

  epdv = uid->endpoint;

  for (i = 0 ; i < uid->bNumEndpoints ; ++i)
    switch (epdv[i].bmAttributes & USB_ENDPOINT_TYPE_MASK) {
    case USB_ENDPOINT_TYPE_INTERRUPT:
      if ((epdv[i].bEndpointAddress & USB_ENDPOINT_DIR_MASK) == USB_ENDPOINT_IN) {
	interrupt_in = epdv[i].bEndpointAddress;
	in_pktsize = epdv[i].wMaxPacketSize;
      }
    default:
      break;
    }

  if (!in_pktsize) {
    pasoriv_shutdown_usb();

    if (verbose) {
      fputs("An interrupt in pipe required\n", stderr);
      fflush(stderr);
    }

    return pasoriv_error_nopipe;
  }

  for (i = 0 ; initv[i].req ; ++i)
    if (!skipv[i]) {
      if ((n = pasoriv_write_pkt(initv[i].req, initv[i].req_len)) < 0)
	return n;

      if ((n = pasoriv_read_pkt(ibuf, sizeof(ibuf))) < 0)
	return n;

      if (n < initv[i].res_len_match || memcmp(ibuf, initv[i].res, initv[i].res_len_match)) {
	if (verbose) {
	  fprintf(stderr, "pasori_start(): init#%d: expected=\"", i);
	  hexdump(initv[i].res, initv[i].res + initv[i].res_len_match, stderr);
	  fputs("\" received=\"", stderr);

	  if (n > initv[i].res_len_match) {
	    hexdump(ibuf, ibuf + initv[i].res_len_match, stderr);
	    putc('[', stderr);
	    hexdump(ibuf + initv[i].res_len_match, ibuf + n, stderr);
	    putc(']', stderr);
	  }
	  else
	    hexdump(ibuf, ibuf + n, stderr);

	  fputs("\"\n", stderr);
	  fflush(stderr);
	}

	return pasoriv_error_unexpectedpkt;
      }
    }

  return 0;
}

static int
pasoriv_firmver(int *major, int *minor)
{
  static unsigned char firmver[] = {pasoriv_pcmd_firmware_version};
  unsigned char firmver_res[PASORIV_PKT_MBR_LEN_MAX];
  int n;

  if ((n = pasoriv_write_pkt(firmver, sizeof(firmver))) < 0)
    return n;

  if ((n = pasoriv_read_pkt(firmver_res, sizeof(firmver_res))) < 0)
    return n;

  if (n != 3 || firmver_res[0] != pasoriv_pcmd_firmware_version_res) {
    pasoriv_send_nak();

    if (verbose) {
      fputs("pasori_firmver(): unexpected response: \"", stderr);
      hexdump(firmver_res, firmver_res + n, stderr);
      fputs("\"\n", stderr);
      fflush(stderr);
    }

    return pasoriv_error_unexpectedpkt;
  }
  else {
    pasoriv_send_ack();
    *major = firmver_res[2];
    *minor = firmver_res[1];
    return 0;
  }
}

static int
pasoriv_write_fcmd(unsigned char *p, int len)
{
  unsigned char req[PASORIV_PKT_MBR_LEN_MAX];

  if (len > sizeof(req) - 1 - 1) {
    if (verbose) {
      fprintf(stderr, "pasoriv_write_fcmd(): requested size (%d) > max (%d)\n", len, PASORIV_PKT_MBR_LEN_MAX);
      fflush(stderr);
    }

    return pasoriv_error_badlength;
  }

  req[0] = pasoriv_pcmd_fcmd;
  req[1] = len + 1;
  memcpy(req + 2, p, len);
  return pasoriv_write_pkt(req, len + 2);
}

static int
pasoriv_read_fcmd(unsigned char *buf, int size)
{
  unsigned char res[PASORIV_PKT_MBR_LEN_MAX];
  int n;

  if ((n = pasoriv_read_pkt(res, sizeof(res))) < 0)
    return n;

  if (n < 2 || res[0] != pasoriv_pcmd_fcmd_res) {
    pasoriv_send_nak();

    if (verbose) {
      fputs("pasoriv_read_fcmd(): unexpected response: \"", stderr);
      hexdump(res, res + n, stderr);
      fputs("\"\n", stderr);
      fflush(stderr);
    }

    return pasoriv_error_unexpectedpkt;
  }
  else if (res[1] != n - 1) {
    if (verbose) {
      fputs("pasoriv_read_fcmd(): broken response: \"", stderr);
      hexdump(res, res + n, stderr);
      fputs("\"\n", stderr);
      fflush(stderr);
    }

    return pasoriv_error_brokenpkt;
  }

  if (size > n - 2)
    size = n - 2;

  memcpy(buf, res + 2, size);
  return size;
}

static unsigned char polling[pasoriv_poll_cmdlen] = {pasoriv_fcmd_polling, 0xFF, 0xFF};

#define IDm_LEN (8)
#define PMm_LEN (8)

static int
pasoriv_polling(unsigned char *idm, unsigned char *pmm)
{
  unsigned char polling_res[PASORIV_FCMD_RES_MAX];
  int n, m;

  for (m = polling_try_again_max ;;) {
    if ((n = pasoriv_write_fcmd(polling, sizeof(polling))) < 0)
      return n;

    if ((n = pasoriv_read_fcmd(polling_res, sizeof(polling_res))) < 0) {
      if (n == pasoriv_error_system && save_errno == EAGAIN && m != 1) {
	if (m > 1)
	  --m;

	continue;
      }
      else
	return n;
    }

    if (verbose >= 3) {
      fprintf(stderr, "pasoriv_polling(): %d octets: \"", n);
      hexdump(polling_res, polling_res + n, stderr);
      fputs("\"\n", stderr);
      fflush(stderr);
    }

    if (polling_res[0] != pasoriv_fcmd_polling_res || n != 1 + IDm_LEN + PMm_LEN) {
      pasoriv_send_nak();

      if (verbose) {
	fputs("pasori_polling(): unexpected response: \"", stderr);
	hexdump(polling_res, polling_res + n, stderr);
	fputs("\"\n", stderr);
	fflush(stderr);
      }

      return pasoriv_error_unexpectedpkt;
    }

    break;
  }

  pasoriv_send_ack();
  memcpy(idm, polling_res + 1, IDm_LEN);
  memcpy(pmm, polling_res + 1 + IDm_LEN, PMm_LEN);
  return 0;
}

static int
f_opt_do(char *opt, void *fdata, int nth)
{
  if (strtol(opt, NULL, 0))
    *(int *)fdata = nth + 1;
  else
    *(int *)fdata = 0;

  return 0;
}

static int
f_opt_done(char *opt, void *fdata, int nth)
{
  if (strtol(opt, NULL, 0))
    *(int *)fdata = -1;

  return 0;
}

static void
f_optf(char *opt, unsigned char *iv, int iv_len, unsigned char *pv, int pv_len, unsigned char *s, int s_len)
{
  int i;

  for (; *opt ; ++opt)
    if (*opt == '%')
      switch (*++opt) {
      case 'I':
	if (!iv)
	  goto asis;

	hexdump(iv, iv + iv_len, stdout);
	break;
      case 'i':
	if (!iv)
	  goto asis;

	for (i = 0 ; i < iv_len ;)
	  printf("%02x", iv[i++]);

	break;
      case 'P':
	if (!pv)
	  goto asis;

	hexdump(pv, pv + pv_len, stdout);
	break;
      case 'p':
	if (!pv)
	  goto asis;

	for (i = 0 ; i < pv_len ;)
	  printf("%02x", pv[i++]);

	break;
      case 'H':
	if (!s)
	  goto asis;

	hexdump(s, s + s_len, stdout);
	break;
      case 'h':
	if (!s)
	  goto asis;

	for (i = 0 ; i < s_len ;)
	  printf("%02x", s[i++]);

	break;
      case 's':
	if (!s)
	  goto asis;

	fwrite(s, 1, s_len, stdout);
	break;
      case 'n':
	putchar('\n');
	break;
      case '\0':
	putchar('%');
	return;
      asis:
      default:
	putchar(*opt);
	break;
      }
    else
      putchar(*opt);

  putchar('\n');
  fflush(stdout);
}

static unsigned char last_idm[IDm_LEN], last_idm_p;

static int
f_opt_poll(char *opt, void *fdata, int nth)
{
  int ret;
  unsigned char pmm[PMm_LEN];

  if (!(ret = pasoriv_polling(last_idm, pmm))) {
    last_idm_p = 1;
    f_optf(opt, last_idm, sizeof(last_idm), pmm, sizeof(pmm), NULL, 0);
  }

  return ret;
}

static int
f_opt_initv(char *opt, void *fdata, int nth)
{
  int i;
  unsigned char *skipv;

  skipv = fdata;

  for (i = 0 ; opt[i] && i < NINITS ; ++i)
    if (strchr("1OoYyTt", opt[i]))
      skipv[i] = 0;
    else if (strchr("0XxNnFf", opt[i]))
      skipv[i] = 1;

  return 0;
}

static int
f_opt_status(char *opt, void *fdata, int nth)
{
  printf(opt, *(int *)fdata);
  putchar('\n');
  return 0;
}

static int
f_opt_atoi(char *opt, void *fdata, int nth)
{
  *(int *)fdata = strtol(opt, NULL, 0);
  return 0;
}

static int
f_opt_recv(char *opt, void *fdata, int nth)
{
  int n, (*f)(unsigned char *, int);
  unsigned char res[PASORIV_PKT_MBR_LEN_MAX];

  f = (int (*)(unsigned char *, int))fdata;

  if ((n = f(res, sizeof(res))) > 0)
    f_optf(opt, NULL, 0, NULL, 0, res, n);

  return n;
}

static int
f_opt_send(char *opt, void *fdata, int nth)
{
  int n, (*f)(unsigned char *, int);
  unsigned char req[PASORIV_PKT_MBR_LEN_MAX], *p;

  f = (int (*)(unsigned char *, int))fdata;

  for (p = opt, n = 0 ; *p && n < sizeof(req) ; ++p)
    if (*p == '%') {
      int i;
      unsigned char c;

      for (c = 0, i = 2 ; i > 0 ; --i) {
	switch (*++p) {
	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
	  c = c * 16 + (*p - '0');
	  continue;
	case 'A':
	case 'B':
	case 'C':
	case 'D':
	case 'E':
	case 'F':
	  c = c * 16 + (*p - 'A') + 10;
	  continue;
	case 'a':
	case 'b':
	case 'c':
	case 'd':
	case 'e':
	case 'f':
	  c = c * 16 + (*p - 'a') + 10;
	  continue;
	default:
	  if (!*p) {
	    req[n++] = '%';
	    goto eoreq;
	  }

	  c = *p;
	  break;
	}

	break;
      }

      req[n++] = c;
    }
    else
      req[n++] = *p;
eoreq:
  if (n > 0)
    n = f(req, n);

  return n;
}

static int
f_opt_sendhex(char *opt, void *fdata, int nth)
{
  int i, n, (*f)(unsigned char *, int);
  unsigned char req[PASORIV_PKT_MBR_LEN_MAX], *p, c;

  f = (int (*)(unsigned char *, int))fdata;

  for (c = 0, p = opt, i = n = 0 ; *p && n < sizeof(req) ; ++p) {
    switch (*p) {
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
      c = c * 16 + (*p - '0');
      break;
    case 'A':
    case 'B':
    case 'C':
    case 'D':
    case 'E':
    case 'F':
      c = c * 16 + (*p - 'A') + 10;
      break;
    case 'a':
    case 'b':
    case 'c':
    case 'd':
    case 'e':
    case 'f':
      c = c * 16 + (*p - 'a') + 10;
      break;
    default:
      if (i) {
	req[n++] = c;
	c = i = 0;
      }

      continue;
    }

    if (++i >= 2) {
      req[n++] = c;
      c = i = 0;
    }
  }

  if (n > 0)
    n = f(req, n);

  return n;
}

static int
f_opt_version(char *opt, void *fdata, int nth)
{
  if (strtol(opt, NULL, 0)) {
    fprintf(stderr, "%s %.2f\n", me, VERSION);
    fflush(stderr);
  }

  return 0;
}

static int
f_opt_busprefix(char *opt, void *fdata, int nth)
{
  int n;

  if (*opt && *opt != '/') {
    if (verbose) {
      fprintf(stderr, "f_opt_bufprefix(\"%s\"): must be absolute path\n", opt);
      fflush(stderr);
    }

    return pasoriv_error_wrongoption;
  }

  if ((n = strlen(opt)) > sizeof(usb_bus_prefix) - sizeof(""))
    n = sizeof(usb_bus_prefix) - sizeof("");

  memcpy(usb_bus_prefix, opt, n);
  usb_bus_prefix[n] = '\0';
  usb_bus_prefix_len = n;
  return n;
}

static int
f_opt_timeslots(char *opt, void *fdata, int nth)
{
  int i, j;

  i = strtol(opt, NULL, 0);

  for (j = 0x01 ; j < PASORIV_POLL_TIMESLOTS_MAX ; j <<= 1)
    if (i <= j)
      break;

  polling[pasoriv_poll_timeslot] = j - 1;
  return 0;
}

static int
f_opt_devicepath(char *opt, void *fdata, int nth)
{
  pasoriv_setup_device_path(opt, usb_bus_dirname, sizeof(usb_bus_dirname), usb_dev_filename, sizeof(usb_dev_filename));
  return 0;
}

static int
f_opt_showdevice(char *opt, void *fdata, int nth)
{
  char dirname[FILENAME_MAX + sizeof("")], filename[FILENAME_MAX + sizeof("")];

  if (ndevs) {
    int i;
    struct usb_device *d;

    pasoriv_setup_device_path(opt, dirname, sizeof(dirname), filename, sizeof(filename));

    for (i = 0 ; i < ndevs ;)
      if ((d = pasoriv_usb_dev_match_p(devv[i++], dirname, filename)))
	pasoriv_show_device(d, stdout);
  }

  *(int *)fdata = 1;
  return 0;
}

static int
f_opt_systemcode(char *opt, void *fdata, int nth)
{
  int i;

  i = strtol(opt, NULL, 0);
  polling[pasoriv_poll_systemcode + pasoriv_pkt_d1] = (i >> 8) & 0xFF;
  polling[pasoriv_poll_systemcode + pasoriv_pkt_d0] = i & 0xFF;
  return 0;
}

static int
f_opt_systemcodes(char *opt, void *fdata, int nth)
{
  unsigned char req[1 + IDm_LEN], res[PASORIV_FCMD_RES_MAX], *b, *e;
  int n;

  if (!last_idm_p) {
    if (verbose) {
      fputs("f_opt_systemcodes: No IDm\n", stderr);
      fflush(stderr);
    }

    return pasoriv_error_wrongoption;
  }

  req[0] = pasoriv_fcmd_systemcodes;
  memcpy(req + 1, last_idm, sizeof(req) - 1);

  if ((n = pasoriv_write_fcmd(req, sizeof(req))) < 0)
    return n;

  if ((n = pasoriv_read_fcmd(res, sizeof(res))) < 0)
    return n;

  if (res[0] != pasoriv_fcmd_systemcodes_res || n < 1 + IDm_LEN + 1 || res[1 + IDm_LEN] * 2 != n - 1 - IDm_LEN - 1) {
    pasoriv_send_nak();

    if (verbose) {
      fputs("f_opt_systemcodes(): unexpected response: \"", stderr);
      hexdump(res, res + n, stderr);
      fputs("\"\n", stderr);
      fflush(stderr);
    }

    return pasoriv_error_unexpectedpkt;
  }

  for (b = res + 1 + IDm_LEN + 1, e = res + n ; b < e - 2 ; b += 2) {
    printf(opt + 1, (b[pasoriv_pkt_d1] << 8) | b[pasoriv_pkt_d0]);
    putchar(*opt);
  }

  if (b < e)
    printf(opt + 1, (b[pasoriv_pkt_d1] << 8) | b[pasoriv_pkt_d0]);

  putchar('\n');
  fflush(stdout);
  return n;
}

static int
f_opt_firmwareversion(char *opt, void *fdata, int nth)
{
  int ret, major, minor;

  if (!(ret = pasoriv_firmver(&major, &minor))) {
    printf(opt, major, minor);
    putchar('\n');
    fflush(stdout);
  }

  return ret;
}

static int f_opt_help(char *, void *, int);

static char helphelp[] = \
"[=<0 or non-0 (default: 1)]\n" \
"  show this message.\n";

static int forever;

static char donehelp[] = \
"[=<0 or non-0 (default: 1)>]\n" \
"  if non-0 value, break from infinite loop\n" \
"  started by option \"do\".\n";

static int device_shown;
static int opt_status;
static int f_opt_readoption(char *, void *, int);

#define KEY(n) sizeof(n) - 1, n

static struct opt {
  unsigned char phase, name_len;
  const char *name;
  char *dflt;
  int (*f)(char *, void *, int);
  void *fdata;
  char *desc;
} opt_tab[] = {
  {0, KEY("?"), "1", f_opt_help, NULL, helphelp},
  {0, KEY("h"), "1", f_opt_help, NULL, helphelp},
  {2, KEY("do"), "1", f_opt_do, &forever,
   "[=<0 or non-0 (default: 1)>]\n" \
   "  if non-0 value, phase 2 options after this option\n"
   "  evaluated forever.\n"},
  {2, KEY("done"), "1", f_opt_done, &forever, donehelp},
  {2, KEY("exit"), "1", f_opt_done, &forever, donehelp},
  {0, KEY("help"), "1", f_opt_help, NULL, helphelp},
  {2, KEY("poll"), "%i", f_opt_poll, NULL,
   "[=<format string (default: \"%i\")>]\n" \
   "  send FeliCa polling command,\n" \
   "  and dump response after <format string>.\n" \
   "  %I => hex dump of IDm (somewhat formatted)\n" \
   "  %i => hex dump of IDm\n" \
   "  %P => hex dump of PMm (somewhat formatted)\n" \
   "  %i => hex dump of PMm\n" \
   "  %n => newline\n" \
   "  %<any other character> => <any other character>\n"},
  {2, KEY("quit"), "1", f_opt_done, &forever, donehelp},
  {0, KEY("initv"), "", f_opt_initv, skipv,
   "[=<flags (default: empty string)>] (system default: \"1111111\")\n" \
   "  specify whether or not send each of 5 initailize commands,\n" \
   "  reset command, and connection command described in\n" \
   "    http://wiki.osdev.info/index.php?PaSoRi%2FRC-S320\n" \
   "  1, O, o, Y, y, T, t => send\n" \
   "  0, X, x, N, n, F, f => not send\n" \
   "  <other character> => same as system default\n"},
  {2, KEY("status"), "%d", f_opt_status, &opt_status,
   "[=<format string (default: \"%d\")>]\n" \
   "  show status of the last option evaluation\n" \
   "  after <format string> which must include just one\n" \
   "  integer conversion specification.\n"},
  {0, KEY("trymax"), "3", f_opt_atoi, &usb_try_again_max,
   "[=<integer (default: 3)>] (system default: 3)\n" \
   "  number of attempts of each USB I/O request.\n"},
  {0, KEY("timeout"), "100", f_opt_atoi, &usb_timeout,
   "[=<mili seconds (default: 100)>] (system default: 100)\n" \
   "  USB I/O request timeout.\n"},
  {0, KEY("verbose"), "1", f_opt_atoi, &verbose,
   "[=<verbosity (default: 1)>] (system default: 1)\n"},
  {0, KEY("version"), "1", f_opt_version, NULL,
   "[=<0 or non-0 (default: 1)>]\n" \
   "  display version of this utility if non-0.\n"},
  {2, KEY("recvfcmd"), "%H", f_opt_recv, (void *)&pasoriv_read_fcmd,
   "[=<format string> (default: \"%H\")]\n" \
   "  receive response of FeliCa command,\n" \
   "  and dump it after <format string>.\n" \
   "  %H => hex dump of response (somewhat formatted)\n" \
   "  %h => hex dump of response\n" \
   "  %n => newline\n" \
   "  %<any other character> => <any other character>\n"},
  {2, KEY("recvpcmd"), "%H", f_opt_recv, (void *)&pasoriv_read_pkt,
   "[=<format string> (default: \"%H\")]\n" \
   "  receive response of PaSoRi command,\n" \
   "  and dump it after <format string>.\n" \
   "  %H => hex dump of response (somewhat formatted)\n" \
   "  %h => hex dump of response\n" \
   "  %n => newline\n" \
   "  %<any other character> => <any other character>\n"},
  {2, KEY("sendfcmd"), "", f_opt_send, (void *)&pasoriv_write_fcmd,
   "=<FeliCa command>\n" \
   "  send FeliCa command.\n" \
   "  Any octet can be included as %+<2 hex digits>.\n"},
  {2, KEY("sendfhex"), "", f_opt_sendhex, (void *)&pasoriv_write_fcmd,
   "=<FeliCa command as hex digits>\n"},
  {2, KEY("sendpcmd"), "", f_opt_send, (void *)&pasoriv_write_pkt,
   "=<PaSoRi command>\n" \
   "  send PaSoRi command.\n" \
   "  Any octet can be included as %+<2 hex digits>.\n"},
  {2, KEY("sendphex"), "", f_opt_sendhex, (void *)&pasoriv_write_pkt,
   "=<FeliCa command as hex digits>\n"},
  {0, KEY("busprefix"), USB_BUS_PREFIX, f_opt_busprefix, NULL,
   "[=<USB bus prefix (default: " USB_BUS_PREFIX ")>] (system default: " USB_BUS_PREFIX ")\n" \
   "  maybe Linux specific.\n"},
  {0, KEY("timeslots"), "1", f_opt_timeslots, NULL,
   "[=<number of time slots when polling (default: 1)>]\n"},
  {0, KEY("devicepath"), "", f_opt_devicepath, NULL,
   "[=<path to USB device (default: empty string)>] (system default: empty string)\n" \
   "  connect to specified PaSoRi device.\n"},
  {0, KEY("lastdevice"), "1", f_opt_atoi, &usb_last_dev,
   "[=<0 or non-0 (default: 1)>] (system default: 0)\n" \
   "  connect to last device when multiple PaSoRi device found.\n"},
  {2, KEY("readoption"), "1", f_opt_readoption, NULL,
   "[=<0 or non-0 (default: 1)>]\n" \
   "  if non-0, read one option and evaluate it.\n"},
  {1, KEY("showdevice"), "", f_opt_showdevice, &device_shown,
   "[=<directory name of USB bus/filename of USB device> (default: empty string)>]\n" \
   "  show USB device with specified path to which PaSoRi connected.\n"},
  {0, KEY("systemcode"), "0xFFFF", f_opt_systemcode, NULL,
   "[=<0 or non-0 (default: 0xFFFF)>] (system default: 0xFFFF)\n" \
   "  specify system code when polling.\n"},
  {0, KEY("debuglibusb"), "1", f_opt_atoi, &debug_libusb,
   "[=<argument to usb_set_debug() (default: 1)>] (system default: 0)\n"},
  {2, KEY("systemcodes"), ",0x%04X", f_opt_systemcodes, NULL,
   "[=<separator+format string (default \",0x%04X\")>]\n" \
   "  show <separator> separated list of system codes of\n" \
   "  connected FeliCa device after <format string> which\n" \
   "  must include just one integer conversion specification.\n"},
  {0, KEY("tryinterval"), "100", f_opt_atoi, &usb_try_again_interval,
   "[=<mili seconds (default: 100)>] (system default: 100)\n" \
   "  wait in mili seconds between USB I/O requests.\n"},
  {0, KEY("pollingtrymax"), "0", f_opt_atoi, &polling_try_again_max,
   "[=<integer (default: 0)>] (system default: 0)\n" \
   "  number of attempts of each FeliCa polling request.\n" \
   "  0 implies never giving up.\n"},
  {2, KEY("firmwareversion"), "%d.%d", f_opt_firmwareversion, NULL,
   "[=<format string (default: \"%d.%d\")>]\n" \
   "  show firmware version of PaSoRi after <format string>\n" \
   "  which must include just two integer conversion specification.\n"},
};

static char (*phase_help[]) = {
  "\n** Phase 0 options: evaluated before libusb initialized\n\n",
  "\n** Phase 1 options: evaluated before PaSoRi device opened\n\n",
  "\n** Phase 2 options: evaluated after PaSoRi device opened\n\n",
};

static int phase_counter[sizeof(phase_help) / sizeof(phase_help[0])];

static void
show_help(int ret, FILE *out)
{
  int i, phase;

  fprintf(out,
	  DESCRIPTION
	  "\nFollowing options are recognized."
	  "\nAll option names are case-insensitive,"
	  "\nand any leading hyphens are ignored.\n",
	  VERSION);

  for (phase = 0 ; phase < sizeof(phase_help) / sizeof(phase_help[0]) ; ++phase) {
    fputs(phase_help[phase], out);

    for (i = 0 ; i < sizeof(opt_tab) / sizeof(opt_tab[0]) ; ++i)
      if (opt_tab[i].phase == phase) {
	fputs(opt_tab[i].name, out);
	fputs(opt_tab[i].desc, out);
	putc('\n', out);
      }
  }

  exit(ret);
}

static int
f_opt_help(char *opt, void *fdata, int nth)
{
  show_help(0, stdout);
  return 0;
}

static int
find_opt(char *arg, int phase, char **val)
{
  int l, b, e, k, cmp;
  char *eq;

  while (*arg == '-')
    ++arg;

  eq = strchr(arg, '=');

  if (eq)
    l = eq - arg;
  else
    l = strlen(arg);

  if (!phase)
    for (k = l ; --k >= 0 ;)
      if (isalpha(arg[k]) && isupper(arg[k]))
	arg[k] = tolower(arg[k]);

  for (b = 0, e = sizeof(opt_tab) / sizeof(opt_tab[0]) ; b < e ;) {
    k = (b + e) / 2;

    if (l < opt_tab[k].name_len)
      e = k;
    else if (l > opt_tab[k].name_len)
      b = k + 1;
    else if ((cmp = memcmp(arg, opt_tab[k].name, l)) < 0)
      e = k;
    else if (cmp > 0)
      b = k + 1;
    else {
      if (!phase && opt_tab[k].phase < sizeof(phase_counter) / sizeof(phase_counter[0]))
	phase_counter[opt_tab[k].phase] += 1;

      if (phase < 0 || opt_tab[k].phase == phase) {
	if (eq)
	  *val = eq + 1;
	else
	  *val = opt_tab[k].dflt;

	return k;
      }
      else
	return pasoriv_error_optphasediffer;
    }
  }

  if (!phase && verbose) {
    fprintf(stderr, "Unknown option: %s\n", arg);
    fflush(stderr);
  }

  return pasoriv_error_optnotfound;
}

#define OPT_PHASEDIFFER (0x01 << 0)
#define OPT_NOTFOUND (0x01 << 1)

static int
call_opt(char *arg, int nth, int phase, int error)
{
  char *val;
  int i;

  if ((i = find_opt(arg, phase, &val)) >= 0) {
    if (opt_tab[i].f) {
      opt_status = opt_tab[i].f(val, opt_tab[i].fdata, nth);
      return opt_status < 0;
    }
    else
      return opt_status = 0;
  }
  else if (((error & OPT_PHASEDIFFER) && i == pasoriv_error_optphasediffer) ||
	   ((error & OPT_NOTFOUND) && i == pasoriv_error_optnotfound)) {
    opt_status = i;
    return 1;
  }
  else {
    opt_status = 0;
    return 0;
  }
}

static int
f_opt_readoption(char *opt, void *fdata, int nth)
{
  if (strtol(opt, NULL, 0)) {
    char buf[4096];

    while (fgets(buf, sizeof(buf), stdin)) {
      int b, e;

      e = strlen(buf);

      while (e > 0 && isspace(buf[e - 1]))
	--e;

      for (b = 0 ; b < e && isspace(buf[b]) ; ++b)
	;

      if (b < e) {
	buf[e] = '\0';
	call_opt(buf + b, nth, -1, OPT_NOTFOUND);
	return opt_status;
      }
    }

    return pasoriv_error_system;
  }
  else
    return 0;
}

#ifndef SIGHANDLER_RETURN_T
#define SIGHANDLER_RETURN_T void
#endif

#ifndef SIGNAL_T
#define SIGNAL_T int
#endif

#ifndef SIGHANDLER_ARG
#define SIGHANDLER_ARG SIGNAL_T signam
#endif

SIGHANDLER_RETURN_T
sighandler(SIGHANDLER_ARG)
{
  pasoriv_shutdown_usb();
  exit(1);
}

#ifndef SIGCATCHED
#define SIGCATCHED SIGTERM, SIGINT
#endif

static SIGNAL_T sigv[] = {SIGCATCHED};

int
main(int argc, char **argv)
{
  int i, ret = 0;
  char *slash;

  for (i = sizeof(sigv) / sizeof(sigv[0]) ; i > 0 ;)
    signal(sigv[--i], sighandler);

  for (me = argv[0] ; (slash = strchr(me, '/')) ; me = slash + 1)
    ;

  for (i = 1 ; i < argc ; ++i)
    if (call_opt(argv[i], i, 0, OPT_NOTFOUND)) {
      if (opt_status == pasoriv_error_optnotfound)
	show_help(1, stderr);

      ++ret;
    }

  if (phase_counter[1] || phase_counter[2]) {
    pasoriv_init_usb();

    for (i = 1 ; i < argc ; ++i)
      ret += call_opt(argv[i], i, 1, 0);

    if (verbose >= 2 && !device_shown) {
      pasoriv_show_device(dev, stderr);
      device_shown = 1;
    }

    if (dev) {
      if (phase_counter[2]) {
	if (!pasoriv_start()) {
	  i = 1;
	loop:
	  for (; i < argc ; ++i) {
	    ret += call_opt(argv[i], i, 2, 0);

	    if (forever < 0)
	      break;
	  }

	  if (forever > 0) {
	    ret = !!ret;
	    i = forever;
	    goto loop;
	  }
	}
	else
	  ++ret;
      }
    }
    else if (phase_counter[2]) {
      if (!device_shown && verbose) {
	pasoriv_show_device(dev, stderr);
	device_shown = 1;
      }

      ++ret;
    }

    pasoriv_shutdown_usb();
  }

  return !!ret;
}
