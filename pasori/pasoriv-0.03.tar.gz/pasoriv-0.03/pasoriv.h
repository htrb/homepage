#ifndef PASORIV_H

#include <usb.h>

#define PASORIV_PREAMBLE 0x00, 0x00, 0xFF
#define PASORIV_PREAMBLE_LEN (3)
#define PASORIV_POSTAMBLE 0x00
#define PASORIV_POSTAMBLE_LEN (1)

enum {
  pasoriv_pkt_mbr_len = PASORIV_PREAMBLE_LEN,
  pasoriv_pkt_mbr_lmod,
  pasoriv_pkt_mbr_data,
};

enum {
  pasoriv_pkt_d1,
  pasoriv_pkt_d0,
};

enum {
  pasoriv_pkt_q3,
  pasoriv_pkt_q2,
  pasoriv_pkt_q1,
  pasoriv_pkt_q0,
};

#define PASORIV_PKT_SIZE_MIN (pasoriv_pkt_mbr_data + 1 + PASORIV_POSTAMBLE_LEN)
#define PASORIV_PKT_MBR_LEN_MAX (254)

enum {
  pasoriv_pcmd_self_test = 0x52,
  pasoriv_pcmd_self_test_res = 0x53,
  pasoriv_pcmd_reset = 0x54,
  pasoriv_pcmd_reset_res = 0x55,
  pasoriv_pcmd_firmware_version = 0x58,
  pasoriv_pcmd_firmware_version_res = 0x59,
  pasoriv_pcmd_iostart = 0x5a,
  pasoriv_pcmd_iostart_res = 0x5b,
  pasoriv_pcmd_fcmd = 0x5c,
  pasoriv_pcmd_fcmd_res = 0x5d,
  pasoriv_pcmd_init = 0x62,
  pasoriv_pcmd_init_res = 0x63,
};

enum {
  pasoriv_fcmd_polling = 0x00,
  pasoriv_fcmd_polling_res = 0x01,
  pasoriv_fcmd_systemcodes = 0x0c,
  pasoriv_fcmd_systemcodes_res = 0x0d,
};

#define PASORIV_FCMD_RES_MAX (PASORIV_PKT_MBR_LEN_MAX - 2)

enum {
  pasoriv_poll_fcmd,
  pasoriv_poll_systemcode,
  pasoriv_poll_systemcode1,
  pasoriv_poll_reservedzero,
  pasoriv_poll_timeslot,
  pasoriv_poll_cmdlen,
};

#define PASORIV_POLL_TIMESLOTS_MAX (0x10)

#endif /* !defined(PASORIV_H) */
