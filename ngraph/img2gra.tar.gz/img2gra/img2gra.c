/**************************************************************************

              img2gra Version 0.00 Copyright (C) hito 2002

 **************************************************************************/

#define PRG_NAME "img2gra Version 0.00"

#include <gdk_imlib.h>
#include <gdk/gdk.h>
#include <glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>

GdkImlibColor BGCOLOR = {255, 255, 255}, IGNCOLOR = {-1, -1, -1};
static int DotSize = 36;

int WriteGra(GdkImlibImage *im, char *gra_file);
int WriteGra2(GdkImlibImage *im, char *gra_file);

static int rectcmp(const void *tmpa, const void *tmpb);
static int colorcmp(GdkImlibColor *a, GdkImlibColor *b);
static void fputcolor(FILE *fp, GdkImlibColor *color);

struct rectangle{
  unsigned char r, g, b;
  int x1, y1, x2, y2;
};

int main(int argc, char **argv)
{
  GdkImlibImage *im;
  int opt, r, g, b, resolution;
  char *optstr = "r:b:", *bmp_file = NULL, *gra_file = NULL;
  char *usage = "Usage: %s [-r resolution -b bgcolor] image_file [gra file].\n";

  gdk_init(&argc, &argv);
  gdk_imlib_init();

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'b':
      if(strlen(optarg) != 6 || sscanf(optarg, "%02x%02x%02x", &r, &g, &b) != 3){
	printf("Invarid color(%s).\n", optarg);
	exit(1);
      }
      BGCOLOR.r = r;
      BGCOLOR.g = g;
      BGCOLOR.b = b;
      break;
    case 'r':
      sscanf(optarg, "%d", &resolution);
      if(resolution < 1 || DotSize > 2540){
	printf("Invarid resolution value(%d).\n", resolution);
	exit(1);
      }
      DotSize = 2540 / resolution;
      break;
    case '?':
      printf(usage, argv[0]);
      exit(1);
      break;
    }
  }

  switch(argc - optind){
  case 2:
    gra_file = argv[optind + 1];
  case 1:
    bmp_file = argv[optind];
    break;
  default:
    printf(usage, argv[0]);
    exit(1);
  }

  if((im = gdk_imlib_load_image(bmp_file)) == NULL){
    perror(bmp_file);
    exit(1);
  }

  WriteGra2(im, gra_file);
  return 0;
}

int WriteGra(GdkImlibImage *im, char *gra_file)
{
  gint w, h, x, x1, y, i, j;
  GdkImlibColor shape_color, color, color2;

  if(im == NULL)
    return 1;

  w=im->rgb_width;
  h=im->rgb_height;

  if(gra_file != NULL && freopen(gra_file, "wt", stdout) == NULL){
    perror("");
    exit(1);
  }

  fprintf(stdout, "%%Ngraph GRAF\n"
	  "%%Creator: " PRG_NAME "\n"
	  "I,5,0,0,%d,%d,10000\n"
	  "V,5,0,0,%d,%d,1\n"
	  "A,5,0,1,0,0,1000\n",
	  w * DotSize, h * DotSize,
	  w * DotSize, h * DotSize);

  gdk_imlib_get_image_shape(im, &shape_color);

  if(!colorcmp(&IGNCOLOR, &shape_color)){
    shape_color = BGCOLOR;
    fputcolor(stdout, &BGCOLOR);
    fprintf(stdout, "B,5,0,0,%d,%d,1\n", w * DotSize, h * DotSize);
  }
  color = color2 = shape_color;

  j = 0;
  for(y = 0; y < h; y++){
    i = y * 3 * w;
    for(x = x1 = 0; x < w; x++){
      color2.r = im->rgb_data[i++];
      color2.g = im->rgb_data[i++];
      color2.b = im->rgb_data[i++];

      if(colorcmp(&color2, &color)){
	if(x != 0 && colorcmp(&shape_color, &color)){
	  fprintf(stdout, "B,5,%d,%d,%d,%d,1\n", x1 * DotSize, y * DotSize, x * DotSize, (y + 1) * DotSize);
	}
	if(colorcmp(&shape_color, &color2)){
	  fputcolor(stdout, &color2);
	}
	color = color2;
	x1 = x;
      }
      if(x == w - 1 && colorcmp(&shape_color, &color)){
	fprintf(stdout, "B,5,%d,%d,%d,%d,1\n", x1 * DotSize, y * DotSize,
		(x + 1) * DotSize, (y + 1) * DotSize);
      }
    }

    if(ferror(stdout)){
      perror("");
      exit(1);
    }
  }
  fprintf(stdout, "E,0\n");
  fclose(stdout);
  return 0;
}

int WriteGra2(GdkImlibImage *im, char *gra_file)
{
  gint w, h, x, x1, y, i, j;
  GdkImlibColor shape_color, color, color2;
  struct rectangle *rect;

  if(im == NULL)
    return 1;

  w=im->rgb_width;
  h=im->rgb_height;

  if(INT_MAX / sizeof(*rect) / w / h < 1 || INT_MAX / w / DotSize < 1 || INT_MAX / h / DotSize < 1){
    g_error("Too large image(%s).\n", im->filename);
    exit(1);
  }
  rect = g_malloc(sizeof(*rect) * w * h);

  if(gra_file != NULL && freopen(gra_file, "wt", stdout) == NULL){
    perror("");
    exit(1);
  }

  fprintf(stdout, "%%Ngraph GRAF\n"
	  "%%Creator: " PRG_NAME "\n"
	  "I,5,0,0,%d,%d,10000\n"
	  "V,5,0,0,%d,%d,1\n"
	  "A,5,0,1,0,0,1000\n",
	  w * DotSize, h * DotSize,
	  w * DotSize, h * DotSize);

  gdk_imlib_get_image_shape(im, &shape_color);

  if(!colorcmp(&IGNCOLOR, &shape_color)){
    shape_color = BGCOLOR;
    fputcolor(stdout, &BGCOLOR);
    fprintf(stdout, "B,5,0,0,%d,%d,1\n", w * DotSize, h * DotSize);
  }
  color = color2 = shape_color;

  j = 0;
  for(y = 0; y < h; y++){
    i = y * 3 * w;
    for(x = x1 = 0; x < w; x++){
      color2.r = im->rgb_data[i++];
      color2.g = im->rgb_data[i++];
      color2.b = im->rgb_data[i++];

      if(colorcmp(&color2, &color)){
	if(x != 0 && colorcmp(&shape_color, &color)){
	  rect[j].r = color.r;
	  rect[j].g = color.g;
	  rect[j].b = color.b;
	  rect[j].x1 = x1 * DotSize;
	  rect[j].y1 = y * DotSize;
	  rect[j].x2 = x * DotSize;
	  rect[j].y2 = (y + 1) * DotSize;
	  j++;
	}
	color = color2;
	x1 = x;
      }
      if(x == w - 1 && colorcmp(&shape_color, &color)){
	rect[j].r = color.r;
	rect[j].g = color.g;
	rect[j].b = color.b;
	rect[j].x1 = x1 * DotSize;
	rect[j].y1 = y * DotSize;
	rect[j].x2 = (x + 1) * DotSize;
	rect[j].y2 = (y + 1) * DotSize;
	j++;
      }
    }
  }

  qsort(rect, j, sizeof(*rect), rectcmp);
  color.r = rect[0].r;
  color.g = rect[0].g;
  color.b = rect[0].b;
  fputcolor(stdout, &color);
  for(i = 0; i < j; i++){
    color2.r = rect[i].r;
    color2.g = rect[i].g;
    color2.b = rect[i].b;
    if(colorcmp(&color2, &color)){
      fputcolor(stdout, &color2);
      color = color2;
    }
    fprintf(stdout, "B,5,%d,%d,%d,%d,1\n", rect[i].x1, rect[i].y1, rect[i].x2, rect[i].y2);
  }
  fprintf(stdout, "E,0\n");

  if(ferror(stdout)){
    perror("");
    exit(1);
  }
  fclose(stdout);
  g_free(rect);
  return 0;
}

static int colorcmp(GdkImlibColor *a, GdkImlibColor *b)
{
  if(a->r == b->r && a->g == b->g && a->b == b->b)
    return 0;
  else
    return 1;
}

static int rectcmp(const void *tmpa, const void *tmpb)
{
  struct rectangle *a = (struct rectangle *)tmpa,  *b = (struct rectangle *)tmpb;
  int c, d;

  c = (((int)a->r)<<16) + (((int)a->g)<<8) + a->b;
  d = (((int)b->r)<<16) + (((int)b->g)<<8) + b->b;
  return c - d;
}

static void fputcolor(FILE *fp, GdkImlibColor *color)
{
  fprintf(fp, "G,3,%d,%d,%d\n", color->r, color->g, color->b);
}
