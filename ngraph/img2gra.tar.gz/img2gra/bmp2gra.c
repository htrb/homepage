/**************************************************************************
              bmp2gra Version 0.00 Copyright (C) hito 2002

               char = 8 bit, short = 16 bit, long = 32 bit
 **************************************************************************/

#define PRG_NAME "bmp2gra Version 0.00"
#define BUF_SIZE 1024

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include <unistd.h>
#include <errno.h>

typedef struct{
  unsigned short bfType;
  unsigned long	 bfSize;
  unsigned short bfReserved1;
  unsigned short bfReserved2;
  unsigned long	 bfOffBits;
}
__attribute__((packed))
BITMAPFILE;

typedef struct{
  unsigned long	biSize;
  long	biWidth;
  long	biHeight;
  short	biPlanes;
  short	biBitCount;
  unsigned long	biCompression;
  unsigned long	biSizeImage;
  long	biXPelsPerMeter;
  long	biYPelsPerMeter;
  unsigned long	biClrUsed;
  unsigned long	biClrImportant;
} BITMAPINFO;

typedef struct{
  unsigned char B;
  unsigned char G;
  unsigned char R;
  unsigned char Reserved;
}RGBQUAD;

typedef struct{
  int width;
  int height;
  RGBQUAD *data[1];
}BMP_DATA;

struct rectangle{
  unsigned char r, g, b;
  int x1, y1, x2, y2;
};

BMP_DATA *ReadBMP(char *bmp_file);
int WriteGra(BMP_DATA *bmp, char *gra_file);
int WriteGra2(BMP_DATA *bmp, char *gra_file);
void free_bmp(BMP_DATA *data);

static int ReadUnCompress(int fd, BMP_DATA *bmp, RGBQUAD *pal, BITMAPINFO bi);
static int Read24bpp(int fd, BMP_DATA *bmp, RGBQUAD *pal);
static int Read8bpp(int fd, BMP_DATA *bmp, RGBQUAD *pal);
static int Read4bpp(int fd, BMP_DATA *bmp, RGBQUAD *pal);
static int Read1bpp(int fd, BMP_DATA *bmp, RGBQUAD *pal);
static int ReadCompress(int fd, BMP_DATA *bmp, RGBQUAD *pal, BITMAPINFO bi);
static int colorcmp(RGBQUAD *a, RGBQUAD *b);
static int rectcmp(const void *tmpa, const void *tmpb);
static BMP_DATA *malloc_bmp(int width, int height);
static void *my_malloc(size_t size);
static int buf_readc(int fd, char *c);

static char *Err_fmt1        = "Error: %s (%s)\n";
static char *Err_too_large   = "Error: Too large image.\n";
static char *Err_invalid_img = "Error: Invalid BMP file.\n";
static char *Err_no_support  = "Error: This program can't deal this BMP file.\n";

static RGBQUAD BGCOLOR = {255, 255, 255, 0};
static int DotSize = 36;

int main(int argc, char *argv[])
{
  BMP_DATA *bmp;
  int opt, r, g, b, resolution;
  char *optstr = "r:b:", *bmp_file = NULL, *gra_file = NULL;
  char *usage = "Usage: %s [-r resolution -b bgcolor] [bmp file] [gra file].\n";

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'b':
      if(strlen(optarg) != 6 || sscanf(optarg, "%02x%02x%02x", &r, &g, &b) != 3){
	printf("Invarid color(%s).\n", optarg);
	exit(1);
      }
      BGCOLOR.R = r;
      BGCOLOR.G = g;
      BGCOLOR.B = b;
      break;
    case 'r':
      sscanf(optarg, "%d", &resolution);
      if(resolution < 1 || DotSize > 2540){
	printf("Invarid resolution value(%d).\n", resolution);
	exit(1);
      }
      DotSize = 2540 / resolution;
      break;
    case '?':
      printf(usage, argv[0]);
      exit(1);
      break;
    }
  }

  switch(argc - optind){
  case 2:
    gra_file = argv[optind + 1];
  case 1:
    bmp_file = argv[optind];
    break;
  case 0:
    break;
  default:
    printf(usage, argv[0]);
    exit(1);
  }

  bmp = ReadBMP(bmp_file);
  WriteGra2(bmp, gra_file);
  return 0;
}

int WriteGra(BMP_DATA *bmp, char *gra_file)
{
  int width, height, x, y, x1;
  RGBQUAD color = BGCOLOR;

  if(bmp == NULL)
    exit(1);

  width = bmp->width;
  height = bmp->height;

  if(gra_file != NULL && freopen(gra_file, "wt", stdout) == NULL){
    perror("");
    exit(1);
  }

  fprintf(stdout, "%%Ngraph GRAF\n"
	  "%%Creator: " PRG_NAME "\n"
	  "I,5,0,0,%d,%d,10000\n"
	  "V,5,0,0,%d,%d,1\n"
	  "A,5,0,1,0,0,1000\n",
	  width * DotSize, height * DotSize,
	  width * DotSize, height * DotSize);
  fprintf(stdout,"G,3,%d,%d,%d\n", BGCOLOR.R, BGCOLOR.G, BGCOLOR.B);
  fprintf(stdout,"B,5,0,0,%d,%d,1\n", width * DotSize, height * DotSize);

  for(y = 0; y < height; y++){
    for(x = x1 = 0; x < width; x++){
      /*
	fprintf(stdout,"G,3,%d,%d,%d\n", bmp->data[y][x].R, bmp->data[y][x].G, bmp->data[y][x].B);
	fprintf(stdout,"B,5,%d,%d,%d,%d,1\n", x * DotSize, y * DotSize, (x + 1) * DotSize, (y + 1) * DotSize);
      */
      if(colorcmp(&bmp->data[y][x], &color)){
	if(x != 0 && colorcmp(&BGCOLOR, &color)){
	  fprintf(stdout,"B,5,%d,%d,%d,%d,1\n", x1 * DotSize, y * DotSize, x * DotSize, (y + 1) * DotSize);
	}
	if(colorcmp(&BGCOLOR, &bmp->data[y][x])){
	  fprintf(stdout,"G,3,%d,%d,%d\n", bmp->data[y][x].R, bmp->data[y][x].G, bmp->data[y][x].B);
	}
	color = bmp->data[y][x];
	x1 = x;
      }
      if(x == width - 1 && colorcmp(&BGCOLOR, &color)){
	fprintf(stdout,"B,5,%d,%d,%d,%d,1\n", x1 * DotSize, y * DotSize,
		(x + 1) * DotSize, (y + 1) * DotSize);
      }
    }
    if(ferror(stdout)){
      perror("");
      exit(1);
    }
  }
  fprintf(stdout, "E,0\n");
  return 0;
}

int WriteGra2(BMP_DATA *bmp, char *gra_file)
{
  int width, height, i, j, x, y, x1;
  RGBQUAD color = BGCOLOR, color2;
  struct rectangle *rect;

  if(bmp == NULL)
    exit(1);

  width = bmp->width;
  height = bmp->height;

  if(INT_MAX / sizeof(*rect) / width / height < 1 || INT_MAX / width / DotSize < 1 || INT_MAX / height / DotSize < 1){
    fprintf(stderr, "Too large image.\n");
    exit(1);
  }
  rect = my_malloc(sizeof(*rect) * width * height);

  if(gra_file != NULL && freopen(gra_file, "wt", stdout) == NULL){
    perror("");
    exit(1);
  }

  fprintf(stdout, "%%Ngraph GRAF\n"
	  "%%Creator: " PRG_NAME "\n"
	  "I,5,0,0,%d,%d,10000\n"
	  "V,5,0,0,%d,%d,1\n"
	  "A,5,0,1,0,0,1000\n",
	  width * DotSize, height * DotSize,
	  width * DotSize, height * DotSize);
  fprintf(stdout,"G,3,%d,%d,%d\n", BGCOLOR.R, BGCOLOR.G, BGCOLOR.B);
  fprintf(stdout,"B,5,0,0,%d,%d,1\n", width * DotSize, height * DotSize);

  j = 0;
  for(y = 0; y < height; y++){
    for(x = x1 = 0; x < width; x++){
      color2 = bmp->data[y][x];

      if(colorcmp(&bmp->data[y][x], &color)){
	if(x != 0 && colorcmp(&BGCOLOR, &color)){
	  rect[j].r = color.R;
	  rect[j].g = color.G;
	  rect[j].b = color.B;
	  rect[j].x1 = x1 * DotSize;
	  rect[j].y1 = y * DotSize;
	  rect[j].x2 = x * DotSize;
	  rect[j].y2 = (y + 1) * DotSize;
	  j++;
	}
	color = bmp->data[y][x];
	x1 = x;
      }
      if(x == width - 1 && colorcmp(&BGCOLOR, &color)){
	rect[j].r = color.R;
	rect[j].g = color.G;
	rect[j].b = color.B;
	rect[j].x1 = x1 * DotSize;
	rect[j].y1 = y * DotSize;
	rect[j].x2 = (x + 1) * DotSize;
	rect[j].y2 = (y + 1) * DotSize;
	j++;
      }
    }
  }
  qsort(rect, j, sizeof(*rect), rectcmp);
  color.R = rect[0].r;
  color.G = rect[0].g;
  color.B = rect[0].b;
  fprintf(stdout,"G,3,%d,%d,%d\n", color.R, color.G, color.B);
  for(i = 0; i < j; i++){
    color2.R = rect[i].r;
    color2.G = rect[i].g;
    color2.B = rect[i].b;
    if(colorcmp(&color2, &color)){
      fprintf(stdout,"G,3,%d,%d,%d\n", color2.R, color2.G, color2.B);
      color = color2;
    }
    fprintf(stdout, "B,5,%d,%d,%d,%d,1\n", rect[i].x1, rect[i].y1, rect[i].x2, rect[i].y2);
  }
  fprintf(stdout, "E,0\n");
  if(ferror(stdout)){
    perror("");
    exit(1);
  }
  return 0;
}

static int rectcmp(const void *tmpa, const void *tmpb)
{
  struct rectangle *a = (struct rectangle *)tmpa,  *b = (struct rectangle *)tmpb;
  int c, d;

  c = (((int)a->r)<<16) + (((int)a->g)<<8) + a->b;
  d = (((int)b->r)<<16) + (((int)b->g)<<8) + b->b;
  return c - d;
}

BMP_DATA *ReadBMP(char *bmp_file)
{
  int i, fd = 0, palsize;
  BITMAPINFO bi;
  BITMAPFILE bf;
  RGBQUAD    pal[256];
  BMP_DATA   *bmp;

  if(bmp_file != NULL && (fd=open(bmp_file, O_RDONLY, S_IREAD | S_IWRITE )) == -1){
    perror("");
    exit(1);
  }

  read(fd, &bf, sizeof(BITMAPFILE));
  if(read(fd, &bi, sizeof(BITMAPINFO)) == -1){
    fprintf(stderr, Err_fmt1, strerror(errno), bmp_file);
    exit(1);
  }

  if((bf.bfType != 0x4d42) ||
     (bi.biBitCount != 1 && bi.biBitCount != 4 && bi.biBitCount != 8 && bi.biBitCount != 24) ||
     (bi.biCompression == 1 && bi.biBitCount != 8) ||
     (bi.biCompression == 2 && bi.biBitCount != 4)){
    fprintf(stderr, Err_invalid_img);
    exit(1);
  }

  bmp = malloc_bmp(bi.biWidth, bi.biHeight);

  if(bi.biBitCount <= 8){
    palsize = 1<<bi.biBitCount;
    for(i = 0; i < palsize;  i++){
      read(fd, &pal[i], sizeof(RGBQUAD));
    }
  }

  lseek(fd, bf.bfOffBits, SEEK_SET);

  if(bi.biCompression != 0){
    ReadCompress(fd, bmp, pal, bi);
  }else{
    ReadUnCompress(fd, bmp, pal, bi);
  }
  close(fd);
  return bmp;
}

static int ReadUnCompress(int fd, BMP_DATA *bmp, RGBQUAD *pal, BITMAPINFO bi)
{
  switch(bi.biBitCount){
  case 24:
    Read24bpp(fd, bmp, pal);
    break;
  case 8:
    Read8bpp(fd, bmp, pal);
    break;
  case 4:
    Read4bpp(fd, bmp, pal);
    break;
  case 1:
    Read1bpp(fd, bmp, pal);
    break;
  }
  return 0;
}

static int Read24bpp(int fd, BMP_DATA *bmp, RGBQUAD *pal)
{
  int x, y, height, width, linesize;
  unsigned char *tmp;

  height = bmp->height;
  width = bmp->width;

  linesize = width * 3;
  linesize += (3 - (linesize - 1) % 4);

  tmp = my_malloc(linesize);

  for(y=0; y < height; y++){
    read(fd, tmp, linesize);
    for(x=0; x < width; x++){
      bmp->data[height - y - 1][x].B = tmp[x * 3];
      bmp->data[height - y - 1][x].G = tmp[x * 3 + 1];
      bmp->data[height - y - 1][x].R = tmp[x * 3 + 2];
    }
  }
  free(tmp);
  return 0;
}

static int Read8bpp(int fd, BMP_DATA *bmp, RGBQUAD *pal)
{
  int i, x, y, height, width;
  unsigned long linesize;
  unsigned char *tmp;


  height = bmp->height;
  width = bmp->width;

  linesize = width + (3 - (width - 1) % 4);
  tmp = my_malloc(linesize);

  for(y=0; y < height; y++){
    read(fd, tmp, linesize);
    for(x=0; x < width; x++){
      i = tmp[x];
      bmp->data[height - y - 1][x] = pal[i];
    }
  }
  free(tmp);
  return 0;
}

static int Read4bpp(int fd, BMP_DATA *bmp, RGBQUAD *pal)
{
  int i, x, y, height, width;
  unsigned long linesize;
  unsigned char *tmp;


  height = bmp->height;
  width = bmp->width;

  linesize = width / 2 + ((width % 2)?1:0);
  linesize += (3 - (linesize - 1) % 4);
  tmp = my_malloc(linesize);

  for(y=0; y < height; y++){
    read(fd, tmp, linesize);
    x=0;
    while(x < width){
      i = tmp[x / 2] >> 4;
      bmp->data[height - y - 1][x] = pal[i];
      x++;

      if(x >= width)
	break;

      i = tmp[x / 2] & 0x0f;
      bmp->data[height - y - 1][x] = pal[i];
      x++;
    }
  }
  free(tmp);
  return 0;
}

static int Read1bpp(int fd, BMP_DATA *bmp, RGBQUAD *pal)
{
  int i, x, y, width, height;
  unsigned long linesize;
  unsigned char *tmp;

  height = bmp->height;
  width = bmp->width;

  linesize = width / 8 + ((width % 8)?1:0);
  linesize += (3 - (linesize - 1) % 4);
  tmp = my_malloc(linesize);

  for(y = 0; y < height; y++){
    read(fd, tmp, linesize);
    x = 0;
    while(x < width){
      for(i = 0x80; i > 0; i >>= 1){
	bmp->data[height - y - 1][x] = pal[(tmp[x / 8] & i)?1:0];
	x++;
	if(x >= width)
	  break;
      }
    }
  }
  free(tmp);
  return 0;
}

static int ReadCompress(int fd, BMP_DATA *bmp, RGBQUAD *pal, BITMAPINFO bi)
{
  int i, x, y, bit, compression, literal, linesize, width, height;
  unsigned char data1, data2;

  height = bmp->height;
  width = bmp->width;

  bit = 8 / bi.biBitCount;
  linesize = width / bit + ((width % bit)?1:0);
  linesize += (3 - (linesize - 1) % 4);

  compression = bi.biCompression;

  x = y = 0;
  while(1){
    buf_readc(fd, &data1);
    if(buf_readc(fd, &data2) != 0)
      return 0;

    if(data1 == 0 && data2 == 0){
      if(x != width)
	goto ERR;
      y++;
      x = 0;
      continue;
    }

    if(data1 == 0 && data2 == 1)		/* EOF */
      break;

    if(data1 == 0 && data2 == 2){		/* MOVE */
      fprintf(stderr, Err_no_support);
      exit(1);
    }

    if(data1 == 0 && data2 != 0){
      literal = 1;
      data1 = data2;
    }else{
      literal = 0;
    }

    for(i = 0; i < data1; i += compression){
      if(literal == 1)
	buf_readc(fd, &data2);

      if(compression == 1){
	bmp->data[height - y - 1][x++] = pal[data2];
      }else{
	bmp->data[height - y - 1][x++] = pal[data2 >> 4];

	if(x >= width) break;

	bmp->data[height - y - 1][x++] = pal[data2 & 0x0f];
      }

      if(x > width)
	goto ERR;
    }

    if(literal == 1){
      if(compression == 2){
	if(((data1 / 2) + (data1 % 2)) % 2 != 0)   /* padding */
	  buf_readc(fd, &data2);
      }else{
	if(data1 % 2 != 0)                         /* padding */
	  buf_readc(fd, &data2);
      }
    }
  }
  return 0;

 ERR:
  fprintf(stderr, Err_invalid_img);
  exit(1);
}

static int buf_readc(int fd, char *c)
{
  static char tmp[BUF_SIZE];
  static int i=0, j=0;

  if(i >= j){
    j = read(fd, tmp, BUF_SIZE);
    i = 0;
    if(j == -1){
      perror("");
      exit(1);
    }else if(j == 0){
      return 1;
    }
  }
  *c=tmp[i++];
  return 0;
}

static BMP_DATA *malloc_bmp(int width, int height)
{
  BMP_DATA *ptr;
  RGBQUAD  *data;
  int i;

  ptr = my_malloc(sizeof(BMP_DATA) + sizeof(data) * height);

  if(INT_MAX / width / height == 0){
    fprintf(stderr, Err_too_large);
    exit(1);
  }

  ptr->width = width;
  ptr->height = height;

  data = my_malloc(sizeof(*data) * width * height);
  for(i = 0; i < height; i++){
    ptr->data[i] = data;
    data += width;
  }
  return ptr;
}

void free_bmp(BMP_DATA *bmp)
{
  if(bmp == NULL)
    return;

  if(bmp->data[0] != NULL)
    free(bmp->data[0]);

  free(bmp);
}

static void *my_malloc(size_t size)
{
  void *tmp;
  tmp = malloc(size);
  if(tmp == NULL){
    perror("");
    exit(1);
  }
  return tmp;
}

static int colorcmp(RGBQUAD *a, RGBQUAD *b)
{
  if(a->R == b->R && a->G == b->G && a->B == b->B)
    return 0;
  else
    return 1;
}
