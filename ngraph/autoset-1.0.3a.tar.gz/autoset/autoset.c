#include <stdio.h>
#include <stdlib.h>

#define FILE_MAX 32

void nsc_out(FILE *fp);
int save_script(char *script_name);
int read_cfg(char *cfg_file);
int read_setting(char *setting_file);

int file_num, *selected;
int Mark[FILE_MAX], File_Style[FILE_MAX], File_Width[FILE_MAX];
int File_R[FILE_MAX], File_G[FILE_MAX], File_B[FILE_MAX];

int COLOR=0, LEGEND=0, STYLE=0, WITH_MARK=0, RE_DRAW=0;

int main(int argc, char *argv[])
{
  if(argc != 5){
    fprintf(stderr, "Option error.\n");
    return 1;
  }

  if((file_num=atoi(argv[1])) < 1)
    return 0;

  if((selected = (int *)malloc(sizeof(int)*file_num)) == NULL){
    fprintf(stderr, "Can't allocate memory.\n");
    return 1;
  }

  if(read_cfg(argv[2])){
    fprintf(stderr, "File error %s.\n", argv[2]);
    return 1;
  }


  if(read_setting(argv[3])){
    fprintf(stderr, "File error %s.\n", argv[3]);
    return 1;
  }

  if(save_script(argv[4])){
    fprintf(stderr, "File error %s.\n", argv[4]);
    return 1;
  }

  free(selected);
  return 0;
}

int read_cfg(char *cfg_file)
{
  char buf[256];
  int i=0, type=0, num[3]={0, 0, 0};
  FILE *fp;

  if((fp=fopen(cfg_file, "r")) == NULL)
    return 1;

  while(fgets(buf, sizeof(buf), fp) != NULL){
    i++;
    if(buf[0] == '#'){
      if(buf[1] == '#'){
	switch(buf[2]){
	case 'M':
	  type=0;
	  break;
	case 'L':
	  type=1;
	  break;
	case 'C':
	  type=2;
	  break;
	case 'I':
	  type=3;
	  break;
	}
      }
    }
    else if(buf[0] != '\n'){
      switch(type){
      case 0:
	if(num[0] > FILE_MAX-1)
	  break;
	if(sscanf(buf, "%d", &Mark[num[0]]) == 1)
	  num[0]++;
	else{
	  fprintf(stderr, "File error %s: %d\n", cfg_file, i);
	  exit(1);
	}
	break;
      case 1:
	if(num[1]>FILE_MAX-1) break;
	if(sscanf(buf, "%d %d", 
		  &File_Style[num[1]], &File_Width[num[1]]) == 2)
	  num[1]++;
	else{
	  fprintf(stderr, "File error %s: %d\n", cfg_file, i);
	  exit(1);
	}
	break;
      case 2:
	if(num[2]>FILE_MAX-1) break;
	if(sscanf(buf, "%d %d %d", 
		  &File_R[num[2]], &File_G[num[2]], &File_B[num[2]]) == 3)
	  num[2]++;
	else{
	  fprintf(stderr, "File error %s: %d\n", cfg_file, i);
	  exit(1);
	}
	break;
      }
    }
  }

  if(ferror(fp))
    return 1;

  fclose(fp);
  return 0;
}

int read_setting(char *setting_file)
{
  int i=0;
  char buf[256];
  FILE *fp;

  if((fp=fopen(setting_file, "r"))==NULL)
    return 1;

  fgets(buf, sizeof(buf), fp);
  if(sscanf(buf, "%d %d %d %d %d",
	    &COLOR, &LEGEND, &STYLE, &WITH_MARK, &RE_DRAW)!=5)
    return 1;

  while(fgets(buf, sizeof(buf), fp)!=NULL){
    if(i>file_num-1)
      return 1;

    selected[i++]=atoi(buf);
  }

  if(ferror(fp))
    return 1;

  fclose(fp);
  return 0;
}

int save_script(char *script_name)
{
  FILE *fp;

  if((fp=fopen(script_name, "w"))==NULL)
    return 1;

  nsc_out(fp);

  fclose(fp);
  return 0;
}

void nsc_out(FILE *fp)
{
  int i,j=0;
  static char *line_style[]=
  {
    "",
    "' 100 100'",
    "' 150 150'",
    "' 450 150'",
    "' 450 150 150 150'",
    "' 450 150 150 150 150 150'",
    "' 450 150 450 150 150 150'"
  };

  static char *draw_type[]=
  {
    "mark",
    "line",
    "polygon",
    "curve", 
    "diagonal",
    "arrow",
    "rectangle",
    "rectangle_fill",
    "rectangle_solid_fill",
    "errorbar_x",
    "errorbar_y",
    "staircase_x",
    "staircase_y",
    "bar_x",
    "bar_y",
    "bar_fill_x",
    "bar_fill_y",
    "bar_solid_fill_x",
    "bar_solid_fill_y",
    "fit"
  };

  STYLE%=sizeof(draw_type)/sizeof(draw_type[0]);

  if(STYLE){
    for(i=0; i<file_num; i++){
      j=i%FILE_MAX;
      fprintf(fp, "file:%d:type=%s\n"
	      "file:%d:line_style=%s\n"
	      "file:%d:line_width=%d\n"
	      "file:%d:R=%d\n"
	      "file:%d:G=%d\n"
	      "file:%d:B=%d\n"
	      ,selected[i], draw_type[STYLE]
	      ,selected[i], (COLOR)?"":line_style[File_Style[j]%(sizeof(line_style)/sizeof(line_style[0]))]
	      ,selected[i], File_Width[(COLOR)?0:j]
	      ,selected[i], File_R[(COLOR)?j:0]
	      ,selected[i], File_G[(COLOR)?j:0]
	      ,selected[i], File_B[(COLOR)?j:0]);

      if(WITH_MARK)
	fprintf(fp, "new file\n"
		"cpy file:%d,!\n"
		"file:!:type=mark\n"
		"file:!:mark_type=%d\n"
		"file:!:fit=\n"
		,selected[i]
		,Mark[0]);
    }
  }else{
    for(i=0; i<file_num; i++){
      j=i%FILE_MAX;
      fprintf(fp, "file:%d:type=mark\n"
	      "file:%d:mark_type=%d\n"
	      "file:%d:R=%d\n"
	      "file:%d:G=%d\n"
	      "file:%d:B=%d\n"
	      ,selected[i]
	      ,selected[i], Mark[(COLOR)?0:j]
	      ,selected[i], File_R[(COLOR)?j:0]
	      ,selected[i], File_G[(COLOR)?j:0]
	      ,selected[i], File_B[(COLOR)?j:0]);
    }
  }

  if(LEGEND)
    fprintf(fp, "new shell\nshell::shell 'legend.nsc'\ndel shell\n");
  else if(RE_DRAW)
    fprintf(fp, "gra::clear\ngra::draw\n");
}
