#ifndef gra_header
#define gra_header

int  gra_set_dpi(int dpi);
void gra_set_bgcolor(gint r, gint g, gint b);
void gra_set_prgname(gchar *prgname);
int  gra_save(GdkImlibImage *im, char *gra_file);
int colorcmp(GdkImlibColor *a, GdkImlibColor *b);

#define DPI_MAX 2540

#endif
