/**************************************************************************

              img2gra Version 0.01 Copyright (C) H.Ito 2002

 **************************************************************************/

#define PRG_NAME "img2gra Version 0.01"

#include <gdk_imlib.h>
#include <gdk/gdk.h>
#include <stdio.h>
#include <unistd.h>
#include "gra.h"

int main(int argc, char **argv)
{
  GdkImlibImage *im;
  int opt, r, g, b, resolution;
  char *optstr = "r:b:", *bmp_file = NULL, *gra_file = NULL;
  char *usage = "Usage: %s [-r resolution -b bgcolor] image_file [gra file].\n";

  gdk_init(&argc, &argv);
  gdk_imlib_init();

  gra_set_prgname(g_basename(argv[0]));

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'b':
      if(strlen(optarg) != 6 || sscanf(optarg, "%02x%02x%02x", &r, &g, &b) != 3){
	printf("Invarid color(%s).\n", optarg);
	exit(1);
      }
      gra_set_bgcolor(r, g, b);
      break;
    case 'r':
      sscanf(optarg, "%d", &resolution);
      if(resolution < 1 || resolution > DPI_MAX){
	printf("Invarid resolution value(%d).\n", resolution);
	exit(1);
      }
      gra_set_dpi(resolution);
      break;
    case '?':
      printf(usage, argv[0]);
      exit(1);
      break;
    }
  }

  switch(argc - optind){
  case 2:
    gra_file = argv[optind + 1];
  case 1:
    bmp_file = argv[optind];
    break;
  default:
    printf(usage, argv[0]);
    exit(1);
  }

  if((im = gdk_imlib_load_image(bmp_file)) == NULL){
    exit(1);
  }

  gra_save(im, gra_file);
  return 0;
}

void print_error_exit(gchar *error)
{
  fprintf(stderr, "%s", error);
  exit(1);
}
