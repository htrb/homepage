/**************************************************************************

              gimg2gra Version 0.00 Copyright (C) H.Ito 2002

 **************************************************************************/
#include <gnome.h>
#include <assert.h>
#include "gra.h"

#define PRGNAME "gnoimg2gra"
#define VERSION "0.0.0"

#define WIDTH  0
#define HEIGHT 1

struct App_Data {
  GdkImlibImage *im;
  gchar *gra;
  GtkWidget *entry;
  gint dpi;
  GdkImlibColor shape_color;
};

static int ADJUST = WIDTH;
static GtkWidget *App = NULL;

extern void print_error_exit(gchar *error);

static void set_bgcolor(int r, int g, int b, struct App_Data *data);
static void set_window_size(GtkWidget *app, GtkWidget *hbox, GdkImlibImage *im);

static GdkPixmap *im_get_pixmap(GdkImlibImage *im);
static GtkWidget *create_drawing_area(struct App_Data *data);
static void create_entry(GdkImlibImage *im, GtkWidget *hbox, struct App_Data *data);
static void create_buttons(struct App_Data *data, GtkWidget *hbox);
static void create_radio_buttons(GtkWidget *box);

static gboolean delete_event(GtkWidget *widget, GdkEvent *event, gpointer data);
static gboolean expose_event(GtkWidget *widget, GdkEventExpose *event, gpointer data);
static gboolean button_press_event(GtkWidget *widget, GdkEventButton *event, gpointer data);
static void save_button_clicked(GtkButton *widget, gpointer data);
static void cancel_button_clicked(GtkButton *widget, gpointer data);
static void adjust_button_clicked(GtkButton *widget, gpointer data);

int main(int argc, char *argv[])
{
  GtkWidget *w, *vbox, *hbox;
  GdkImlibImage *im;
  gchar *title;
  static gchar *img_file = NULL, *gra_file = NULL;
  static char *usage = "Usage: %s resolution image_file gra_file\n";
  struct App_Data app_data;

  gnome_init(PRGNAME, VERSION, argc, argv);

  while(getopt(argc, argv, "") != -1);
  if(argc - optind != 3){
    gchar *error;

    error = g_strdup_printf(usage, g_basename(argv[0]));
    print_error_exit(error);
  }
  gra_file = argv[optind + 2];
  img_file = argv[optind + 1];
  app_data.dpi = atoi(argv[optind]);

  if(gra_file == NULL)
    gra_file = g_strconcat(g_basename(img_file), ".gra", NULL);

  gra_set_prgname(PRGNAME);

  if((im = gdk_imlib_load_image(img_file)) == NULL){
    gchar *error;

    error = g_strdup_printf("Can't open image file(%s).", img_file);
    print_error_exit(error);
  }
  gdk_imlib_get_image_shape(im, &app_data.shape_color);

  app_data.im = im;
  app_data.gra = gra_file;
  app_data.entry = NULL;

  vbox = gtk_vbox_new(FALSE, 0);
  hbox = gtk_hbox_new(FALSE, 0);

  w = create_drawing_area(&app_data);
  gtk_box_pack_start(GTK_BOX(vbox), w, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

  create_buttons(&app_data, hbox);

  title = g_strconcat(PRGNAME, ": ", im->filename, NULL);
  App = gnome_app_new(PRGNAME, title);
  gtk_signal_connect(GTK_OBJECT(App), "delete_event", GTK_SIGNAL_FUNC(delete_event), NULL);
  gnome_app_set_contents(GNOME_APP(App), vbox);

  gtk_widget_show_all(App);
  set_window_size(App, hbox, im);

  gtk_main();

  return 0;
}

void print_error_exit(gchar *error)
{
  GtkWidget *dialog;

  if(App == NULL)
    dialog = gnome_error_dialog(error);
  else
    dialog = gnome_error_dialog_parented(error, GTK_WINDOW(App));

  gnome_dialog_run(GNOME_DIALOG(dialog));

  exit(1);
}

static void set_window_size(GtkWidget *app, GtkWidget *hbox, GdkImlibImage *im)
{
  gint x, y, width, height, depth;     
  GtkRequisition requisition;

  gdk_window_get_geometry(NULL, &x, &y, &width, &height, &depth);     
  gtk_widget_get_child_requisition(GTK_WIDGET(hbox), &requisition);

  width = (width > im->rgb_width)? im->rgb_width : width;
  height = (height > im->rgb_height + requisition.height)? im->rgb_height + requisition.height : height;

  gtk_window_set_default_size(GTK_WINDOW(app), width, height);
}


static void create_buttons(struct App_Data *data, GtkWidget *box)
{
  GtkWidget *w, *vbox, *hbox;
  GdkImlibImage *im;

  vbox = gtk_vbox_new(FALSE, 0);

  im = data->im;

  create_entry(im, vbox, data);
  create_radio_buttons(vbox);

  gtk_box_pack_start(GTK_BOX(box), vbox, FALSE, FALSE, 10);

  hbox = gtk_hbox_new(TRUE, 0);
  w = gtk_button_new_with_label(" OK ");
  gtk_signal_connect(GTK_OBJECT(w), "clicked", GTK_SIGNAL_FUNC(save_button_clicked), data);
  gtk_box_pack_start(GTK_BOX(hbox), w, TRUE, TRUE, 5);

  w = gtk_button_new_with_label(" Cancel ");
  gtk_signal_connect(GTK_OBJECT(w), "clicked", GTK_SIGNAL_FUNC(cancel_button_clicked), NULL);
  gtk_box_pack_start(GTK_BOX(hbox), w, FALSE, FALSE, 5);

  gtk_box_pack_start(GTK_BOX(box), hbox, FALSE, FALSE, 5);
}

static void create_radio_buttons(GtkWidget *box)
{
  GtkWidget *w, *group, *hbox;

  hbox = gtk_hbox_new(FALSE, 0);

  w = gtk_label_new("ADJUST:");
  gtk_box_pack_start(GTK_BOX(hbox), w, FALSE, FALSE, 0);

  group = gtk_radio_button_new_with_label(NULL, "Width");
  if(ADJUST == WIDTH)
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(group), TRUE);
  gtk_signal_connect(GTK_OBJECT(group), "clicked", GTK_SIGNAL_FUNC(adjust_button_clicked), (gpointer)WIDTH);
  gtk_box_pack_start(GTK_BOX(hbox), group, FALSE, FALSE, 5);

  group = gtk_radio_button_new_with_label_from_widget(GTK_RADIO_BUTTON(group), "Height");
  if(ADJUST == HEIGHT)
    gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(group), TRUE);
  gtk_signal_connect(GTK_OBJECT(group), "clicked", GTK_SIGNAL_FUNC(adjust_button_clicked), (gpointer)HEIGHT);
  gtk_box_pack_start(GTK_BOX(hbox), group, FALSE, FALSE, 5);

  gtk_box_pack_start(GTK_BOX(box), hbox, FALSE, FALSE, 5);
}

static void create_entry(GdkImlibImage *im, GtkWidget *box, struct App_Data *data)
{
  GtkWidget *w, *hbox, *entry = NULL;
  gboolean sensitive = FALSE;

  hbox = gtk_hbox_new(FALSE, 0);

  w = gtk_label_new("BGCOLOR:");
  gtk_box_pack_start(GTK_BOX(hbox), w, FALSE, FALSE, 0);

  entry = gtk_entry_new();
  gtk_entry_set_max_length(GTK_ENTRY(entry), 10);
  gtk_editable_set_editable(GTK_EDITABLE(entry), FALSE);
  gtk_box_pack_start(GTK_BOX(hbox), entry, FALSE, FALSE, 0);

  data->entry = entry;

  if(data->shape_color.r < 0 || data->shape_color.g < 0 || data->shape_color.b < 0){
    sensitive = TRUE;
  }
  gtk_widget_set_sensitive(w, sensitive);
  gtk_widget_set_sensitive(entry, sensitive);

  set_bgcolor(255, 255, 255, data);

  gtk_box_pack_start(GTK_BOX(box), hbox, FALSE, FALSE, 0);
}

static GtkWidget *create_drawing_area(struct App_Data *data)
{
  GtkWidget *w, *sw;
  GdkPixmap *pixmap;
  GdkImlibImage *im;
  GtkPolicyType policy = GTK_POLICY_AUTOMATIC;

  im = data->im;

  pixmap = im_get_pixmap(im);

  w = gtk_drawing_area_new();
  gtk_drawing_area_size(GTK_DRAWING_AREA(w), im->rgb_width, im->rgb_height);
  gtk_widget_set_events(w, GDK_BUTTON_PRESS_MASK);
  gtk_signal_connect(GTK_OBJECT(w), "expose_event", GTK_SIGNAL_FUNC(expose_event), pixmap);
  gtk_signal_connect(GTK_OBJECT(w), "button_press_event", GTK_SIGNAL_FUNC(button_press_event), data);

  sw = gtk_scrolled_window_new(NULL, NULL);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(sw), policy, policy);
  gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(sw), w);

  return GTK_WIDGET(sw);
}

static GdkPixmap *im_get_pixmap(GdkImlibImage *im)
{
  GdkPixmap *p;

  gdk_imlib_render(im, im->rgb_width, im->rgb_height);
  p = gdk_imlib_move_image(im);
  assert(p != NULL);

  return p;
}

static void set_bgcolor(int r, int g, int b, struct App_Data *data)
{
  static char bgcolor[64];
  GdkImlibColor color;

  color.r = r;
  color.g = g;
  color.b = b;

  if(colorcmp(&color, &data->shape_color) == 0){
    gtk_entry_set_text(GTK_ENTRY(data->entry), "#------");
    return;
  }

  gra_set_bgcolor(r, g, b);
  sprintf(bgcolor, "#%02x%02x%02x", r, g, b);
  if(data->entry != NULL)
    gtk_entry_set_text(GTK_ENTRY(data->entry), bgcolor);
}

/************* Event Handler **************/
static gboolean delete_event(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  gtk_main_quit();
  return TRUE;
}

static gboolean expose_event(GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  GdkPixmap *pixmap = (GdkPixmap *) data;

  gdk_window_clear_area(widget->window, event->area.x, event->area.y,event->area.width, event->area.height);
  gdk_gc_set_clip_rectangle (widget->style->fg_gc[widget->state], &event->area);
  gdk_draw_pixmap(widget->window, widget->style->fg_gc[widget->state], pixmap,
		  event->area.x, event->area.y, event->area.x, event->area.y, event->area.width, event->area.height);
  gdk_gc_set_clip_rectangle(widget->style->fg_gc[widget->state], NULL);
  return TRUE;
}

static gboolean button_press_event(GtkWidget *widget, GdkEventButton *event, gpointer data)
{
  struct App_Data *app_data = (struct App_Data *) data;
  GdkImlibImage *im;
  int i, x = event->x,  y = event->y;
  GtkWidget *entry;

  im = app_data->im;
  entry = app_data->entry;

  if(x >= im->rgb_width || y >= im->rgb_height)
    return TRUE;
  
  i = (y * im->rgb_width + x) * 3;
  switch(event->button){
  case 1:
    set_bgcolor(im->rgb_data[i], im->rgb_data[i + 1], im->rgb_data[i + 2], app_data);
    break;
  }

  return TRUE;
}

static void adjust_button_clicked(GtkButton *widget, gpointer data)
{
  ADJUST = (int) data;
}

static void save_button_clicked(GtkButton *widget, gpointer data)
{
  struct App_Data *app_data = (struct App_Data *) data;
  GdkImlibImage *im;
  gchar *grafile;
  int dotsize;
  char *adj[] = {"Width", "Height"};

  im = app_data->im;
  grafile = app_data->gra;

  dotsize = gra_set_dpi(app_data->dpi);
  gra_save(im, grafile);
  printf("%d %d %s\n", im->rgb_width * dotsize, im->rgb_height * dotsize, adj[ADJUST]);
  gtk_main_quit();
}

static void cancel_button_clicked(GtkButton *widget, gpointer data)
{
  gtk_main_quit();
}
