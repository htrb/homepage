#include <gdk_imlib.h>
#include <gdk/gdk.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
#include "gra.h"

extern void print_error_exit(gchar *error);

static GdkImlibColor BGCOLOR = {255, 255, 255}, IGNCOLOR = {-1, -1, -1};
static int DotSize = 36;
static gchar *PRGNAME ="";

struct rectangle{
  unsigned char r, g, b;
  int x1, y1, x2, y2;
};

static int rectcmp(const void *tmpa, const void *tmpb);
static void fputcolor(FILE *fp, GdkImlibColor *color);

void gra_set_bgcolor(gint r, gint g, gint b)
{
  if(r >= 0 && r < 256 && g >= 0 && g < 256 && b >= 0 && b < 256){
    BGCOLOR.r = r;
    BGCOLOR.g = g;
    BGCOLOR.b = b;
  }
}

int gra_set_dpi(int dpi)
{
  if(dpi > 0 && dpi<= DPI_MAX)
    DotSize = DPI_MAX / dpi;

  return DotSize;
}

void gra_set_prgname(gchar *prgname)
{
  if(prgname != NULL)
    PRGNAME = prgname;
}

int gra_save(GdkImlibImage *im, char *gra_file)
{
  gint w, h, x, x1, y, i, j;
  GdkImlibColor shape_color, color, color2;
  struct rectangle *rect;
  FILE *fp;

  if(im == NULL)
    return 1;

  w=im->rgb_width;
  h=im->rgb_height;

  if(INT_MAX / sizeof(*rect) / w / h < 1 || INT_MAX / w / DotSize < 1 || INT_MAX / h / DotSize < 1){
    gchar *error;
    error = g_strdup_printf("Too large image(%s).\n", im->filename);
    print_error_exit(error);
  }
  rect = g_malloc(sizeof(*rect) * w * h);

  if(gra_file == NULL){
    fp = stdout;
  }else if((fp = fopen(gra_file, "wt")) == NULL){
    print_error_exit(g_strerror(errno));
  }

  fprintf(fp, "%%Ngraph GRAF\n"
	  "%%Creator: %s\n"
	  "I,5,0,0,%d,%d,10000\n"
	  "V,5,0,0,%d,%d,1\n"
	  "A,5,0,1,0,0,1000\n",
	  PRGNAME,
	  w * DotSize, h * DotSize,
	  w * DotSize, h * DotSize);

  gdk_imlib_get_image_shape(im, &shape_color);

  if(!colorcmp(&IGNCOLOR, &shape_color)){
    shape_color = BGCOLOR;
    fputcolor(fp, &BGCOLOR);
    fprintf(fp, "B,5,0,0,%d,%d,1\n", w * DotSize, h * DotSize);
  }
  color = color2 = shape_color;

  j = 0;
  for(y = 0; y < h; y++){
    i = y * 3 * w;
    for(x = x1 = 0; x < w; x++){
      color2.r = im->rgb_data[i++];
      color2.g = im->rgb_data[i++];
      color2.b = im->rgb_data[i++];

      if(colorcmp(&color2, &color)){
	if(x != 0 && colorcmp(&shape_color, &color)){
	  rect[j].r = color.r;
	  rect[j].g = color.g;
	  rect[j].b = color.b;
	  rect[j].x1 = x1 * DotSize;
	  rect[j].y1 = y * DotSize;
	  rect[j].x2 = x * DotSize;
	  rect[j].y2 = (y + 1) * DotSize;
	  j++;
	}
	color = color2;
	x1 = x;
      }
      if(x == w - 1 && colorcmp(&shape_color, &color)){
	rect[j].r = color.r;
	rect[j].g = color.g;
	rect[j].b = color.b;
	rect[j].x1 = x1 * DotSize;
	rect[j].y1 = y * DotSize;
	rect[j].x2 = (x + 1) * DotSize;
	rect[j].y2 = (y + 1) * DotSize;
	j++;
      }
    }
  }

  qsort(rect, j, sizeof(*rect), rectcmp);
  color.r = rect[0].r;
  color.g = rect[0].g;
  color.b = rect[0].b;
  fputcolor(fp, &color);
  for(i = 0; i < j; i++){
    color2.r = rect[i].r;
    color2.g = rect[i].g;
    color2.b = rect[i].b;
    if(colorcmp(&color2, &color)){
      fputcolor(fp, &color2);
      color = color2;
    }
    fprintf(fp, "B,5,%d,%d,%d,%d,1\n", rect[i].x1, rect[i].y1, rect[i].x2, rect[i].y2);
  }
  fprintf(fp, "E,0\n");

  if(ferror(fp)){
    print_error_exit(g_strerror(errno));
  }

  if(fp != stdout)
    fclose(fp);

  g_free(rect);
  return 0;
}

int colorcmp(GdkImlibColor *a, GdkImlibColor *b)
{
  if(a->r == b->r && a->g == b->g && a->b == b->b)
    return 0;
  else
    return 1;
}

static int rectcmp(const void *tmpa, const void *tmpb)
{
  struct rectangle *a = (struct rectangle *)tmpa,  *b = (struct rectangle *)tmpb;
  int c, d;

  c = (((int)a->r)<<16) + (((int)a->g)<<8) + a->b;
  d = (((int)b->r)<<16) + (((int)b->g)<<8) + b->b;
  return d - c;
}

static void fputcolor(FILE *fp, GdkImlibColor *color)
{
  fprintf(fp, "G,3,%d,%d,%d\n", color->r, color->g, color->b);
}

