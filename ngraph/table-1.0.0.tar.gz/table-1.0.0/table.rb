#!/usr/bin/ruby
#
#  table.rb Version 1.0.0 written by hito 2000/3/8
#
require "tk"
require "tkentry"
require "tkscrollbox"
require "jcode"
require "kconv"

class TABLE
  include Tk

  ON  = 1
  OFF = 0

  SEPARATOR = /\t+/
  VALIGN_LIST = ['Top', 'Center', 'Bottom']
  HALIGN_LIST = ['Left', 'Center', 'Right']

  LABEL_TITLE = 'Table Version 1.0.0'
  LABEL_POSITION = '�ΰ��֡�'
  LABEL_TEXT = '�Υƥ����ȡ�'
  LABEL_NUMERICAL = '�ο��͡�'
  LABEL_VALIGN = '�νİ��֡�'
  LABEL_HALIGN = '�β����֡�'
  LABEL_LINE = '�η�����'
  LABEL_X = 'X:'
  LABEL_Y = 'Y:'
  LABEL_PADX = '��;��:'
  LABEL_PADY = '��;��:'
  LABEL_RIGHT = '����'
  LABEL_COLOR = '��: '
  LABEL_PT = '�ݥ����:'
  LABEL_FONT = 'Font:'
  LABEL_JFONT = 'JFont:'
  LABEL_DRAW = '����'
  LABEL_SLASH = '����'
  LABEL_WIDTH = '����:'
  LABEL_OK = 'OK'
  LABEL_CANCEL = 'Cancel'
  LABEL_SAVEALL = '��������¸'
  LABEL_SETTING = '�������'

  def initialize(scriptname = 'TABLE.$$$', tablename = 'TABLE',
		 x = 5000, y = 5000,
		 lcolor = '#000000', lwidth = 40,
		 tcolor = '#000000', fpt = 2000, font = 'Helv', jfont = 'Goth', draw = ON, saveall = ON,
		 padx = 200, pady = 200, valign = 'Top', halign = 'Left', slash = ON, numerical = ON)

    @table_name = tablename
    @linecolor = lcolor
    @textcolor = tcolor
    @draw = TkVariable.new(draw)

    @separator = SEPARATOR

    @valign = TkVariable.new(valign)
    @halign = TkVariable.new(halign)
    @numerical = TkVariable.new(numerical)
    @slash = TkVariable.new(slash)
    @saveall = TkVariable.new(saveall)

    @list = nil
    @x = nil
    @y = nil
    @padx = nil
    @pady = nil
    @linewidth = nil
    @column_items = nil

#TITLE
    TkLabel.new(nil, 'text'=>LABEL_TITLE){
      pack('side'=>'top', 'pady'=>'10')
    }


#LISTBOX
    @list = TkScrollbox.new{
      width 25
      font '-adobe-*-*-r-*--14-*-*-*-m-*-*-*'
      setgrid 'yes'
      pack('side'=>'left', 'fill'=>'both', 'padx'=>'5', 'pady'=>'2')
    }


#MAINPANEL
    fpanel = TkFrame.new{
      pack('side'=>'right','fill'=>'y')
    }


#SUBPANEL LEFT
    fpanel_left = TkFrame.new(fpanel){
      pack('side'=>'left', 'fill'=>'both')
    }


    ftable_position = TkFrame.new(fpanel_left, 'relief'=>'groove', 'bd'=>'2'){
      pack('fill'=>'both', 'padx'=>'5', 'pady'=>'2', 'ipadx'=>'2', 'ipady'=>'2')
    }
    
    TkLabel.new(ftable_position, 'text'=>LABEL_POSITION){
      pack('anchor'=>'w')
    }

    @x = new_entry(ftable_position, LABEL_X, x, 9)
    @y = new_entry(ftable_position, LABEL_Y, y, 9)
    @padx = new_entry(ftable_position, LABEL_PADX, padx, 6)
    @pady = new_entry(ftable_position, LABEL_PADY, pady, 6)


    fanchor = TkFrame.new(fpanel_left) {
      pack('fill'=>'both', 'padx'=>'5', 'pady'=>'2', 'ipadx'=>'2', 'ipady'=>'2')
    }

    fanchor_num = TkFrame.new(fanchor, 'relief'=>'groove', 'bd'=>'2'){
      pack('fill'=>'both', 'anchor'=>'w', 'pady'=>'2')
    }

    TkLabel.new(fanchor_num, 'text'=>LABEL_NUMERICAL){
      pack('anchor'=>'w', 'side'=>'top')
    }

    TkCheckButton.new(fanchor_num, 'text'=>LABEL_RIGHT, 'variable'=>@numerical){
      pack('anchor'=>'w')
    }
    
    fanchor_v = TkFrame.new(fanchor, 'relief'=>'groove', 'bd'=>'2'){
      pack('fill'=>'both', 'anchor'=>'w', 'pady'=>'2')
    }

    TkLabel.new(fanchor_v, 'text'=>LABEL_VALIGN){
      pack('anchor'=>'w', 'side'=>'top')
    }

    VALIGN_LIST.each{|item|
      TkRadioButton.new (fanchor_v, 'variable'=>@valign, 'text'=>item, 'value'=>item){
	pack('anchor'=>'w')
      }
    }

    fanchor_h = TkFrame.new(fanchor, 'relief'=>'groove', 'bd'=>'2'){
      pack('fill'=>'both', 'anchor'=>'w', 'pady'=>'2')
    }

    TkLabel.new(fanchor_h, 'text'=>LABEL_HALIGN){
      pack('anchor'=>'w', 'side'=>'top')
    }
    HALIGN_LIST.each{|item|
      TkRadioButton.new (fanchor_h, 'variable'=>@halign, 'text'=>item, 'value'=>item){
	pack('anchor'=>'w')
      }
    }


#SUBPANEL RIGHT    
    fpanel_right = TkFrame.new(fpanel){
      pack('side'=>'right', 'fill'=>'both')
    }



    TkButton.new(fpanel_right,
		 'text'=>LABEL_CANCEL,
		 'command'=>proc{exit}){
      pack('side'=>'bottom', 'fill'=>'x', 'padx'=>'5', 'pady'=>'5')
    }

    TkButton.new(fpanel_right,
		 'text'=>LABEL_OK,
		 'command'=>proc{write_script(scriptname); exit}){
      pack('side'=>'bottom', 'fill'=>'x', 'padx'=>'5', 'pady'=>'5')
    }



    ffont = TkFrame.new(fpanel_right, 'relief'=>'groove', 'bd'=>'2'){
      pack('fill'=>'both', 'padx'=>'5', 'pady'=>'2', 'ipadx'=>'2', 'ipady'=>'2')
    }

    TkLabel.new(ffont, 'text'=>LABEL_TEXT){
      pack('anchor'=>'w')
    }

    @fontpt = new_entry(ffont, LABEL_PT, fpt, 5)
    @font = new_entry(ffont, LABEL_FONT, font, 7)
    @jfont = new_entry(ffont, LABEL_JFONT, jfont, 6)

    ffont_color = TkFrame.new(ffont){
      pack('anchor'=>'w', 'pady'=>'2')
    }

    TkLabel.new(ffont_color, 'text'=>LABEL_COLOR){
      pack('side'=>'left')
    }
      
    b_fontcolor = TkButton.new(ffont_color,
		 'width'=>'3',
		 'bg'=>@textcolor,
		 'command'=>proc{
		   @textcolor = select_color(@textcolor)
		   b_fontcolor.configure('bg', @textcolor)}){
      pack('side'=>'right')
    }



    fline = TkFrame.new(fpanel_right, 'relief'=>'groove', 'bd'=>'2'){
      pack('fill'=>'both', 'padx'=>'5', 'pady'=>'2', 'ipadx'=>'2', 'ipady'=>'2')
    }

    TkLabel.new(fline, 'text'=>LABEL_LINE){
      pack('anchor'=>'w')
    }

    TkCheckButton.new(fline, 'text'=>LABEL_DRAW, 'variable'=>@draw){
      pack('anchor'=>'w')
    }

    TkCheckButton.new(fline, 'text'=>LABEL_SLASH, 'variable'=>@slash){
      pack('anchor'=>'w')
    }

    @linewidth = new_entry(fline, LABEL_WIDTH, lwidth, 3)
    fline_color = TkFrame.new(fline){
      pack('anchor'=>'w', 'pady'=>'2')
    }

    TkLabel.new(fline_color, 'text'=>LABEL_COLOR){
      pack('side'=>'left')
    }

    b_linecolor = TkButton.new(fline_color,
		 'width'=>'3',
		 'bg'=>@linecolor,
		 'command'=>proc{
		   @linecolor = select_color(@linecolor)
		   b_linecolor.configure('bg'=>@linecolor)}){
      pack('side'=>'right')
    }

    fsaveall = TkFrame.new(fpanel_right, 'relief'=>'groove', 'bd'=>'2'){
      pack('fill'=>'both', 'padx'=>'5', 'pady'=>'2', 'ipadx'=>'2', 'ipady'=>'2')
    }

    TkLabel.new(fsaveall, 'text'=>LABEL_SETTING){
      pack('anchor'=>'w', 'side'=>'top')
    }

    TkCheckButton.new(fsaveall, 'text'=>LABEL_SAVEALL, 'variable'=>@saveall){
      pack('anchor'=>'w')
    }
  end

  def read_data(filename)
    @column_items = 0
    IO.foreach(filename) {|l|
      l.chomp!
      @list.insert('end', l.gsub('\'', '\\\x27'))
      i = l.split(@separator).nitems
      if (i > @column_items)
	@column_items = i
      end
    }
  end

  def new_entry(form, title, inial_text, text_width)
    entry = nil

    TkFrame.new(form) {|f|
      TkLabel.new(f) {
	text title
	pack('side'=>'left')
      }
      entry = TkEntry.new(f) {
	width text_width
	insert 0, inial_text
	pack('side'=>'right')
      }
      pack('anchor'=>'w', 'pady'=>'2')
    }
    return entry
  end

  def select_color(initialcolor)
    tmpcolor = tk_call('tk_chooseColor', '-initialcolor', initialcolor)
    if (tmpcolor != "")
      return tmpcolor
    else
      return initialcolor
    end
  end

  def run
    root = TkRoot.new
    root.title 'Table.rb'
    Tk.mainloop
  end

  def write_script(filename)
    script_file = open(filename, "w")
    row = Integer(@list.index('end'))
    font_size = @fontpt.value
    text_color_r = Integer("0x"+@textcolor[1,2])
    text_color_g = Integer("0x"+@textcolor[3,2])
    text_color_b = Integer("0x"+@textcolor[5,2])
    line_color_r = Integer("0x"+@linecolor[1,2])
    line_color_g = Integer("0x"+@linecolor[3,2])
    line_color_b = Integer("0x"+@linecolor[5,2])
    i = 0
    j = 0
    while (i < row)
      line = @list.get(i).split(@separator)

      if (@column_items - line.nitems > 0)
	line.fill(" ", line.nitems .. @column_items - 1)
      end

      line.each {|s|
	script_file.print "new text\n"

	if (s.length == 0)
	  s = " "
	end

	if (s =~ /^ +$/o )
	  script_file.print 'iarray:pos:add ${text::id}',"\n"
	else
	  position = -1

	  if (s =~ /^_.*_$/o )
	    s.gsub!(/^_(.*)_$/, "\\1")
	    position -= 16
	  elsif (s =~ /-.*-$/o )
	    s.gsub!(/^-(.*)-$/, "\\1")
	    position -= 32
	  elsif (s =~ /~.*~$/o )
	    s.gsub!(/^~(.*)~$/, "\\1")
	    position -= 64
	  end

	  if (s =~ /^>.*>$/o )
	    s.gsub!(/^>(.*)>$/, "\\1")
	    position -= 2
	  elsif (s =~ /^>.*<$/o )
	    s.gsub!(/^>(.*)<$/, "\\1")
	    position -= 4
	  elsif (s =~ /^<.*<$/o )
	    s.gsub!(/^<(.*)<$/, "\\1")
	    position -= 8
	  elsif ((s =~ /^[+-]?[0-9,\.]+[EeDd]?[+-]?[0-9]*$/o) && (@numerical == 1))
	    position -= 2
	  end

	  script_file.print 'iarray:pos:add ', position, "\n"
	end

	script_file.print "text::text='",Kconv::tosjis(s),"'\n"
	script_file.print 'text::R=',text_color_r,"\n"
	script_file.print 'text::G=',text_color_g,"\n"
	script_file.print 'text::B=',text_color_b,"\n"
	script_file.print 'text::pt=',font_size,"\n"
	script_file.print 'text::font=',@font.value,"\n"
	script_file.print 'text::jfont=',@jfont.value,"\n"
	script_file.print 'text::name="',@table_name,"\"\n"
	script_file.print 'set ${text::bbox}',"\n"
	script_file.print 'iarray:width:add `iexpr "ABS($1 - $3)"`',"\n"
	script_file.print 'iarray:height:add `iexpr "ABS($2 - $4)"`',"\n"

	if j == 0
	  script_file.print "id=${text::id}\n"
	end
	j = 1
      }
      i += 1
    end

    if (@saveall == 1)
      script_file.print "new text name=_#{@table_name}\n"
      script_file.print "text::hidden=true\n"
      script_file.print "text::text=\"",\
      "DummyText,#{@table_name#},#{@padx.value},#{@pady.value},",\
      "#{@valign},#{@halign},#{@slash},#{@numerical}\"\n"
    end

    script_file.print 'RL=',line_color_r,"\n"
    script_file.print 'GL=',line_color_g,"\n"
    script_file.print 'BL=',line_color_b,"\n"
    script_file.print 'col=', @column_items, "\n"
    script_file.print 'row=', row, "\n"
    script_file.print 'PADX=', @padx.value, "\n"
    script_file.print 'PADY=', @pady.value, "\n"
    script_file.print 'x=', @x.value, "\n"
    script_file.print 'y=', @y.value, "\n"
    script_file.print 'line_width=', @linewidth.value, "\n"
    script_file.print 'VALIGN=', @valign, "\n"
    script_file.print 'HALIGN=', @halign, "\n"
    script_file.print 'DRAW=', @draw, "\n"
    script_file.print 'SLASH=', @slash, "\n"
  end
end

if (ARGV.nitems != 18)
  exit
end

setting = ARGV[17].split(',')
if (setting.nitems != 8)
    exit
end

table = TABLE.new(ARGV[1], ARGV[2], ARGV[3], ARGV[4],
		  sprintf("#%02x%02x%02x", ARGV[5], ARGV[6], ARGV[7]),
		  ARGV[8],
		  sprintf("#%02x%02x%02x", ARGV[9], ARGV[10], ARGV[11]),
		  ARGV[12], ARGV[13], ARGV[14], ARGV[15], ARGV[16],
		  setting[2], setting[3], setting[4], setting[5], setting[6], setting[7])

table.read_data(ARGV[0])
table.run
