/* $Id: w3mimgsize.c,v 1.1 2002/01/31 17:54:57 ukai Exp $ */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "getsize.h"

int main(int argc, char **argv)
{
  int width, height;

  fclose(stderr);
  if (argc < 2)
    exit(1);

  if(getsize(argv[1], &width, &height) != 0)
    exit(1);

  printf("%d %d\n", width, height);
  exit(0);
}
