/**************************************************************************
               fb_img 0.00 Copyright (C) hito 2002
 **************************************************************************/

#define PRG_NAME "fb_img Version 0.00"
#define BUF_SIZE 1024

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "fb.h"
#include "fb_img.h"

#define BUFSIZE 2048

IMAGE *fb_load_image(char *filename, int w, int h)
{
  char buf[BUFSIZE];
  IMAGE *bmp;

  snprintf(buf, sizeof(buf), "convert -geometry %dx%d! %s %s.bmp", w, h, filename, filename);
  if(WEXITSTATUS(system(buf)))
    return NULL;

  snprintf(buf, sizeof(buf), "%s.bmp", filename);
  bmp = read_bmp(buf);
  remove(buf);
  return bmp;
}

int fb_disp_image(IMAGE *bmp, int x, int y, int sx, int sy, int width, int height)
{
  int i, j;

  if(bmp == NULL)
    return 1;
  for(j = sy; j < sy + height; j++){
    for(i = sx; i < sx + width; i++){
      fb_pset(i + x - sx, j + y - sy,
	      bmp->data[j][i].R, bmp->data[j][i].G, bmp->data[j][i].B);
    }
  }
  return 0;
}
void fb_free_image(IMAGE *bmp)
{
  if(bmp != NULL)
    free_bmp(bmp);
}
