#ifndef bmp_header
#define bmp_header
typedef struct{
  unsigned char B;
  unsigned char G;
  unsigned char R;
  unsigned char Reserved;
}RGBQUAD;

typedef struct{
  int width;
  int height;
  RGBQUAD *data[1];
}BMP_DATA;

BMP_DATA *read_bmp(char *bmp_file);
void free_bmp(BMP_DATA *data);

#endif
