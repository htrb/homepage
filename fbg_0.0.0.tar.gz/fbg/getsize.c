#include <stdio.h>
#include <stdlib.h>

#define BUFSIZE 2048

int getsize(char *file, int *width, int *height)
{
  char buf[BUFSIZE];
  FILE *fp;
  char *ptr;

  if(file == NULL || width == NULL || height == NULL) return 1;

  snprintf(buf, sizeof(buf), "identify %s", file);
  fp = popen(buf, "r");
  if(fp == NULL) return 1;

  fgets(buf, sizeof(buf), fp);
  pclose(fp);

  ptr = buf + strlen(file) + 1;
  if(sscanf(ptr, "%dx%d", width, height) != 2) return 1;

  return 0;
}

