$B"#Ds6!$9$k$b$N(B
  $B!&(Bfbg             framebuffer $BMQ2hA|%S%e!<%"(B
  $B!&(Bw3mimgdisplayfb w3mimgdisplay ($B$[$\(B)$B8_49$N(B framebuffer $BMQ2hA|%S%e!<%"(B
  $B!&(Bw3mimgsizefb    w3mimgsize ($B$[$\(B)$B8_49$N2hA|%5%$%:Js9p%W%m%0%i%`(B

$B"#I,MW$J$b$N(B
  $B!&(BImageMagick (identify, convert $B$r;HMQ(B)
    $B3+H/;~$KMxMQ$7$?(B version 
      Version: @(#)ImageMagick 5.2.9 03/01/01 Q:16 http://www.imagemagick.org
      Copyright: Copyright (C) 2001 ImageMagick Studio
  $B!&(BTRUE $B%+%i!<$N(Bframebuffer $B$rMxMQ$G$-$k4D6-(B

$B"#@)8BEy(B
  $B!&(Bframebuffer $B$O(B 15,16,24,32bpp PACKED-PIXELS TRUE-COLOR
    $B$K$7$+BP1~$7$F$$$^$;$s!#(B
  $B!&I=<($N3NG'$O%$%s%F%k%W%i%C%H%[!<%`$N%b!<%I(B 0x314, 0x317
    $B$G9T$J$$$^$7$?!#(B

    $ dmesg |grep vesafb
    vesafb: framebuffer at 0xe2000000, mapped to 0xc880d000, size 8192k
    vesafb: mode is 1024x768x16, linelength=2048, pages=4
    vesafb: protected mode interface info at c000:4785
    vesafb: scrolling: redraw
    vesafb: directcolor: size=0:5:6:5, shift=0:11:5:0

  $B!&2hA|$O(B convert $B$K$h$C$F(B BMP $B$KJQ49$5$l$?8eI=<($5$l$^$9!#(B
  $B!&(Bw3mimgsizefb $B$G$O(B identify $B$rMxMQ$7$F$$$^$9!#(B
  $B!&(Bidentify $B$,8m$C$?%5%$%:$rJs9p$9$k(B GIF $B2hA|$,$"$j$^$7$?!#(B
    ImageMagick $B$NLdBj$J$N$+!"2hA|$,0[>o$J$N$+$OD4$Y$F$$$^$;$s!#(B
  $B!&%b%N%/%m#2CM$N(B GIF $B%U%!%$%k$r(B convert $B$G(B BMP $B$KJQ49$9$k$H(B
    $BGr9uH?E>$7$F$7$^$&$3$H$,$"$k$h$&$G$9!#(B
  $B!&(BBMP $B$K$O(B($BB?J,(B)$BF)2a?'$N;XDj$,=PMh$J$$$?$a(B w3mimgdisplayfb 
    $B$G$O(B -bg $B%*%W%7%g%s$rL5;k$7$F$$$^$9!#(B

$B"#$=$NB>(B
  $B!&(Bw3mimgsizefb, w3mimgdisplayfb $B$O:dK\9@B'$5$s$N(B w3mimgsize,
    w3mimgdisplay $B$r$b$H$K$7$F$$$^$9(B($B$H$$$&$+$[$H$s$I$=$N$^$^$G$9(B)$B!#(B
  $B!&(Bframebuffer $BIA2h4X78$N%k!<%A%s$O!"$d$^$5$-$7$s$8$5$s$N%5%s%W%k%W%m%0(B
    $B%i%`$r$b$H$K$7$F$$$^$9(B($B$H$$$&$+$[$H$s$I$=$N$^$^$G$9(B)$B!#(B
  $B!&$^$@3+H/ES>e$G$"$j!"F0:n3NG'$bIT==J,$G$9!#;HMQ$5$l$k:]$O$4<+?H$N@UG$(B
    $B$G$*4j$$$7$^$9!#(B

$B"#3+H/4D6-(B
  $B!&(B w3m version w3m/0.3+cvs-1.353-m17n-20020316
  $B!&(B linux 2.4.18 (Vine Linux 2.5)
  $B!&(B gcc 2.95.3
  $B!&(B $B%S%G%*%+!<%I(B
    VGA compatible controller: ATI Technologies Inc 3D Rage Pro AGP 1X/2X (rev 92).
      Master Capable.  Latency=64.  Min Gnt=8.
      Non-prefetchable 32 bit memory at 0xe2000000 [0xe2ffffff].
      I/O at 0xd800 [0xd8ff].
      Non-prefetchable 32 bit memory at 0xe1800000 [0xe1800fff].

$B"#4XO"(B URI
   $B!&(B W3M Homepage  http://w3m.sourceforge.net/
   $B!&(B w3m-img http://www2u.biglobe.ne.jp/%7Ehsaka/w3m/index-ja.html
   $B!&(B Linux Kernel Hack Japan http://www.sainet.or.jp/~yamasaki/

