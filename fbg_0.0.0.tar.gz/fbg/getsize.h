#ifndef getsize_header
#define getsize_header

int getsize(char *file, int *width, int *height);

#endif
