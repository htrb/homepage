/**************************************************************************
               fbb 0.00 Copyright (C) hito 2002

               char = 8 bit, short = 16 bit, long = 32 bit
 **************************************************************************/

#define PRG_NAME "fbb Version 0.00"
#define BUF_SIZE 1024

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "fb.h"
#include "bmp.h"
#include "getsize.h"

#define BUFSIZE 2048
static int draw(BMP_DATA *bmp);

int main(int argc, char *argv[])
{
  BMP_DATA *bmp;
  int opt, fit = 0, width, height;
  char *optstr = "cfF", *img_file = NULL, bmp_file[] = "/tmp/fbbXXXXXX";
  char *usage = "Usage: %s [-cfF] file\n";
  char buf[BUFSIZE];

  if(mkstemp(bmp_file) < 0)
    return 1;

  if(fb_open())
    goto END;

  while((opt = getopt(argc, argv, optstr)) != -1){
    switch(opt){
    case 'c':
      fb_clear();
      goto END;
      break;
    case 'f':
      fit = 1;
      break;
    case 'F':
      fit = 2;
      break;
    case '?':
      printf(usage, argv[0]);
      goto END;
      break;
    }
  }

  switch(argc - optind){
  case 1:
    img_file = argv[optind];
    break;
  default:
    printf(usage, argv[0]);
    goto END;
  }

  if(getsize(img_file, &width, &height) != 0)
    goto END;

  switch(fit){
  case 1: 
    if(width > height && width > fb_width()){
      height *= fb_width() * 1.0 / width;
      width = fb_width();
    }else if(width < height && height > fb_height()){
      width *= fb_height() * 1.0 / height;
      height = fb_height();
    }
    break;
  case 2:
    width = fb_width();
    height = fb_height();
    break;
  }

  snprintf(buf, sizeof(buf), "convert -geometry %dx%d! %s BMP:%s",
	    width, height, img_file, bmp_file);
  if(WEXITSTATUS(system(buf))){
    goto END;
  }

  bmp = read_bmp(bmp_file);
  if(bmp != NULL)
    draw(bmp);

 END:
  remove(bmp_file);
  fb_close();
  return 0;
}

static int draw(BMP_DATA *bmp)
{
  int width, height, x, y;

  if(bmp == NULL)
    exit(1);

  width = bmp->width;
  height = bmp->height;

  for(y = 0; y < height; y++){
    for(x = 0; x < width; x++){
       fb_pset(x, y, bmp->data[y][x].R, bmp->data[y][x].G, bmp->data[y][x].B);
    }
  }
  return 0;
}
