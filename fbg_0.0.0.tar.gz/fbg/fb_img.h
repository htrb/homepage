#ifndef fb_img_header
#define fb_img_header

#include "bmp.h"
typedef BMP_DATA IMAGE;

IMAGE *fb_load_image(char *filename, int w, int h);
int    fb_disp_image(IMAGE *bmp, int x, int y, int sx, int sy, int width, int height);
void   fb_free_image(IMAGE *bmp);

#endif
